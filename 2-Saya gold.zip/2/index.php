




<!DOCTYPE html>
<html dir="ltr" lang="en" class="has-hover no-js not-ready">
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">

        <title>Saya Gold</title>

            <link rel="preconnect" href="https://storage.googleapis.com" crossorigin>

            
            

                        <style>
                body { background: #ffffff; color: #ffffff; }
                a { color: #ffffff; }
                .js.not-ready, .js.not-ready * { transition: none !important; }
            </style>
        
            <link rel="stylesheet" href="assets/stylesheets/global.css">
            <link rel="stylesheet" href="assets/stylesheets/landing.css" />

            <script>
            document.documentElement.classList.remove('no-js');
            document.documentElement.classList.add('js');

            if (navigator.platform.toUpperCase().indexOf('WIN') >= 0) {
                document.documentElement.classList.add('is-win');
            }
        </script>

            <link rel="manifest" href="assets/manifest/manifest.webmanifest">
<meta name="theme-color" content="#000000">
<meta name="msapplication-config" content="assets/manifest/browserconfig.xml?v=1779376336">

<link rel="shortcut icon" href="/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="assets/manifest/favicon-32x32-dark.png" media="(prefers-color-scheme: light)">
<link rel="icon" type="image/png" sizes="32x32" href="assets/manifest/favicon-32x32.png" media="(prefers-color-scheme: dark)">
<link rel="icon" type="image/png" sizes="16x16" href="assets/manifest/favicon-16x16-dark.png" media="(prefers-color-scheme: light)">
<link rel="icon" type="image/png" sizes="16x16" href="assets/manifest/favicon-16x16.png" media="(prefers-color-scheme: dark)">
<link rel="apple-touch-icon" href="/assets/manifest/apple-touch-icon.png?v=1779376336">
<link rel="mask-icon" href="/assets/manifest/safari-pinned-tab.svg?v=1779376336" color="#ffffff">

                    <link rel="canonical" href="">
                <meta name="description" content="Zorge 9 is an exclusive complex of New York-style apartments in the prestigious Khodynka district. Luxurious interiors, five-star hotel service, private park, fitness center for residents. Feel like you&amp;#039;re living in the lap of luxury.">
                        <meta name="format-detection" content="telephone=no">

            <link rel="canonical" href="">

                    <meta property="og:type" content="website">
        <meta property="og:url" content="">
        <meta property="og:title" content="Business class apartments Zorge 9|Luxury Real Estate">
        <meta property="og:description" content="Zorge 9 is an exclusive complex of New York-style apartments in the prestigious Khodynka district. Luxurious interiors, five-star hotel service, private park, fitness center for residents. Feel like you&amp;#039;re living in the lap of luxury.">
        <meta property="og:locale" content="en_US">
        <meta property="og:image" content="">

                <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="Business class apartments Zorge 9|Luxury Real Estate">
        <meta name="twitter:description" content="Zorge 9 is an exclusive complex of New York-style apartments in the prestigious Khodynka district. Luxurious interiors, five-star hotel service, private park, fitness center for residents. Feel like you&amp;#039;re living in the lap of luxury.">
        <meta name="twitter:image" content="https://zorge9.estate/assets/manifest/og-twitter.png">

                    </head>
<body data-barba="wrapper">
        <a href="#top" class="sr-only sr-only--focusable">
                    Skip to main content
            </a>

                        
                
        
        



<div
    class="
        preloader
        
        js-preloader        is-hidden    "
            aria-hidden="true"
    
        data-nosnippet

                            data-plugin="preloader"
>
    <div class="preloader__content ui-dark ui-background">

                <div class="preloader__card">
            <svg class="preloader__card-border svg-fix" width="240" height="360" viewBox="0 0 240 360" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M239 1H1V359H239V1Z" stroke="white" stroke-opacity="0.3"/>
                <path class="preloader__card-progress" d="M239 1H1V359H239V1Z" stroke="white"/>
            </svg>

            <svg class="icon icon-logo preloader__card-logo" width="673" height="87" aria-hidden="true"            viewBox="0 0 673 87"
            style="--icon-width: 673; --icon-height: 87;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo"></use></svg>
            <p class="text-small text-center leading-trim">
                The Luxury <br>of Experience
            </p>
        </div>

                
    </div>
</div>

                    



<div
    class="
        preloader
        
        js-preloader            "
    
        data-nosnippet

                            data-plugin="preloader"                        data-preloader-animation-name-out="preloader-slide-out"
>
    <div class="preloader__content ui-dark">

                <div class="preloader__card">
            <svg class="preloader__card-border svg-fix" width="240" height="360" viewBox="0 0 240 360" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M239 1H1V359H239V1Z" stroke="white" stroke-opacity="0.3"/>
                <path class="preloader__card-progress" d="M239 1H1V359H239V1Z" stroke="white"/>
            </svg>

            <svg class="icon icon-logo preloader__card-logo" width="673" height="87" aria-hidden="true"            viewBox="0 0 673 87"
            style="--icon-width: 673; --icon-height: 87;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo"></use></svg>
            <p class="text-small text-center leading-trim">
                The Luxury <br>of Experience
            </p>
        </div>

                            <p class="preloader__content__cover h1">
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            </p>
        
    </div>
</div>
        
    
        
            
        <div
        class="page-content-wrapper ui-light-background"
        data-barba="container" data-barba-namespace="page"

        data-plugin="
                        
                                "
    >
                <div class="page-content-wrapper__inner js-page-content-wrapper">
                            

    

    


<header
    class="header is-hidden--print header--sticky ui-dark"
                            data-plugin="themed "
>
    <div class="header__content row row--top-xs">
        <div class="col col--xs-3 col--md-9 py-layout pl-layout">
                                        
                        
        
                                                                      
                        

        
    
        
        
        
    <a
        class="btn header__logo header__logo--landing btn--link btn--link-static"
                                                href="#top"
                                                                    aria-label="Scroll to top of the page"
                            data-plugin="parallax"
                                                            data-parallax-pattern="logo"
                            >
        
        <span class="btn__content">
            
                                    
                                                                    <svg class="icon icon-logo" width="673" height="87" aria-hidden="true"            viewBox="0 0 673 87"
            style="--icon-width: 673; --icon-height: 87;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo"></use></svg>
                    <span class="header__logo-zebra is-hidden--sm-down">
                        <svg class="icon icon-logo" width="673" height="87" aria-hidden="true"            viewBox="0 0 673 87"
            style="--icon-width: 673; --icon-height: 87;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo"></use></svg>
                    </span>
                
                                    </span>
    </a>
                    </div>
        <div class="col col--xs-1 col--md-3 group group--nowrap group--none py-layout pr-layout">
            <div class="header__item is-hidden--sm-down">
                <div
                                            data-reveal="intro-menu"
                        data-reveal-delay="1600"
                        data-reveal-distance="0"
                                    >
                            
        
                                                                      
            

                    
    
                    
        
        
    <a
        class="btn btn--link btn--link-static btn--text-small btn--clone"
                                                href="/apartments"
                                                                data-plugin=" button"
                            data-button-clone-content="true"
                                                    data-ajax-page-ignore="true"
                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Choose an Apartment

                                    </span>
            
                    </span>
    </a>
                </div>
            </div>
                        <div class="header__item is-hidden--sm-down">
                            </div>
            <div class="header__item">
                <div
                                            data-reveal="fade-in block"
                        data-reveal-delay="1600"
                        data-reveal-distance="0"
                                    >
                                    
                            
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn header__burger btn--link btn--link-static"
                                                href="#menu"
                                                                    aria-label="открыть меню"
                                                    >
        
        <span class="btn__content">
            
                                    
                                                                        <svg class="svg-fix" width="60" height="8" viewBox="0 0 60 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g>
                                <path d="M0 0.65H60" stroke="currentColor" stroke-width="1.3"/>
                                <path d="M0 0.65H60" stroke="currentColor" stroke-width="1.3"/>
                            </g>
                            <g>
                                <path d="M0 6.65H60" stroke="currentColor" stroke-width="1.3"/>
                                <path d="M0 6.65H60" stroke="currentColor" stroke-width="1.3"/>
                            </g>
                        </svg>

                    
                                    </span>
    </a>
                </div>
            </div>
        </div>
    </div>
</header>
            
                                            <div class="page-content js-page-content">
                    <main id="top">
                            

<section
    class="section section--full-height ui-dark ui-background"
    data-scroll-section
    data-scroll-snap-point='[
        { "viewport": 0, "element": 0 }
    ]'
    data-themed-class="ui-dark"
    data-plugin="history"
    id=""
>
    <div class="sticky sticky--under-next sticky--full-height"
        data-plugin="parallax"
        data-parallax-pattern="sectionOutTiny"
        data-parallax-enable-mq="null"
    >
        <div class="intro sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
            data-reveal-group
        >
            <div
                class="intro__background"
                data-plugin="contentAnimation"
                data-content-animation-animations='{
                    "changeShow": {"name": "fadeIn", "duration": 2}
                }'
                data-content-animation-plugins="controller events counter autoplay"
                data-content-animation-autoplay-delay="7"
            >
                <div class="content-animation background background--cover">
                    <div
                        data-content-animation-item="intro-night"
                        class="ui-background background background--cover"
                        aria-hidden="false"
                    >
                        
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_intro_bg_xxxl/uploads/39/6_final_1_1777284604.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1709" height="1388">                    <source srcset="https://zorge9.estate/media/cache/homepage_intro_bg_xxl/uploads/39/6_final_1_1777284604.webp" media="(min-width: 1440px) and (min-height: 700px)" width="1344" height="1092">                    <source srcset="https://zorge9.estate/media/cache/homepage_intro_bg_md/uploads/39/6_final_1_1777284604.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="960" height="780">
        <img
            src="https://zorge9.estate/media/cache/homepage_intro_bg_xs/uploads/39/6_final_4_1777386791.webp"                    alt=""                            width="360" height="480"            draggable="false"
        >
    </picture>

            
                    </div>
                    <div
                        data-content-animation-item="intro-day"
                        class="ui-background background background--cover is-hidden"
                        aria-hidden="true"
                    >
                        
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_intro_bg_xxxl/uploads/39/6_final_1777284542.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1709" height="1388">                    <source srcset="https://zorge9.estate/media/cache/homepage_intro_bg_xxl/uploads/39/6_final_1777284542.webp" media="(min-width: 1440px) and (min-height: 700px)" width="1344" height="1092">                    <source srcset="https://zorge9.estate/media/cache/homepage_intro_bg_md/uploads/39/6_final_1777284542.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="960" height="780">
        <img
            src="https://zorge9.estate/media/cache/homepage_intro_bg_xs/uploads/39/6_final_5_1777386791.webp"                    alt=""                            width="360" height="480"            draggable="false"
        >
    </picture>

            
                    </div>
                </div>
            </div>
                        <div class="intro__back ui-background is-hidden--sm-down" data-reveal="intro-back" data-reveal-delay="0" data-reveal-distance="0" data-reveal-visible></div>
                        
    
    
    
    
    <picture class=" intro__decor img-full"                        data-reveal="intro-decor"                        data-reveal-distance="0"        draggable="false"    >                    <source srcset="/assets/images/media/landing/1.intro/decor@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="1282" height="1388">                    <source srcset="/assets/images/media/landing/1.intro/decor@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1008" height="1092">                    <source srcset="/assets/images/media/landing/1.intro/decor@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            src="assets/images/media/landing/1.intro/decor-xs.webp"                    alt=""                            width="360" height="400"            draggable="false"
        >
    </picture>

            
            <div class="intro__content row">
                <div class="col col--xs-3 col--md-4 pl-layout pr-layout:md py-layout">
                    <h1 class="sr-only">Zorge 9 - House with Privileges</h1>
                    <p class="h2 leading-trim mb-1.5 mb-layout:xxl"
                                            data-reveal="text" data-reveal-delay="1600" data-reveal-distance="0"
                                        >
                        Premium residence — the&nbsp;embodiment of&nbsp;your status
                    </p>
                    <div
                                            data-reveal="fade-in block" data-reveal-delay="1600" data-reveal-distance="0"
                                        >
                                
        
                                                                      
            

        
                
        
        
        
    <a
        class="btn btn--link btn--link-static btn--animate-icon"
                                                href="#about"
                                                                    aria-label="О проекте"
                                                    >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-long-arrow-down" width="14" height="41" aria-hidden="true"            viewBox="0 0 14 41"
            style="--icon-width: 14; --icon-height: 41;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-down" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-down"></use></svg>
                                                    <svg class="icon icon-long-arrow-down" width="14" height="41" aria-hidden="true"            viewBox="0 0 14 41"
            style="--icon-width: 14; --icon-height: 41;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-down" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-down"></use></svg>
                                            </span>
                                    </span>
    </a>
                    </div>
                </div>
            </div>
            <div
                class="intro__logo px-layout text-color-primary"
                data-reveal="intro-logo"
                data-reveal-delay="1600"
                data-reveal-distance="0"
            >
                <svg class="icon icon-logo" width="673" height="87" aria-hidden="true"            viewBox="0 0 673 87"
            style="--icon-width: 673; --icon-height: 87;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo"></use></svg>
            </div>
        </div>
    </div>
</section>
    
<section
    class="about section ui-dark ui-background"
    id="about"
    data-plugin="reveal"
    data-scroll-section
    data-scroll-snap-point='[
        { "viewport": 0, "element": 33.34 }
    ]'
>
    <div class="about__sticky sticky sticky--under-next sticky--under-previous">
        <div
            class="about__background sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
        >
            
    
    
    
    
    <picture class=" background background--cover img-full"        draggable="false"    >                    <source srcset="assets/images/media/landing/2.about/background@xxxl.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1920" height="1080">                    <source srcset="/assets/images/media/landing/2.about/background@xxl.webp" media="(min-width: 1440px) and (min-height: 700px)" width="1920" height="1080">                    <source srcset="/assets/images/media/landing/2.about/background@md.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1440" height="810">
        <img
            src="assets/images/media/landing/2.about/background@xs.webp"                    alt=""                            width="607" height="1080"            draggable="false"
        >
    </picture>

            
                
    
    
    <div                         class="background background--cover">
        <iframe
            style="--ratio: 1.7777777777778; --aspect-ratio: 1920 / 1080"                                    width="1920"                        height="1080"
            src="https://player.vimeo.com/video/1185877284?loop=1&amp;muted=1&amp;autoplay=1&amp;autopause=0&amp;background=1"
            allow="autoplay; encrypted-media"
            allowfullscreen
        ></iframe>
    </div>

        </div>
        <div
            class="about__content sticky__layer sticky__layer--sticky sticky__layer--top is-hidden--sm-down"
            data-scroll
            data-scroll-sticky
        >
            <div class="row">
                <div class="col col--xs-4 col--md-4 px-layout py-2 py-layout:md pr-0:md"
                    data-plugin="parallax"
                    data-parallax-pattern="about"
                >
                    <h2 class="h2 leading-trim" data-reveal="text" data-reveal-distance="0">
                        Life on&nbsp;Your<br />
Own Terms
                    </h2>
                </div>
                <div class="col col--xs-4 col--md-8 px-layout py-2 py-layout:md"
                    data-plugin="parallax"
                    data-parallax-pattern="about"
                >
                    <div class="group group--small group--right group--nowrap">
                        <div class="about__card">
                            <a
                                class="about-card card ui-dark ui-background btn-container"
                                href="#video-modal"
                                data-video-modal-video-id="https://player.vimeo.com/video/1185877284"
                                data-video-modal-video-width="1920"
                                data-video-modal-video-height="1080"
                            >
                                <p class="card__lt text-small leading-trim">
                                    About&nbsp;the&nbsp;Project
                                </p>
                                <div class="card__center">
                                            
        
                                                                      
            

        
                
        
        
        
    <span
        class="btn btn--link btn--link-static btn--animate-icon"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-play-lg" width="12" height="26" aria-hidden="true"            viewBox="0 0 12 26"
            style="--icon-width: 12; --icon-height: 26;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play-lg" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play-lg"></use></svg>
                                                    <svg class="icon icon-play-lg" width="12" height="26" aria-hidden="true"            viewBox="0 0 12 26"
            style="--icon-width: 12; --icon-height: 26;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play-lg" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play-lg"></use></svg>
                                            </span>
                                    </span>
    </span>
                                </div>
                            </a>
                        </div>
                        <div class="about__card">
                            <a class="about-card card ui-light ui-background btn-container" href="#offers-modal">
                                <p class="card__lt text-small leading-trim">
                                    Installment <br />
and Mortgage
                                </p>
                                <p class="card__center text-center h3 leading-trim">
                                    Special Offers
                                </p>
                                <div class="card__b text-center:md">
                                            
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-heading btn--underline btn--text-small"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Watch

                                            <span class="btn__underline"></span>
                                    </span>
            
                    </span>
    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="about__content sticky__layer sticky__layer--top is-hidden--md-up">
            <div class="row">
                <div class="col col--xs-4 col--md-4 px-layout py-2 py-layout:md pr-0:md">
                    <p class="h2 leading-trim" data-reveal="text" data-reveal-distance="0">
                        Life on&nbsp;Your<br />
Own Terms
                    </p>
                </div>
                <div class="col col--xs-4 col--md-8 px-layout py-2 py-layout:md">
                    <div class="group group--small group--right group--nowrap">
                        <div class="about__card">
                            <a
                                class="about-card card ui-dark ui-background btn-container"
                                href="#video-modal"
                                data-video-modal-video-id="https://player.vimeo.com/video/1185877284"
                                data-video-modal-video-width="1920"
                                data-video-modal-video-height="1080"
                            >
                                <p class="card__lt text-small leading-trim">
                                    About&nbsp;the&nbsp;Project
                                </p>
                                <div class="card__center">
                                            
        
                                                                      
            

        
                
        
        
        
    <span
        class="btn btn--link btn--link-static btn--animate-icon"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-play-lg" width="12" height="26" aria-hidden="true"            viewBox="0 0 12 26"
            style="--icon-width: 12; --icon-height: 26;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play-lg" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play-lg"></use></svg>
                                                    <svg class="icon icon-play-lg" width="12" height="26" aria-hidden="true"            viewBox="0 0 12 26"
            style="--icon-width: 12; --icon-height: 26;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play-lg" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play-lg"></use></svg>
                                            </span>
                                    </span>
    </span>
                                </div>
                            </a>
                        </div>
                        <div class="about__card">
                            <a class="about-card card ui-light ui-background btn-container" href="#offers-modal">
                                <p class="card__lt text-small leading-trim">
                                    Installment<br />
and Mortgage
                                </p>
                                <p class="card__center text-center h3 leading-trim">
                                    Special Offers
                                </p>
                                <div class="card__b text-center:md">
                                            
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-heading btn--underline btn--text-small"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Watch

                                            <span class="btn__underline"></span>
                                    </span>
            
                    </span>
    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    

<section
    id="location"
    class="location section section--no-overflow ui-background pb-2 pb-4:md"
    data-scroll-section
    data-plugin="reveal history"
    data-scroll-snap-point='[
        { "viewport": 0, "element": 0, "scrollable": true }
    ]'
>
    <h2 class="sr-only">Location</h2>
    <div class="row">
        <div class="col col--xs-4 col--md-9 offset--md-3">
            <div data-themed-class="ui-dark"></div>
            <div data-themed-class="ui-dark" data-themed-add-class="header__logo--zebra">
                
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/3.location/hero@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221922%22%20height=%221388%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201922%201388%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1922" height="1388">                    <source
        data-srcset="/assets/images/media/landing/3.location/hero@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221512%22%20height=%221092%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201512%201092%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1512" height="1092">                    <source
        data-srcset="/assets/images/media/landing/3.location/hero@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221080%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201080%20780%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1080" height="780">
        <img
            data-src="assets/images/media/landing/3.location/hero-xs.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22360%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20360%22%3E%3C/svg%3E"                    alt=""                            width="360" height="360"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/3.location/hero@xxxl.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1922" height="1388">                    <source srcset="/assets/images/media/landing/3.location/hero@xxxl.webp" media="(min-width: 1440px) and (min-height: 700px)" width="1512" height="1092">                    <source srcset="/assets/images/media/landing/3.location/hero@xxxl.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1080" height="780">
        <img
            src="assets/images/media/landing/3.location/hero-xs.webp"                    alt=""                            width="360" height="360"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
            </div>
            <div data-themed-class="ui-light"></div>
            <p class="text-small leading-trim px-1 pl-0:md mt-1 mt-0.66:md">
                <span class="is-hidden--md-down">
                    Privilege&nbsp;of&nbsp;Location
                </span>
                <span class="is-hidden--md-up">
                    Privilege&nbsp;<br />
of&nbsp;Location
                </span>
            </p>
            <p class="h2 leading-trim px-1 pl-0:md mt-2" data-reveal="text">
                <span class="text-offset text-offset--3 is-hidden--sm-down"></span>
                Сity skyscrapers and iconic landmarks are at&nbsp;your feet. The&nbsp;capital unfolds before&nbsp;you like&nbsp;a&nbsp;grand bouquet of&nbsp;endless opportunities.
            </p>
        </div>
    </div>
    <div class="mt-4.5 mt-8:md"
        data-plugin="contentAnimation"
        data-content-animation-animations='{
            "changeShow": {"name": "fadeIn"},
            "changeHide": {"name": "fadeOut"}
        }'
        data-content-animation-controller-plugins=""
    >
        <div class="row row--bottom-md">
            <div class="col col--xs-4 col--md-8 px-1 container-h-vars">
                            </div>
            <div class="col col--xs-4 col--md-4 px-1 pb-1 is-hidden--sm-down">
                <p class="h1 text-right leading-trim" data-reveal="text">
                    Location
                </p>
            </div>
        </div>
        <hr class="location__line">
        <div class="px-1 mt-1 container-h-vars js-location-container">
            <div class="content-animation">
                                    <div
                        data-content-animation-item="location-1"
                        class="ui-background "
                        aria-hidden="false"
                    >
                        <div
                            class="location__carousel carousel carousel--md-up carousel--not-ready"
                            data-plugin="carousel"
                            data-carousel-enable-mq="md-up"
                            data-carousel-breakpoints='{
                                "xs-up": {"slidesPerView": 1},
                                "md-up": {"slidesPerView": 2}
                            }'
                            data-carousel-effects="imageMove"
                        >
                            <div class="carousel__list">
                                <ul class="carousel__list__inner mobile-scrollable js-carousel-list">
                                                                        <li class="carousel__list__item mobile-scrollable__item js-carousel-item ">
                                        

<div class="location-card js-picture-crop card ui-dark">
    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js location-card__image background background--cover parallax-image-move js-picture-wrapper"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_8_1777287547.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221219%22%20height=%22854%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201219%20854%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_8_1777287547.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22959%22%20height=%22672%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20959%20672%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_8_1777287547.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22685%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20685%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_8_1777287547.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22640%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20640%20480%22%3E%3C/svg%3E"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" location-card__image background background--cover parallax-image-move js-picture-wrapper"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_8_1777287547.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_8_1777287547.webp" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_8_1777287547.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_8_1777287547.webp"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
    <div class="card__lb">
        <p class="card__title text-small leading-trim">
            
        </p>
        <p class="h2 leading-trim mt-0.66">
            Walking park
        </p>
    </div>
</div>
                                    </li>
                                                                        <li class="carousel__list__item mobile-scrollable__item js-carousel-item is-hidden--not-ready">
                                        

<div class="location-card js-picture-crop card ui-dark">
    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js location-card__image background background--cover parallax-image-move js-picture-wrapper"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_9_1777287547.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221219%22%20height=%22854%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201219%20854%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_9_1777287547.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22959%22%20height=%22672%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20959%20672%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_9_1777287547.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22685%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20685%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_9_1777287547.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22640%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20640%20480%22%3E%3C/svg%3E"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" location-card__image background background--cover parallax-image-move js-picture-wrapper"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_9_1777287547.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_9_1777287547.webp" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_9_1777287547.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_9_1777287547.webp"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
    <div class="card__lb">
        <p class="card__title text-small leading-trim">
            
        </p>
        <p class="h2 leading-trim mt-0.66">
            School
        </p>
    </div>
</div>
                                    </li>
                                                                        <li class="carousel__list__item mobile-scrollable__item js-carousel-item is-hidden--not-ready">
                                        

<div class="location-card js-picture-crop card ui-dark">
    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js location-card__image background background--cover parallax-image-move js-picture-wrapper"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_10_1777287548.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221219%22%20height=%22854%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201219%20854%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_10_1777287548.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22959%22%20height=%22672%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20959%20672%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_10_1777287548.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22685%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20685%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_10_1777287548.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22640%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20640%20480%22%3E%3C/svg%3E"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" location-card__image background background--cover parallax-image-move js-picture-wrapper"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_10_1777287548.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_10_1777287548.webp" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_10_1777287548.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_10_1777287548.webp"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
    <div class="card__lb">
        <p class="card__title text-small leading-trim">
            
        </p>
        <p class="h2 leading-trim mt-0.66">
            Sport center
        </p>
    </div>
</div>
                                    </li>
                                                                        <li class="carousel__list__item mobile-scrollable__item js-carousel-item is-hidden--not-ready">
                                        

<div class="location-card js-picture-crop card ui-dark">
    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js location-card__image background background--cover parallax-image-move js-picture-wrapper"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_11_1777287548.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221219%22%20height=%22854%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201219%20854%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_11_1777287548.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22959%22%20height=%22672%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20959%20672%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_11_1777287548.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22685%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20685%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_11_1777287548.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22640%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20640%20480%22%3E%3C/svg%3E"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" location-card__image background background--cover parallax-image-move js-picture-wrapper"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_11_1777287548.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_11_1777287548.webp" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_11_1777287548.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_11_1777287548.webp"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
    <div class="card__lb">
        <p class="card__title text-small leading-trim">
            
        </p>
        <p class="h2 leading-trim mt-0.66">
            Embankment
        </p>
    </div>
</div>
                                    </li>
                                                                        <li class="carousel__list__item mobile-scrollable__item js-carousel-item is-hidden--not-ready">
                                        

<div class="location-card js-picture-crop card ui-dark">
    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js location-card__image background background--cover parallax-image-move js-picture-wrapper"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_12_1777287546.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221219%22%20height=%22854%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201219%20854%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_12_1777287546.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22959%22%20height=%22672%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20959%20672%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_12_1777287546.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22685%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20685%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_12_1777287546.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22640%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20640%20480%22%3E%3C/svg%3E"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" location-card__image background background--cover parallax-image-move js-picture-wrapper"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxxl/uploads/39/image_12_1777287546.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1219" height="854">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_xxl/uploads/39/image_12_1777287546.webp" media="(min-width: 1440px) and (min-height: 700px)" width="959" height="672">                    <source srcset="https://zorge9.estate/media/cache/homepage_location_cards_img_md/uploads/39/image_12_1777287546.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="685" height="480">
        <img
            src="https://zorge9.estate/media/cache/homepage_location_cards_img_xs/uploads/39/image_12_1777287546.webp"                    alt=""                            width="640" height="480"                                        data-plugin="parallax"                        data-parallax-measure-selector=".js-location-container"                        data-parallax-clamp="true"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-16&#x25;&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0&#x25;&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
    <div class="card__lb">
        <p class="card__title text-small leading-trim">
            
        </p>
        <p class="h2 leading-trim mt-0.66">
            Restaurants
        </p>
    </div>
</div>
                                    </li>
                                    
                                </ul>
                            </div>
                            <div
                                class="location__carousel-nav ui-dark is-hidden--sm-down is-hidden--no-hover"
                                data-plugin="cursor"
                                data-cursor-show-default-cursor="true"
                            >
                                        
        
                                                                      
            

        
    
        
        
        
    <button
        class="btn location__carousel-link btn--link js-carousel-prev is-disabled"
                                                            aria-label="Previous item"
                                                    >
        
        <span class="btn__content">
            
                                    
                    </span>
    </button>
                                        
        
                                                                      
            

        
    
        
        
        
    <button
        class="btn location__carousel-link btn--link js-carousel-next"
                                                            aria-label="Next item"
                                                    >
        
        <span class="btn__content">
            
                                    
                    </span>
    </button>
                                <div class="cursor cursor--arrow js-cursor-button">
                                            
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn cursor__button cursor__button--left btn--outline js-carousel-prev is-decorative"
                                                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-long-arrow-left" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left"></use></svg>
                                            </span>
                                    </span>
    </span>
                                            
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn cursor__button cursor__button--right btn--outline js-carousel-next is-decorative"
                                                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-long-arrow-right" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                            </div>
        </div>
    </div>
</section>
    





        
                                                    
                    
            

<section
    class="map section ui-dark ui-background"
    data-scroll-section
    data-themed-class="ui-dark"
    >
    <div
        class="sticky"
        id="map"
        data-plugin="parallax"
        data-parallax-pattern="sectionOutHalf"
        data-parallax-enable-mq="md-up"
    >
        <div
            class="sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
            data-scroll-target="#map"
        >
            <h2 class="sr-only">Map of the area</h2>
            <div class="map__container"
                data-plugin="mapCenter"
            >
                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn map__swipe btn--swipe btn--square is-decorative is-hidden--md-up"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-scroll" width="42" height="14" aria-hidden="true"            viewBox="0 0 42 14"
            style="--icon-width: 42; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#scroll" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#scroll"></use></svg>
                                            </span>
                                    </span>
    </span>
                <div class="map__mobile-anchor is-hidden--md-up" data-anchor="mobile"></div>

                <div class="map__scrollable js-map-scrollable">
                    <div
                        class="plan map__plan"
                        data-plugin="plan"
                        data-plan-plans="&#x5B;&#x7B;&quot;svg&quot;&#x3A;&quot;&#x5C;&#x2F;assets&#x5C;&#x2F;images&#x5C;&#x2F;media&#x5C;&#x2F;landing&#x5C;&#x2F;4.map&#x5C;&#x2F;map.svg&#x3F;v&#x3D;1779376336&quot;,&quot;img&quot;&#x3A;&quot;&#x5C;&#x2F;assets&#x5C;&#x2F;images&#x5C;&#x2F;media&#x5C;&#x2F;landing&#x5C;&#x2F;4.map&#x5C;&#x2F;map-image.svg&#x3F;v&#x3D;1779376336&quot;,&quot;config&quot;&#x3A;&#x7B;&quot;tooltips&quot;&#x3A;&#x7B;&quot;placement&quot;&#x3A;&quot;top-start&quot;,&quot;parentSelector&quot;&#x3A;&quot;.map__container&quot;&#x7D;&#x7D;,&quot;items&quot;&#x3A;&#x5B;&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;group&quot;&#x3A;1,&quot;title&quot;&#x3A;&quot;Walking&#x20;park&quot;,&quot;time&quot;&#x3A;&quot;&quot;,&quot;index&quot;&#x3A;1,&quot;image&quot;&#x3A;&#x7B;&quot;xs&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xs&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_28_1777363545.webp&quot;,&quot;width&quot;&#x3A;180,&quot;height&quot;&#x3A;179&#x7D;,&quot;md&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_md&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_28_1777363545.webp&quot;,&quot;width&quot;&#x3A;298,&quot;height&quot;&#x3A;219&#x7D;,&quot;xxl&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xxl&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_28_1777363545.webp&quot;,&quot;width&quot;&#x3A;417,&quot;height&quot;&#x3A;306&#x7D;,&quot;xxxl&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xxxl&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_28_1777363545.webp&quot;,&quot;width&quot;&#x3A;530,&quot;height&quot;&#x3A;389&#x7D;&#x7D;&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-point&quot;,&quot;anchor&quot;&#x3A;&quot;park-1&quot;&#x7D;&#x5D;,&quot;state&quot;&#x3A;&#x7B;&quot;hidden&quot;&#x3A;false&#x7D;,&quot;tooltips&quot;&#x3A;&#x5B;&#x7B;&quot;anchor&quot;&#x3A;&quot;park-1&quot;,&quot;class&quot;&#x3A;&quot;is-hidden--sm-down&quot;,&quot;template&quot;&#x3A;&quot;map-tooltip-info&quot;&#x7D;,&#x7B;&quot;anchor&quot;&#x3A;&quot;&#x3A;root&#x20;mobile&quot;,&quot;class&quot;&#x3A;&quot;is-hidden--md-up&quot;,&quot;template&quot;&#x3A;&quot;map-tooltip-info-mobile&quot;,&quot;parentSelector&quot;&#x3A;&quot;.sticky&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;group&quot;&#x3A;1,&quot;title&quot;&#x3A;&quot;embankment&quot;,&quot;time&quot;&#x3A;&quot;15&#x20;min&#x20;walk&quot;,&quot;index&quot;&#x3A;2,&quot;image&quot;&#x3A;&#x7B;&quot;xs&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xs&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_11_1777287548.webp&quot;,&quot;width&quot;&#x3A;180,&quot;height&quot;&#x3A;179&#x7D;,&quot;md&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_md&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_11_1777287548.webp&quot;,&quot;width&quot;&#x3A;298,&quot;height&quot;&#x3A;219&#x7D;,&quot;xxl&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xxl&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_11_1777287548.webp&quot;,&quot;width&quot;&#x3A;417,&quot;height&quot;&#x3A;306&#x7D;,&quot;xxxl&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xxxl&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_11_1777287548.webp&quot;,&quot;width&quot;&#x3A;530,&quot;height&quot;&#x3A;389&#x7D;&#x7D;&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-point&quot;,&quot;anchor&quot;&#x3A;&quot;park-2&quot;&#x7D;&#x5D;,&quot;state&quot;&#x3A;&#x7B;&quot;hidden&quot;&#x3A;false&#x7D;,&quot;tooltips&quot;&#x3A;&#x5B;&#x7B;&quot;anchor&quot;&#x3A;&quot;park-2&quot;,&quot;class&quot;&#x3A;&quot;is-hidden--sm-down&quot;,&quot;template&quot;&#x3A;&quot;map-tooltip-info&quot;&#x7D;,&#x7B;&quot;anchor&quot;&#x3A;&quot;&#x3A;root&#x20;mobile&quot;,&quot;class&quot;&#x3A;&quot;is-hidden--md-up&quot;,&quot;template&quot;&#x3A;&quot;map-tooltip-info-mobile&quot;,&quot;parentSelector&quot;&#x3A;&quot;.sticky&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;group&quot;&#x3A;1,&quot;title&quot;&#x3A;&quot;Sport&#x20;center&quot;,&quot;time&quot;&#x3A;&quot;&quot;,&quot;index&quot;&#x3A;3,&quot;image&quot;&#x3A;&#x7B;&quot;xs&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xs&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_27_1777363545.webp&quot;,&quot;width&quot;&#x3A;180,&quot;height&quot;&#x3A;179&#x7D;,&quot;md&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_md&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_27_1777363545.webp&quot;,&quot;width&quot;&#x3A;298,&quot;height&quot;&#x3A;219&#x7D;,&quot;xxl&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xxl&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_27_1777363545.webp&quot;,&quot;width&quot;&#x3A;417,&quot;height&quot;&#x3A;306&#x7D;,&quot;xxxl&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xxxl&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_27_1777363545.webp&quot;,&quot;width&quot;&#x3A;530,&quot;height&quot;&#x3A;389&#x7D;&#x7D;&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-point&quot;,&quot;anchor&quot;&#x3A;&quot;park-3&quot;&#x7D;&#x5D;,&quot;state&quot;&#x3A;&#x7B;&quot;hidden&quot;&#x3A;false&#x7D;,&quot;tooltips&quot;&#x3A;&#x5B;&#x7B;&quot;anchor&quot;&#x3A;&quot;park-3&quot;,&quot;class&quot;&#x3A;&quot;is-hidden--sm-down&quot;,&quot;template&quot;&#x3A;&quot;map-tooltip-info&quot;&#x7D;,&#x7B;&quot;anchor&quot;&#x3A;&quot;&#x3A;root&#x20;mobile&quot;,&quot;class&quot;&#x3A;&quot;is-hidden--md-up&quot;,&quot;template&quot;&#x3A;&quot;map-tooltip-info-mobile&quot;,&quot;parentSelector&quot;&#x3A;&quot;.sticky&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;group&quot;&#x3A;1,&quot;title&quot;&#x3A;&quot;shopping&#x20;mall&quot;,&quot;time&quot;&#x3A;&quot;&quot;,&quot;index&quot;&#x3A;4,&quot;image&quot;&#x3A;&#x7B;&quot;xs&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xs&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_26_1777363545.webp&quot;,&quot;width&quot;&#x3A;180,&quot;height&quot;&#x3A;179&#x7D;,&quot;md&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_md&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_26_1777363545.webp&quot;,&quot;width&quot;&#x3A;298,&quot;height&quot;&#x3A;219&#x7D;,&quot;xxl&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xxl&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_26_1777363545.webp&quot;,&quot;width&quot;&#x3A;417,&quot;height&quot;&#x3A;306&#x7D;,&quot;xxxl&quot;&#x3A;&#x7B;&quot;src&quot;&#x3A;&quot;https&#x3A;&#x5C;&#x2F;&#x5C;&#x2F;zorge9.estate&#x5C;&#x2F;media&#x5C;&#x2F;cache&#x5C;&#x2F;homepage_map_pin_img_xxxl&#x5C;&#x2F;uploads&#x5C;&#x2F;39&#x5C;&#x2F;image_26_1777363545.webp&quot;,&quot;width&quot;&#x3A;530,&quot;height&quot;&#x3A;389&#x7D;&#x7D;&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-point&quot;,&quot;anchor&quot;&#x3A;&quot;park-4&quot;&#x7D;&#x5D;,&quot;state&quot;&#x3A;&#x7B;&quot;hidden&quot;&#x3A;false&#x7D;,&quot;tooltips&quot;&#x3A;&#x5B;&#x7B;&quot;anchor&quot;&#x3A;&quot;park-4&quot;,&quot;class&quot;&#x3A;&quot;is-hidden--sm-down&quot;,&quot;template&quot;&#x3A;&quot;map-tooltip-info&quot;&#x7D;,&#x7B;&quot;anchor&quot;&#x3A;&quot;&#x3A;root&#x20;mobile&quot;,&quot;class&quot;&#x3A;&quot;is-hidden--md-up&quot;,&quot;template&quot;&#x3A;&quot;map-tooltip-info-mobile&quot;,&quot;parentSelector&quot;&#x3A;&quot;.sticky&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;title&quot;&#x3A;&quot;Polezhaevskaya,&lt;br&#x20;&#x5C;&#x2F;&gt;&#x5C;r&#x5C;nKhoroshevskaya&quot;,&quot;time&quot;&#x3A;&quot;7&#x20;min&#x20;walk&quot;&#x7D;,&quot;state&quot;&#x3A;&#x7B;&quot;disabled&quot;&#x3A;false&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-metro&quot;,&quot;anchor&quot;&#x3A;&quot;label-metro-1&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;title&quot;&#x3A;&quot;Khoroshevo&quot;,&quot;time&quot;&#x3A;&quot;10&#x20;min&#x20;walk&quot;&#x7D;,&quot;state&quot;&#x3A;&#x7B;&quot;disabled&quot;&#x3A;false&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-metro&quot;,&quot;anchor&quot;&#x3A;&quot;label-metro-2&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;title&quot;&#x3A;&quot;Zorge&quot;,&quot;time&quot;&#x3A;&quot;7&#x20;min&#x20;walk&quot;&#x7D;,&quot;state&quot;&#x3A;&#x7B;&quot;disabled&quot;&#x3A;false&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-metro&quot;,&quot;anchor&quot;&#x3A;&quot;label-metro-3&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;title&quot;&#x3A;&quot;Oktiabrskoe&#x20;Pole&quot;,&quot;time&quot;&#x3A;&quot;21&#x20;min&#x20;walk&quot;&#x7D;,&quot;state&quot;&#x3A;&#x7B;&quot;disabled&quot;&#x3A;false&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-metro&quot;,&quot;anchor&quot;&#x3A;&quot;label-metro-4&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;title&quot;&#x3A;&quot;Panfilovskaya&quot;,&quot;time&quot;&#x3A;&quot;24&#x20;min&#x20;walk&quot;&#x7D;,&quot;state&quot;&#x3A;&#x7B;&quot;disabled&quot;&#x3A;false&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-metro&quot;,&quot;anchor&quot;&#x3A;&quot;label-metro-5&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;title&quot;&#x3A;&quot;historical&#x20;park&quot;,&quot;rotation&quot;&#x3A;0&#x7D;,&quot;state&quot;&#x3A;&#x7B;&quot;disabled&quot;&#x3A;false&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-place&quot;,&quot;placement&quot;&#x3A;&quot;center&quot;,&quot;mainAxis&quot;&#x3A;false,&quot;anchor&quot;&#x3A;&quot;label-fili-park&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;title&quot;&#x3A;&quot;landscape&#x20;park&quot;,&quot;rotation&quot;&#x3A;0&#x7D;,&quot;state&quot;&#x3A;&#x7B;&quot;disabled&quot;&#x3A;false&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-place&quot;,&quot;placement&quot;&#x3A;&quot;center&quot;,&quot;mainAxis&quot;&#x3A;false,&quot;anchor&quot;&#x3A;&quot;label-pine-forest&quot;&#x7D;&#x5D;&#x7D;,&#x7B;&quot;data&quot;&#x3A;&#x7B;&quot;title&quot;&#x3A;&quot;&quot;,&quot;rotation&quot;&#x3A;0&#x7D;,&quot;state&quot;&#x3A;&#x7B;&quot;disabled&quot;&#x3A;false&#x7D;,&quot;markers&quot;&#x3A;&#x5B;&#x7B;&quot;template&quot;&#x3A;&quot;map-marker-house&quot;,&quot;placement&quot;&#x3A;&quot;center&quot;,&quot;mainAxis&quot;&#x3A;false,&quot;anchor&quot;&#x3A;&quot;label-house&quot;&#x7D;&#x5D;&#x7D;&#x5D;&#x7D;&#x5D;"
                        data-plan-filters-filter-selector=":root .js-plan-map-filters"
                    >
                                                <script type="text/template" data-template-name="map-marker-point" data-template-variable="item">
                            <div class="plan-marker plan-marker--point <%- item.class || '' %> <%- item.stateClass %>">
                                <div class="plan-marker__content">
                                            
        
                                                                      
            

        
    
        
        
        
    <button
        class="btn btn--square btn--marker-point btn--text-small"
                                                            aria-label=""
                                                    >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    &lt;%= item.index %&gt;

                                    </span>
            
                    </span>
    </button>
                                </div>
                            </div>
                        </script>

                        <script type="text/template" data-template-name="map-marker-place" data-template-variable="item">
                            <div class="plan-marker plan-marker--place <%- item.class || '' %> <%- item.stateClass %>">
                                <div class="plan-marker__content">
                                    <div class="plan-marker__text text-small leading-trim"><%= item.title %></div>
                                </div>
                            </div>
                        </script>

                        <script type="text/template" data-template-name="map-marker-metro" data-template-variable="item">
                            <div class="plan-marker plan-marker--metro <%- item.class || '' %> <%- item.stateClass %> is-decorative">
                                <div class="plan-marker__content">
                                            
        
                                                                      
            

        
    
        
        
        
    <button
        class="btn btn--square btn--marker-metro btn--sm"
                                                            aria-label=""
                                                    >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-map-metro" width="10" height="10" aria-hidden="true"            viewBox="0 0 10 10"
            style="--icon-width: 10; --icon-height: 10;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#map-metro" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#map-metro"></use></svg>
                                            </span>
                                    </span>
    </button>
                                </div>
                            </div>
                        </script>

                        <script type="text/template" data-template-name="map-marker-house" data-template-variable="item">
                            <div class="plan-marker plan-marker--house <%- item.class || '' %> <%- item.stateClass %>">
                                <div class="plan-marker__content">
                                    
    
    
    <img class="map__logo svg-fix " alt=""
        draggable="false"                                    width="60"                        height="60"
                src="/assets/images/media/landing/4.map/map-logo.svg"    >

        
                                </div>
                            </div>
                        </script>

                                                <script type="text/template" data-template-name="map-tooltip-info" data-template-variable="item">
                            <div class="tooltip tooltip--map-info <%- item.class %> <%- item.stateClass %> ui-dark" role="tooltip">
                                <div class="tooltip__animation">
                                    <div class="tooltip__content">
                                        <div class="tooltip__close is-hidden--hover">
                                                    
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--outline btn--outline-secondary btn--square js-tooltip-close"
                                                                                                                                                        aria-label="Закрыть информацию"
                                                    tabindex="0"
                            role="button"
            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-close" width="18" height="16" aria-hidden="true"            viewBox="0 0 18 16"
            style="--icon-width: 18; --icon-height: 16;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close"></use></svg>
                                            </span>
                                    </span>
    </a>
                                        </div>
                                        <span class="tooltip__marker leading-trim is-hidden--sm-down">
                                                    
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--square btn--marker-point btn--text-small is-active"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    &lt;%= item.index %&gt;

                                    </span>
            
                    </span>
    </span>
                                        </span>

                                        <%= picture(item.image, {alt: item.title, class: 'img-full'}) %>
                                        <div class="tooltip__capture">
                                            <p class="leading-trim"><%= item.title %></p>
                                            <p class="text-small text-color-smallest leading-trim"><%= item.time %></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </script>

                        <script type="text/template" data-template-name="map-tooltip-info-mobile" data-template-variable="item">
                            <div class="tooltip tooltip--map-info tooltip--map-info--mobile <%- item.class %> <%- item.stateClass %> ui-dark" role="tooltip">
                                <div class="tooltip__animation">
                                    <div class="tooltip__close">
                                                
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--outline btn--outline-secondary btn--square btn--lg js-tooltip-close"
                                                                                                                                                        aria-label="Закрыть информацию"
                                                    tabindex="0"
                            role="button"
            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-close" width="18" height="16" aria-hidden="true"            viewBox="0 0 18 16"
            style="--icon-width: 18; --icon-height: 16;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close"></use></svg>
                                            </span>
                                    </span>
    </a>
                                    </div>
                                    <div class="tooltip__content">
                                        <div class="tooltip__capture">
                                            <p class="leading-trim"><%= item.title %></p>
                                            <p class="text-small text-color-smallest leading-trim"><%= item.time %></p>
                                        </div>
                                        <%= picture(item.image, {alt: item.title, class: 'img-full'}) %>
                                    </div>
                                </div>
                            </div>
                        </script>

                        <script type="text/template" data-template-name="map-tooltip-metro" data-template-variable="item">
                            <div class="tooltip tooltip--map-info tooltip--map-info--metro <%- item.class %> <%- item.stateClass %> ui-dark" role="tooltip">
                                <div class="tooltip__animation">
                                    <div class="tooltip__content">
                                        <span class="tooltip__marker leading-trim is-hidden--sm-down">
                                                    
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--square btn--marker-metro btn--sm is-active"
                                        aria-label=""
                                                    >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-map-metro" width="10" height="10" aria-hidden="true"            viewBox="0 0 10 10"
            style="--icon-width: 10; --icon-height: 10;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#map-metro" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#map-metro"></use></svg>
                                            </span>
                                    </span>
    </span>
                                        </span>

                                        <div class="tooltip__capture">
                                            <p class="leading-trim"><%= item.title %></p>
                                            <p class="text-small text-color-smallest leading-trim"><%= item.time %></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </script>

                        <script type="text/template" data-template-name="map-tooltip-metro-mobile" data-template-variable="item">
                            <div class="tooltip tooltip--map-info tooltip--map-info--metro <%- item.class %> <%- item.stateClass %> ui-dark" role="tooltip">
                                <div class="tooltip__animation">
                                    <div class="tooltip__close">
                                                
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--outline btn--outline-secondary btn--square btn--lg js-tooltip-close"
                                                                                                                                                        aria-label="Закрыть информацию"
                                                    tabindex="0"
                            role="button"
            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-close" width="18" height="16" aria-hidden="true"            viewBox="0 0 18 16"
            style="--icon-width: 18; --icon-height: 16;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close"></use></svg>
                                            </span>
                                    </span>
    </a>
                                    </div>
                                    <div class="tooltip__content">
                                        <div class="tooltip__capture">
                                            <p class="leading-trim"><%= item.title %></p>
                                            <p class="text-small text-color-smallest leading-trim"><%= item.time %></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </script>

                    </div>
                </div>
            </div>
        </div>
            </div>
</section>
    
<section
    class="panorama section section--no-overflow-clip ui-dark ui-background"
    data-scroll-section
    data-themed-class="ui-dark"
    data-plugin="reveal"
>
    <div
        class="panorama__sticky sticky"
        data-plugin="parallax"
        data-parallax-enable-mq="null"
        data-parallax-clamp="true"
        data-parallax-measure-selector=".section"
        data-parallax-100-0='{"transform": "translateY(calc(var(--translate) * 1))"}'
        data-parallax-0-0='{"transform": "translateY(calc(var(--translate) * 0))"}'
    >
        
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_panorama_bg_xxxl/uploads/39/page_7_1_11_1_1777564172.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222563%22%20height=%222278%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202563%202278%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2563" height="2278">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_panorama_bg_xxl/uploads/39/page_7_1_11_1_1777564172.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222016%22%20height=%221792%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202016%201792%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="2016" height="1792">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_panorama_bg_md/uploads/39/page_7_1_11_1_1777564172.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221440%22%20height=%221280%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201440%201280%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1440" height="1280">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_panorama_bg_xs/uploads/39/page_7_1_11_1_1_1777564634.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22790%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20790%22%3E%3C/svg%3E"                    alt=""                            width="360" height="790"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover parallax-image-move"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_panorama_bg_xxxl/uploads/39/page_7_1_11_1_1777564172.webp" media="(min-width: 1920px) and (min-height: 700px)" width="2563" height="2278">                    <source srcset="https://zorge9.estate/media/cache/homepage_panorama_bg_xxl/uploads/39/page_7_1_11_1_1777564172.webp" media="(min-width: 1440px) and (min-height: 700px)" width="2016" height="1792">                    <source srcset="https://zorge9.estate/media/cache/homepage_panorama_bg_md/uploads/39/page_7_1_11_1_1777564172.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1440" height="1280">
        <img
            src="https://zorge9.estate/media/cache/homepage_panorama_bg_xs/uploads/39/page_7_1_11_1_1_1777564634.webp"                    alt=""                            width="360" height="790"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
        
        <div class="panorama__content sticky__layer">
            <div class="row">
                <div class="col col--xs-4 col--md-2 mb-1 mb-0:md px-layout pr-0:md">
                    <h2 class="text-default leading-trim" data-reveal="text">
                        IT'S A WORLD THAT <br />
ADAPTS TO YOU
                    </h2>
                </div>
                <div class="col col--xs-4 col--md-12 col--order-first-md mb-1 mb-layout:md px-layout">
                    <hr>
                </div>
                <div class="col col--xs-4 col--md-6 offset--md-4 px-layout pl-0:md">
                    <p class="h2 leading-trim" data-reveal="text">
                        It is not just a&nbsp;trio of&nbsp;luxurious buildings and the&nbsp;premium service of&nbsp;a&nbsp;grand hotel. It is a&nbsp;home where reality plays by&nbsp;your rules and follows your desires.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
    

<section
    id="style"
    class="style section ui-light ui-background pb-2 pb-3:xxxl pb-2:xxxxl"
    data-scroll-section
    data-themed-class="ui-light"
    data-plugin="reveal history"
>
    <h2 class="sr-only">Architecture</h2>
    <div class="row mb-4 mb-3:md mb-4:xxl mb-5:xxxl mb-3:xxxxl">
        <div class="col col--xs-4 col--md-6 offset--md-6 px-layout pl-0:md mb-layout">
            <p class="h2 leading-trim" data-reveal="text">
                <span class="text-offset text-offset--2 is-hidden--sm-down"></span>
                Three buildings in&nbsp;the&nbsp;style of&nbsp;elegant New York skyscrapers reflect the&nbsp;perfect combination of&nbsp;sophistication and a&nbsp;modern approach to&nbsp;life.
            </p>
        </div>
        <div class="col col--xs-4 col--md-12 px-layout:md mb-layout">
            <div class="style__image-1">
                
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/image-1@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221619%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201619%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1619">                    <source
        data-srcset="assets/images/media/landing/6.style/image-1@xxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221274%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201274%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1274">                    <source
        data-srcset="assets/images/media/landing/6.style/image-1@md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22910%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20910%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="910">
        <img
            data-src="assets/images/media/landing/6.style/image-1-xs.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22320%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20320%22%3E%3C/svg%3E"                    alt=""                            width="360" height="320"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/image-1@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1619">                    <source srcset="/assets/images/media/landing/6.style/image-1@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1274">                    <source srcset="/assets/images/media/landing/6.style/image-1@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="910">
        <img
            src="assets/images/media/landing/6.style/image-1-xs.webp"                    alt=""                            width="360" height="320"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                            </div>
        </div>
        <div class="col col--xs-4 col--md-12 pl-layout">
            <p class="h2 leading-trim" data-reveal="text">
                Panoramic windows<br />
and architectural<br />
lighting
            </p>
        </div>
    </div>
    <div class="row row--bottom-md mb-3 mb-1:md mb-0:xxxxl">
        <div class="col col--xs-4 col--md-3 offset--md-3 is-hidden--sm-down">
            <div class="style__image-2">
                
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/image-2@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22623%22%20height=%22747%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20623%20747%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source
        data-srcset="assets/images/media/landing/6.style/image-2@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22490%22%20height=%22588%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20490%20588%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">
        <img
            data-src="assets/images/media/landing/6.style/image-2@md.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22350%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20350%20420%22%3E%3C/svg%3E"                    alt=""                            width="350" height="420"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/image-2@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source srcset="/assets/images/media/landing/6.style/image-2@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">
        <img
            src="assets/images/media/landing/6.style/image-2@md.webp?v=1779376336"                    alt=""                            width="350" height="420"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
            </div>
        </div>
        <div class="col col--xs-4 col--md-6 pr-layout is-hidden--sm-down">
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/image-3@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221228%22%20height=%221228%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201228%201228%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1228">                    <source
        data-srcset="assets/images/media/landing/6.style/image-3@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22966%22%20height=%22966%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20966%20966%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="966">
        <img
            data-src="assets/images/media/landing/6.style/image-3@md.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22690%22%20height=%22690%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20690%20690%22%3E%3C/svg%3E"                    alt=""                            width="690" height="690"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/image-3@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1228">                    <source srcset="/assets/images/media/landing/6.style/image-3@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="966">
        <img
            src="assets/images/media/landing/6.style/image-3@md.webp?v=1779376336"                    alt=""                            width="690" height="690"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
        </div>
        <div class="col col--xs-4 px-layout container-h-vars is-hidden--md-up">
            <ul class="style__scrollable mobile-scrollable">
                <li class="mobile-scrollable__item">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >
        <img
            data-src="assets/images/media/landing/6.style/image-2@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22380%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20380%22%3E%3C/svg%3E"                    alt=""                            width="320" height="380"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >
        <img
            src="assets/images/media/landing/6.style/image-2@xs.webp?v=1779376336"                    alt=""                            width="320" height="380"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </li>
                <li class="mobile-scrollable__item">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >
        <img
            data-src="assets/images/media/landing/6.style/image-3-xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22380%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20380%22%3E%3C/svg%3E"                    alt=""                            width="320" height="380"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >
        <img
            src="assets/images/media/landing/6.style/image-3-xs.webp?v=1779376336"                    alt=""                            width="320" height="380"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </li>
                            </ul>
        </div>
        <div class="col col--xs-4 col--md-4 offset--md-8 mt-4 mt-1:md px-layout">
            <p class="h2 text-right leading-trim" data-reveal="text">
                Premium<br />
materials
            </p>
        </div>
    </div>
    <div class="px-layout mb-4 mb-1:md">
        <div class="style__decor">
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(4vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-4vmin)&quot;}"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/decor/1@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221284%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201284%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/1@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221010%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201010%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/1@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22722%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20722%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            data-src="assets/images/media/landing/6.style/decor-xs/1.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22264%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20264%22%3E%3C/svg%3E"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(4vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-4vmin)&quot;}"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/decor/1@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source srcset="/assets/images/media/landing/6.style/decor/1@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source srcset="/assets/images/media/landing/6.style/decor/1@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            src="/assets/images/media/landing/6.style/decor-xs/1.webp?v=1779376336"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(8vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-8vmin)&quot;}"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/decor/2@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221284%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201284%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/2@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221010%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201010%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/2@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22722%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20722%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            data-src="assets/images/media/landing/6.style/decor-xs/2.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22264%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20264%22%3E%3C/svg%3E"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(8vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-8vmin)&quot;}"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/decor/2@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source srcset="/assets/images/media/landing/6.style/decor/2@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source srcset="/assets/images/media/landing/6.style/decor/2@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            src="assets/images/media/landing/6.style/decor-xs/2.webp?v=1779376336"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(12vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-12vmin)&quot;}"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/decor/3@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221284%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201284%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/3@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221010%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201010%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/3@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22722%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20722%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            data-src="assets/images/media/landing/6.style/decor-xs/3.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22264%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20264%22%3E%3C/svg%3E"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(12vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-12vmin)&quot;}"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/decor/3@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source srcset="/assets/images/media/landing/6.style/decor/3@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source srcset="/assets/images/media/landing/6.style/decor/3@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            src="assets/images/media/landing/6.style/decor-xs/3.webp?v=1779376336"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(16vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-16vmin)&quot;}"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/decor/4@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221284%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201284%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/4@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221010%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201010%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/4@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22722%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20722%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            data-src="/assets/images/media/landing/6.style/decor-xs/4.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22264%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20264%22%3E%3C/svg%3E"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(16vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-16vmin)&quot;}"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/decor/4@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source srcset="/assets/images/media/landing/6.style/decor/4@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source srcset="/assets/images/media/landing/6.style/decor/4@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            src="assets/images/media/landing/6.style/decor-xs/4.webp?v=1779376336"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(20vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-20vmin)&quot;}"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/decor/5@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221284%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201284%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/5@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221010%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201010%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/5@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22722%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20722%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            data-src="assets/images/media/landing/6.style/decor-xs/5.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22264%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20264%22%3E%3C/svg%3E"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(20vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-20vmin)&quot;}"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/decor/5@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source srcset="/assets/images/media/landing/6.style/decor/5@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source srcset="/assets/images/media/landing/6.style/decor/5@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            src="assets/images/media/landing/6.style/decor-xs/5.webp?v=1779376336"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(24vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-24vmin)&quot;}"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/decor/6@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221284%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201284%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/6@xxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221010%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201010%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/6@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22722%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20722%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            data-src="assets/images/media/landing/6.style/decor-xs/6.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22264%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20264%22%3E%3C/svg%3E"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(24vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-24vmin)&quot;}"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/decor/6@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source srcset="/assets/images/media/landing/6.style/decor/6@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source srcset="/assets/images/media/landing/6.style/decor/6@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            src="assets/images/media/landing/6.style/decor-xs/6.webp"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(28vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-28vmin)&quot;}"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/decor/7@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221284%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201284%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/7@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221010%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201010%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/7@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22722%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20722%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            data-src="assets/images/media/landing/6.style/decor-xs/7.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22264%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20264%22%3E%3C/svg%3E"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"                        data-parallax-100-0="{&quot;transform&quot;: &quot;translateY(28vmin)&quot;}"                        data-parallax-0-100="{&quot;transform&quot;: &quot;translateY(-28vmin)&quot;}"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/decor/7@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source srcset="/assets/images/media/landing/6.style/decor/7@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source srcset="/assets/images/media/landing/6.style/decor/7@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            src="images/media/landing/6.style/decor-xs/7.webp"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js style__decor-mirror background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;12vmin&#x29;&quot;,&quot;--mirror&quot;&#x3A;&quot;4&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-12vmin&#x29;&quot;,&quot;--mirror&quot;&#x3A;&quot;-4&quot;&#x7D;"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/decor/4-mirror@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221284%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201284%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/4-mirror@xxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221010%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201010%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source
        data-srcset="assets/images/media/landing/6.style/decor/4-mirror@md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22722%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20722%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            data-src="assets/images/media/landing/6.style/decor-xs/4-mirror.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22264%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20264%22%3E%3C/svg%3E"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" style__decor-mirror background background--cover"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".style__decor"                        data-parallax-enable-mq="null"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;12vmin&#x29;&quot;,&quot;--mirror&quot;&#x3A;&quot;4&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-12vmin&#x29;&quot;,&quot;--mirror&quot;&#x3A;&quot;-4&quot;&#x7D;"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/decor/4-mirror@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1284">                    <source srcset="/assets/images/media/landing/6.style/decor/4-mirror@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1010">                    <source srcset="/assets/images/media/landing/6.style/decor/4-mirror@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="722">
        <img
            src="/assets/images/media/landing/6.style/decor-xs/4-mirror.webp?v=1779376336"                    alt=""                            width="320" height="264"            draggable="false"
        >
    </picture>

            
        </noscript>
    
        </div>
    </div>
    <div class="row mb-1">
        <div class="col col--xs-4 col--md-6 col--xxxl-5 px-layout pr-0:md pr-3:xxxxl">
            <p class="leading-trim" data-reveal="text">
                Luxury is embodied in&nbsp;every detail of&nbsp;the&nbsp;finishing materials It is imprinted in&nbsp;the&nbsp;delicate pattern of&nbsp;the&nbsp;porcelain stoneware, fused into&nbsp;the&nbsp;gold of&nbsp;the&nbsp;frames, and interspersed in&nbsp;the&nbsp;crystal waterfall of&nbsp;the&nbsp;chandeliers.
            </p>
        </div>
    </div>
    <div class="row" data-themed-class="ui-dark">
        <div class="col col--xs-4 col--md-6 pl-layout is-hidden--sm-down">
            <div class="style__image-2">
                
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/image-4@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221210%22%20height=%221228%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201210%201228%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1210" height="1228">                    <source
        data-srcset="assets/images/media/landing/6.style/image-4@xxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22952%22%20height=%22966%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20952%20966%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="952" height="966">
        <img
            data-src="assets/images/media/landing/6.style/image-4@md.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22680%22%20height=%22690%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20680%20690%22%3E%3C/svg%3E"                    alt=""                            width="680" height="690"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="assets/images/media/landing/6.style/image-4@xxxl.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1210" height="1228">                    <source srcset="/assets/images/media/landing/6.style/image-4@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="952" height="966">
        <img
            src="assets/images/media/landing/6.style/image-4@md.webp"                    alt=""                            width="680" height="690"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
            </div>
        </div>
        <div class="style__image-3 col col--xs-4 col--md-6 pr-layout is-hidden--sm-down">
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/6.style/image-5@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221228%22%20height=%221228%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201228%201228%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1228">                    <source
        data-srcset="assets/images/media/landing/6.style/image-5@xxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22966%22%20height=%22966%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20966%20966%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="966">
        <img
            data-src="assets/images/media/landing/6.style/image-5@md.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22690%22%20height=%22690%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20690%20690%22%3E%3C/svg%3E"                    alt=""                            width="690" height="690"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/6.style/image-5@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1228">                    <source srcset="/assets/images/media/landing/6.style/image-5@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="966">
        <img
            src="/assets/images/media/landing/6.style/image-5@md.webp?v=1779376336"                    alt=""                            width="690" height="690"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
        </div>
        <div class="col col--xs-4 px-layout container-h-vars is-hidden--md-up">
            <ul class="style__scrollable mobile-scrollable">
                <li class="mobile-scrollable__item">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >
        <img
            data-src="/assets/images/media/landing/6.style/image-4-xs@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22293%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20293%22%3E%3C/svg%3E"                    alt=""                            width="320" height="293"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >
        <img
            src="/assets/images/media/landing/6.style/image-4-xs@xs.webp?v=1779376336"                    alt=""                            width="320" height="293"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </li>
                <li class="mobile-scrollable__item">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >
        <img
            data-src="/assets/images/media/landing/6.style/image-5-xs@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22293%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20293%22%3E%3C/svg%3E"                    alt=""                            width="320" height="293"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >
        <img
            src="/assets/images/media/landing/6.style/image-5-xs@xs.webp?v=1779376336"                    alt=""                            width="320" height="293"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </li>
                            </ul>
        </div>
    </div>
</section>
    

<section
    class="gallery section section--full-height ui-dark ui-background"
    data-scroll-section
    data-themed-class="ui-dark"
    data-scroll-snap-point='[
        { "viewport": -100, "element": 0 },
        { "viewport": 0, "element": 0 }
    ]'
>
    <div class="section__content"
        data-plugin="parallax"
        data-parallax-pattern="sectionOutFade"
        data-parallax-enable-mq="md-up"
    >
        <div class="gallery__background" data-plugin="galleryBackground">
            <div
                data-plugin="parallax"
                data-parallax-clamp="true"
                data-parallax-measure-selector=".section"
                data-parallax-100-0='{"transform": "translateY(-25vh)"}'
                data-parallax-0-100='{"transform": "translateY(25vh)"}'
                data-parallax-enable-mq="null"
                data-parallax-mobile-smooth="true"
            >
                <div class="row">
                    <div class="col col--xs-1 col--md-2">
                        <div class="gallery__image-1">
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full js-gallery-image"                        data-move-factor="0.8"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_1_xxxl/uploads/39/image_1777288096.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22641%22%20height=%22854%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20641%20854%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="854">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_1_xxl/uploads/39/image_1777288096.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22504%22%20height=%22672%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20504%20672%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="672">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_1_md/uploads/39/image_1777288096.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="480">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_gallery_img_1_xs/uploads/39/image_1777288096.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22180%22%20height=%22240%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20180%20240%22%3E%3C/svg%3E"                    alt=""                            width="180" height="240"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full js-gallery-image"                        data-move-factor="0.8"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_1_xxxl/uploads/39/image_1777288096.webp" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="854">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_1_xxl/uploads/39/image_1777288096.webp" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="672">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_1_md/uploads/39/image_1777288096.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="480">
        <img
            src="https://zorge9.estate/media/cache/homepage_gallery_img_1_xs/uploads/39/image_1777288096.webp"                    alt=""                            width="180" height="240"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                    </div>
                    <div class="col col--xs-2 col--md-4 offset--xs-1 offset--md-1">
                        <div class="gallery__image-2">
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full js-gallery-image"                        data-move-factor="0.9"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_2_xxxl/uploads/39/11_1777288096.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22854%22%20height=%22570%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20854%20570%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="854" height="570">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_2_xxl/uploads/39/11_1777288096.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22672%22%20height=%22448%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20672%20448%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="672" height="448">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_2_md/uploads/39/11_1777288096.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22480%22%20height=%22320%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20480%20320%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="480" height="320">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_gallery_img_2_xs/uploads/39/11_1777288096.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22270%22%20height=%22180%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20270%20180%22%3E%3C/svg%3E"                    alt=""                            width="270" height="180"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full js-gallery-image"                        data-move-factor="0.9"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_2_xxxl/uploads/39/11_1777288096.webp" media="(min-width: 1920px) and (min-height: 700px)" width="854" height="570">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_2_xxl/uploads/39/11_1777288096.webp" media="(min-width: 1440px) and (min-height: 700px)" width="672" height="448">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_2_md/uploads/39/11_1777288096.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="480" height="320">
        <img
            src="https://zorge9.estate/media/cache/homepage_gallery_img_2_xs/uploads/39/11_1777288096.webp"                    alt=""                            width="270" height="180"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                    </div>
                    <div class="col col--xs-2 col--md-2 offset--md-3 is-hidden--sm-down">
                        <div class="gallery__image-3">
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full js-gallery-image"                        data-move-factor="0.6"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_3_xxxl/uploads/39/img_5610_1_1777288095.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22534%22%20height=%22641%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20534%20641%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="534" height="641">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_3_xxl/uploads/39/img_5610_1_1777288095.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22420%22%20height=%22504%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20420%20504%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="420" height="504">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_gallery_img_3_md/uploads/39/img_5610_1_1777288095.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22300%22%20height=%22360%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20300%20360%22%3E%3C/svg%3E"                    alt=""                            width="300" height="360"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full js-gallery-image"                        data-move-factor="0.6"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_3_xxxl/uploads/39/img_5610_1_1777288095.webp" media="(min-width: 1920px) and (min-height: 700px)" width="534" height="641">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_3_xxl/uploads/39/img_5610_1_1777288095.webp" media="(min-width: 1440px) and (min-height: 700px)" width="420" height="504">
        <img
            src="https://zorge9.estate/media/cache/homepage_gallery_img_3_md/uploads/39/img_5610_1_1777288095.webp"                    alt=""                            width="300" height="360"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                    </div>
                    <div class="col col--xs-2 col--md-4 offset--xs-1 offset--md-4">
                        <div class="gallery__image-4">
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full js-gallery-image"                        data-move-factor="1"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_4_xxxl/uploads/39/img_0231_1777288095.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22854%22%20height=%22854%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20854%20854%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="854" height="854">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_4_xxl/uploads/39/img_0231_1777288095.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22672%22%20height=%22672%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20672%20672%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="672" height="672">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_4_md/uploads/39/img_0231_1777288095.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22480%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20480%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="480" height="480">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_gallery_img_4_xs/uploads/39/img_0231_1777288095.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22180%22%20height=%22180%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20180%20180%22%3E%3C/svg%3E"                    alt=""                            width="180" height="180"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full js-gallery-image"                        data-move-factor="1"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_4_xxxl/uploads/39/img_0231_1777288095.webp" media="(min-width: 1920px) and (min-height: 700px)" width="854" height="854">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_4_xxl/uploads/39/img_0231_1777288095.webp" media="(min-width: 1440px) and (min-height: 700px)" width="672" height="672">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_4_md/uploads/39/img_0231_1777288095.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="480" height="480">
        <img
            src="https://zorge9.estate/media/cache/homepage_gallery_img_4_xs/uploads/39/img_0231_1777288095.webp"                    alt=""                            width="180" height="180"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col col--xs-1 col--md-3">
                        <div class="gallery__image-5">
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full js-gallery-image"                        data-move-factor="0.7"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_5_xxxl/uploads/39/0k0a8352_1777288094.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22641%22%20height=%22534%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20641%20534%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="534">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_5_xxl/uploads/39/0k0a8352_1777288094.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22504%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20504%20420%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="420">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_5_md/uploads/39/0k0a8352_1777288094.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22300%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20300%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="300">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_gallery_img_5_xs/uploads/39/0k0a8352_1777288094.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22270%22%20height=%22225%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20270%20225%22%3E%3C/svg%3E"                    alt=""                            width="270" height="225"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full js-gallery-image"                        data-move-factor="0.7"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_5_xxxl/uploads/39/0k0a8352_1777288094.webp" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="534">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_5_xxl/uploads/39/0k0a8352_1777288094.webp" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="420">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_5_md/uploads/39/0k0a8352_1777288094.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="300">
        <img
            src="https://zorge9.estate/media/cache/homepage_gallery_img_5_xs/uploads/39/0k0a8352_1777288094.webp"                    alt=""                            width="270" height="225"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                    </div>
                    <div class="col col--xs-1 col--md-3 offset--xs-2 offset--md-6">
                        <div class="gallery__image-6">
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full js-gallery-image"                        data-move-factor="0.8"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_6_xxxl/uploads/39/%D0%97%D0%BE%D1%80%D0%B3%D0%B520821_1777288096.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22641%22%20height=%22854%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20641%20854%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="854">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_6_xxl/uploads/39/%D0%97%D0%BE%D1%80%D0%B3%D0%B520821_1777288096.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22504%22%20height=%22672%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20504%20672%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="672">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_gallery_img_6_md/uploads/39/%D0%97%D0%BE%D1%80%D0%B3%D0%B520821_1777288096.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="480">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_gallery_img_6_xs/uploads/39/%D0%97%D0%BE%D1%80%D0%B3%D0%B520821_1777288096.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22180%22%20height=%22240%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20180%20240%22%3E%3C/svg%3E"                    alt=""                            width="180" height="240"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full js-gallery-image"                        data-move-factor="0.8"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_6_xxxl/uploads/39/%D0%97%D0%BE%D1%80%D0%B3%D0%B520821_1777288096.webp" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="854">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_6_xxl/uploads/39/%D0%97%D0%BE%D1%80%D0%B3%D0%B520821_1777288096.webp" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="672">                    <source srcset="https://zorge9.estate/media/cache/homepage_gallery_img_6_md/uploads/39/%D0%97%D0%BE%D1%80%D0%B3%D0%B520821_1777288096.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="480">
        <img
            src="https://zorge9.estate/media/cache/homepage_gallery_img_6_xs/uploads/39/%D0%97%D0%BE%D1%80%D0%B3%D0%B520821_1777288096.webp"                    alt=""                            width="180" height="240"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div
            class="gallery__title"
            data-plugin="cursor"
            data-cursor-show-default-cursor="true"
        >
            <div class="gallery__title-line offset--md-3 px-layout px-0:md">
                <h2 class="gallery__title-text h1 leading-trim">
                    GALLERY
                </h2>
                <p class="text-small leading-trim">
                    /11 photos
                </p>
            </div>
            <a class="gallery__link btn-container" href="#gallery-modal">
                    
                                    
    
            
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--text-arrow btn--text-small btn-container btn--outline is-hidden--hover"
                                                                            data-content-animation-id="false"
                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                                    
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn "
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    View

                                    </span>
            
                    </span>
    </span>
    

                                    </span>
            
                                                        <span class="btn__icon">
                    
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn "
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
        </span>
    
                                    </span>
    </span>
            </a>
            <div class="cursor cursor--gallery js-cursor-button is-hidden--no-hover">
                    
                                    
    
            
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--text-arrow btn--text-small btn-container cursor__button btn--outline is-decorative"
                                                                            data-content-animation-id="false"
                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                                    
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn "
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    View

                                    </span>
            
                    </span>
    </span>
    

                                    </span>
            
                                                        <span class="btn__icon">
                    
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn "
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
        </span>
    
                                    </span>
    </span>
            </div>
        </div>
    </div>
</section>
    

<section
    class="time section ui-dark ui-background"
    data-scroll-section
    data-themed-class="ui-dark"
    data-plugin="time reveal"
    data-scroll-snap-point='[
        { "viewport": 100, "element": 0 }
    ]'
>
    <div class="time__sticky sticky sticky--under-next sticky--under-previous"
        data-plugin="parallax"
        data-parallax-pattern="sectionOutTiny"
        data-parallax-enable-mq="md-up"
    >
        <div
            class="time__container sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
        >
            <h2 class="sr-only">Daily schedule</h2>
            <div
                class="time__image js-time-content-animation-controller"
                data-plugin="contentAnimation"
                data-content-animation-animations='{
                    "changeShow": {"name": "imageClipIn", "duration": 2},
                    "changeHide": {"name": "imageSlideOut", "duration": 2}
                }'
                data-content-animation-plugins="controller events"
                data-content-animation-next-selector=":root .js-content-animation-time-next"
                data-content-animation-prev-selector=":root .js-content-animation-time-prev"
                data-content-animation-disable-next-prev="true"
            >
                <div class="content-animation background background--cover"
                    data-plugin="parallax"
                    data-parallax-measure-selector=".time__image"
                    data-parallax-enable-mq="sm-down"
                    data-parallax-100-100='{"transform": "translateY(-5svh)"}'
                    data-parallax-0-0='{"transform": "translateY(0svh)"}'
                    data-parallax-mobile-smooth="true"
                >
                                            <div
                            data-content-animation-item="time-1"
                            data-degree="-150"
                            class="background background--cover ui-background "
                            aria-hidden="false"
                        >
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/image_13_1777289990.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/image_13_1777289990.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/image_13_1777289990.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/image_13_1777289990.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20640%22%3E%3C/svg%3E"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/image_13_1777289990.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/image_13_1777289990.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/image_13_1777289990.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/image_13_1777289990.webp"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                                            <div
                            data-content-animation-item="time-2"
                            data-degree="-120"
                            class="background background--cover ui-background is-hidden"
                            aria-hidden="true"
                        >
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/image_14_1777289992.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/image_14_1777289992.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/image_14_1777289992.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/image_14_1777289992.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20640%22%3E%3C/svg%3E"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/image_14_1777289992.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/image_14_1777289992.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/image_14_1777289992.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/image_14_1777289992.webp"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                                            <div
                            data-content-animation-item="time-3"
                            data-degree="-30"
                            class="background background--cover ui-background is-hidden"
                            aria-hidden="true"
                        >
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/image_15_1777289992.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/image_15_1777289992.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/image_15_1777289992.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/image_15_1777289992.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20640%22%3E%3C/svg%3E"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/image_15_1777289992.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/image_15_1777289992.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/image_15_1777289992.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/image_15_1777289992.webp"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                                            <div
                            data-content-animation-item="time-4"
                            data-degree="60"
                            class="background background--cover ui-background is-hidden"
                            aria-hidden="true"
                        >
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/13_1777289990.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/13_1777289990.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/13_1777289990.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/13_1777289990.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20640%22%3E%3C/svg%3E"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/13_1777289990.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/13_1777289990.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/13_1777289990.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/13_1777289990.webp"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                                            <div
                            data-content-animation-item="time-5"
                            data-degree="270"
                            class="background background--cover ui-background is-hidden"
                            aria-hidden="true"
                        >
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/13_1_1777289986.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/13_1_1777289986.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/13_1_1777289986.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/13_1_1777289986.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20640%22%3E%3C/svg%3E"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxxl/uploads/39/13_1_1777289986.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_xxl/uploads/39/13_1_1777289986.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_time_slider_img_md/uploads/39/13_1_1777289986.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_time_slider_img_xs/uploads/39/13_1_1777289986.webp"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </div>
                                    </div>
            </div>
            <div class="time__content">
                <div class="time__clock" style="--hour-degree: -150">
                    <span class="time__clock-hour"></span>
                    <span class="time__clock-minute"></span>
                </div>
                <div
                    class="time__digits"
                    data-plugin="contentAnimation"
                    data-content-animation-animations='{
                        "changeShow": {"name": "text"},
                        "changeHide": {"name": "textOut"}
                    }'
                    data-content-animation-plugins="controller"
                    data-content-animation-controller-selector=":root .js-time-content-animation-controller"
                >
                    <div class="content-animation">
                                                    <div
                                data-content-animation-item="time-1"
                                class=""
                                aria-hidden="false"
                                                                    data-reveal="text" data-reveal-distance="0"
                                                            >
                                <p class="h2 leading-trim">
                                    07:00
                                </p>
                            </div>
                                                    <div
                                data-content-animation-item="time-2"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <p class="h2 leading-trim">
                                    08:00
                                </p>
                            </div>
                                                    <div
                                data-content-animation-item="time-3"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <p class="h2 leading-trim">
                                    11:00
                                </p>
                            </div>
                                                    <div
                                data-content-animation-item="time-4"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <p class="h2 leading-trim">
                                    14:00
                                </p>
                            </div>
                                                    <div
                                data-content-animation-item="time-5"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <p class="h2 leading-trim">
                                    21:00
                                </p>
                            </div>
                                            </div>
                </div>
                <div class="time__controls">
                            
        
                                                                      
            

        
                
        
        
        
    <a
        class="btn btn--link btn--link-static btn--animate-icon js-content-animation-time-prev is-disabled"
                                                                                                                                                        aria-label="Previous item"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-long-arrow-left" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left"></use></svg>
                                                    <svg class="icon icon-long-arrow-left" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left"></use></svg>
                                            </span>
                                    </span>
    </a>
                            
        
                                                                      
            

        
                
        
        
        
    <a
        class="btn btn--link btn--link-static btn--animate-icon js-content-animation-time-next"
                                                                                                                                                        aria-label="Next item"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-long-arrow-right" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right"></use></svg>
                                                    <svg class="icon icon-long-arrow-right" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right"></use></svg>
                                            </span>
                                    </span>
    </a>
                </div>
                <div
                    class="time__text col--xs-4 col--md-4 px-layout pr-0:md"
                    data-plugin="contentAnimation"
                    data-content-animation-animations='{
                        "changeShow": {"name": "text"},
                        "changeHide": {"name": "textOut"}
                    }'
                    data-content-animation-plugins="controller"
                    data-content-animation-controller-selector=":root .js-time-content-animation-controller"
                >
                    <div class="content-animation content-animation--bottom">
                                                    <div
                                data-content-animation-item="time-1"
                                class=""
                                aria-hidden="false"
                                                                    data-reveal="text" data-reveal-distance="0"
                                                            >
                                <div>
                                    <span class="text-offset text-offset--2:md"></span>
                                    <p class="leading-trim">
                                        ENJOY THE&nbsp;FIRST RAYS OF&nbsp;DAWN AS&nbsp;THE&nbsp;CITY UNFOLDS BEFORE&nbsp;YOU IN&nbsp;PANORAMIC WINDOWS, FILLING YOUR HOME WITH&nbsp;LIGHT AND SERENITY.
                                    </p>
                                </div>
                            </div>
                                                    <div
                                data-content-animation-item="time-2"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <div>
                                    <span class="text-offset text-offset--2:md"></span>
                                    <p class="leading-trim">
                                        Feel the&nbsp;ease of&nbsp;movement and harmony as&nbsp;you start your morning with&nbsp;yoga in&nbsp;the&nbsp;open air. Fresh air, soft rays of&nbsp;sunshine, and smooth movements in&nbsp;rhythm. There is no hustle and bustle here — just you and the&nbsp;perfect start to&nbsp;your morning.
                                    </p>
                                </div>
                            </div>
                                                    <div
                                data-content-animation-item="time-3"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <div>
                                    <span class="text-offset text-offset--2:md"></span>
                                    <p class="leading-trim">
                                        FEEL THE&nbsp;ATTENTION FROM&nbsp;THE&nbsp;FIRST STEP IN&nbsp;THE&nbsp;LOBBY, WHERE THE&nbsp;STAFF IS READY TO&nbsp;PROVIDE YOU WITH&nbsp;UNIQUE SERVICE: FROM&nbsp;ORGANIZING TRANSPORTATION AND BOOKING SERVICES TO&nbsp;SOLVING SMALL DAILY TASKS.
                                    </p>
                                </div>
                            </div>
                                                    <div
                                data-content-animation-item="time-4"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <div>
                                    <span class="text-offset text-offset--2:md"></span>
                                    <p class="leading-trim">
                                        CREATE THE&nbsp;PERFECT MOMENT FOR&nbsp;WORK IN&nbsp;A&nbsp;PRIVATE CO-WORKING SPACE. HERE IT IS EASY TO&nbsp;FOCUS ON&nbsp;YOUR TASKS, HOLD A&nbsp;MEETING WITH&nbsp;A&nbsp;CLIENT, OR DISCUSS STRATEGY WITH&nbsp;YOUR TEAM.
                                    </p>
                                </div>
                            </div>
                                                    <div
                                data-content-animation-item="time-5"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <div>
                                    <span class="text-offset text-offset--2:md"></span>
                                    <p class="leading-trim">
                                        End the&nbsp;day in&nbsp;the&nbsp;tea room in&nbsp;the&nbsp;grand lobby, where every gesture becomes part of&nbsp;a&nbsp;ritual: unhurried, mindful, filled with&nbsp;silence. This evening ceremony of&nbsp;slowing down&nbsp;is a&nbsp;way to&nbsp;gently let go of&nbsp;the&nbsp;hustle and bustle of&nbsp;the&nbsp;day and prepare for&nbsp;sleep.
                                    </p>
                                </div>
                            </div>
                                            </div>
                </div>
            </div>
        </div>
    </div>
</section>
    
<section
    class="lobby section ui-dark ui-background"
    data-scroll-section
    data-themed-class="ui-dark"
    data-plugin="reveal"
    data-scroll-snap-point='[
        { "viewport": 100, "element": 0 }
    ]'
>
    <div class="sticky sticky:md-up sticky--under-next sticky--under-previous sticky--full-height">
        <div
            class="sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
        >
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js lobby__image background background--cover"                        data-parallax-enable-mq="md-up"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".section"            data-parallax-0-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"            data-parallax-100-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_lobby_bg_xxxl/uploads/39/zorge90843_1777290628.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222563%22%20height=%221886%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202563%201886%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2563" height="1886">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_lobby_bg_xxl/uploads/39/zorge90843_1777290628.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222016%22%20height=%221484%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202016%201484%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="2016" height="1484">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_lobby_bg_md/uploads/39/zorge90843_1777290628.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221440%22%20height=%221060%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201440%201060%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1440" height="1060">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_lobby_bg_xs/uploads/39/zorge90843_1777290628.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20640%22%3E%3C/svg%3E"                    alt=""                            width="360" height="640"                                        data-plugin="parallax"                        data-parallax-enable-mq="sm-down"                        data-parallax-clamp="true"                        data-parallax-measure-selector="picture"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" lobby__image background background--cover"                        data-parallax-enable-mq="md-up"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".section"            data-parallax-0-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"            data-parallax-100-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_lobby_bg_xxxl/uploads/39/zorge90843_1777290628.webp" media="(min-width: 1920px) and (min-height: 700px)" width="2563" height="1886">                    <source srcset="https://zorge9.estate/media/cache/homepage_lobby_bg_xxl/uploads/39/zorge90843_1777290628.webp" media="(min-width: 1440px) and (min-height: 700px)" width="2016" height="1484">                    <source srcset="https://zorge9.estate/media/cache/homepage_lobby_bg_md/uploads/39/zorge90843_1777290628.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1440" height="1060">
        <img
            src="https://zorge9.estate/media/cache/homepage_lobby_bg_xs/uploads/39/zorge90843_1777290628.webp"                    alt=""                            width="360" height="640"                                        data-plugin="parallax"                        data-parallax-enable-mq="sm-down"                        data-parallax-clamp="true"                        data-parallax-measure-selector="picture"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    

            <div class="lobby__content pb-layout"
                data-plugin="parallax"
                data-parallax-enable-mq="md-up"
                data-parallax-clamp="true"
                data-parallax-measure-selector=".section"
                data-parallax-0-0='{"transform": "translateY(10svh)"}'
                data-parallax--100-0='{"transform": "translateY(0svh)"}'
                data-parallax-100-100='{"transform": "translateY(-10svh)"}'
            >
                <div class="px-layout">
                    <h2 class="h1 text-right leading-trim" data-reveal="text" data-reveal-distance="0">
                        The&nbsp;Luxury<br />
of&nbsp;Experience
                    </h2>
                </div>
                <div class="row">
                    <div class="col col--xs-4 col--md-5 px-layout pr-3:md">
                        <p class="leading-trim" data-reveal="text" data-reveal-distance="0">
                            The&nbsp;sophisticated design of&nbsp;the&nbsp;lobby is inspired by&nbsp;the&nbsp;interiors of&nbsp;famous grand hotels: two-meter mirrors, dark glossy stone walls, crystal waterfall chandeliers.
                        </p>
                    </div>
                </div>
            </div>
            <div class="lobby__shadow is-hidden--sm-down"
                data-plugin="parallax"
                data-parallax-enable-mq="md-up"
                data-parallax-clamp="true"
                data-parallax-measure-selector=".section"
                data-parallax--125-0='{"opacity": "0"}'
                data-parallax-100-100='{"opacity": "1"}'
            ></div>
        </div>
    </div>
</section>
    

<section
    class="advantages section ui-dark ui-background"
    data-scroll-section
    data-themed-class="ui-dark"
    data-scroll-snap-point='[
                        { "viewport": 100, "element": 0 },                                { "viewport": 200, "element": 0 },                                { "viewport": 300, "element": 0 },                                { "viewport": 400, "element": 0 }                                    ]'
>
    <div
        class="advantages__sticky sticky sticky--under-next sticky--under-previous sticky--full-height is-hidden--sm-down"
        style="--item-count: 5;"
        data-plugin="parallax"
        data-parallax-measure-selector=".section"
        data-parallax-enable-mq="md-up"
        data-parallax-clamp="true"
        data-parallax--500-0='{"transform": "translateX(0svh)"}'
        data-parallax-100-100='{"transform": "translateX(-10svh)"}'
    >
        <div
            class="advantages__container sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
                        data-plugin="parallax"
            data-parallax-pattern="advantages"
            data-parallax-services-count="5"
                    >
            <h2 class="sr-only">advantages</h2>
            <div
                class="advantages__image js-scroll-parent-ignore"
            >
                <div class="content-animation background background--cover js-scroll-parent-ignore">
                                            <div
                            class=" background background--cover ui-background js-content-animation-advantages-1-controller"
                            data-plugin="contentAnimation parallax"
                            data-content-animation-animations='{
                                "changeShow": {"name": "imageClipIn", "duration": 2},
                                "changeHide": {"name": "imageSlideOut", "duration": 2}
                            }'
                            data-content-animation-plugins="controller events"
                            data-content-animation-item-selector="[data-content-animation-item-sub]"
                            data-content-animation-next-selector=":root .js-content-animation-advantages-1-next"
                            data-content-animation-prev-selector=":root .js-content-animation-advantages-1-prev"
                            data-content-animation-disable-next-prev="true"
                            data-parallax-pattern="advantagesImage"
                            data-parallax-item-index="1"
                            data-parallax-first="1"
                            data-parallax-last=""
                        >
                            <div class="content-animation background background--cover"
                            >
                                                                    <div
                                        data-content-animation-item="sub-1"
                                        data-content-animation-item-sub="sub-1"
                                        class="background background--cover ui-background "
                                        aria-hidden="false"
                                    >
                                                                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1777290624.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1777290624.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1777290624.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1777290624.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1777290624.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                            </div>
                                                            </div>
                        </div>
                                            <div
                            class=" background background--cover ui-background js-content-animation-advantages-2-controller"
                            data-plugin="contentAnimation parallax"
                            data-content-animation-animations='{
                                "changeShow": {"name": "imageClipIn", "duration": 2},
                                "changeHide": {"name": "imageSlideOut", "duration": 2}
                            }'
                            data-content-animation-plugins="controller events"
                            data-content-animation-item-selector="[data-content-animation-item-sub]"
                            data-content-animation-next-selector=":root .js-content-animation-advantages-2-next"
                            data-content-animation-prev-selector=":root .js-content-animation-advantages-2-prev"
                            data-content-animation-disable-next-prev="true"
                            data-parallax-pattern="advantagesImage"
                            data-parallax-item-index="2"
                            data-parallax-first=""
                            data-parallax-last=""
                        >
                            <div class="content-animation background background--cover"
                            >
                                                                    <div
                                        data-content-animation-item="sub-1"
                                        data-content-animation-item-sub="sub-1"
                                        class="background background--cover ui-background "
                                        aria-hidden="false"
                                    >
                                                                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="780">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="780">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1_1777290624.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1_1777290624.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="780">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1_1777290624.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="780">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1_1777290624.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1_1777290624.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                            </div>
                                                            </div>
                        </div>
                                            <div
                            class=" background background--cover ui-background js-content-animation-advantages-3-controller"
                            data-plugin="contentAnimation parallax"
                            data-content-animation-animations='{
                                "changeShow": {"name": "imageClipIn", "duration": 2},
                                "changeHide": {"name": "imageSlideOut", "duration": 2}
                            }'
                            data-content-animation-plugins="controller events"
                            data-content-animation-item-selector="[data-content-animation-item-sub]"
                            data-content-animation-next-selector=":root .js-content-animation-advantages-3-next"
                            data-content-animation-prev-selector=":root .js-content-animation-advantages-3-prev"
                            data-content-animation-disable-next-prev="true"
                            data-parallax-pattern="advantagesImage"
                            data-parallax-item-index="3"
                            data-parallax-first=""
                            data-parallax-last=""
                        >
                            <div class="content-animation background background--cover"
                            >
                                                                    <div
                                        data-content-animation-item="sub-1"
                                        data-content-animation-item-sub="sub-1"
                                        class="background background--cover ui-background "
                                        aria-hidden="false"
                                    >
                                                                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_2_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="780">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_2_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="780">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_2_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_2_1777290624.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_2_1777290624.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="780">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_2_1777290624.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="780">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_2_1777290624.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_2_1777290624.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                            </div>
                                                            </div>
                        </div>
                                            <div
                            class=" background background--cover ui-background js-content-animation-advantages-4-controller"
                            data-plugin="contentAnimation parallax"
                            data-content-animation-animations='{
                                "changeShow": {"name": "imageClipIn", "duration": 2},
                                "changeHide": {"name": "imageSlideOut", "duration": 2}
                            }'
                            data-content-animation-plugins="controller events"
                            data-content-animation-item-selector="[data-content-animation-item-sub]"
                            data-content-animation-next-selector=":root .js-content-animation-advantages-4-next"
                            data-content-animation-prev-selector=":root .js-content-animation-advantages-4-prev"
                            data-content-animation-disable-next-prev="true"
                            data-parallax-pattern="advantagesImage"
                            data-parallax-item-index="4"
                            data-parallax-first=""
                            data-parallax-last=""
                        >
                            <div class="content-animation background background--cover"
                            >
                                                                    <div
                                        data-content-animation-item="sub-1"
                                        data-content-animation-item-sub="sub-1"
                                        class="background background--cover ui-background "
                                        aria-hidden="false"
                                    >
                                                                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1777290625.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1777290625.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1777290625.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1777290625.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1777290625.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1777290625.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1777290625.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1777290625.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                            </div>
                                                            </div>
                        </div>
                                            <div
                            class=" background background--cover ui-background js-content-animation-advantages-5-controller"
                            data-plugin="contentAnimation parallax"
                            data-content-animation-animations='{
                                "changeShow": {"name": "imageClipIn", "duration": 2},
                                "changeHide": {"name": "imageSlideOut", "duration": 2}
                            }'
                            data-content-animation-plugins="controller events"
                            data-content-animation-item-selector="[data-content-animation-item-sub]"
                            data-content-animation-next-selector=":root .js-content-animation-advantages-5-next"
                            data-content-animation-prev-selector=":root .js-content-animation-advantages-5-prev"
                            data-content-animation-disable-next-prev="true"
                            data-parallax-pattern="advantagesImage"
                            data-parallax-item-index="5"
                            data-parallax-first=""
                            data-parallax-last="1"
                        >
                            <div class="content-animation background background--cover"
                            >
                                                                    <div
                                        data-content-animation-item="sub-1"
                                        data-content-animation-item-sub="sub-1"
                                        class="background background--cover ui-background "
                                        aria-hidden="false"
                                    >
                                                                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_3_1777290626.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_3_1777290626.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_3_1777290626.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_3_1777290626.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_3_1777290626.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_3_1777290626.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_3_1777290626.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_3_1777290626.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                            </div>
                                                            </div>
                        </div>
                                    </div>
            </div>
            <div class="advantages__content">
                <div class="advantages__counter px-layout">
                    <span class="leading-trim js-content-animation-advantages-counter">1</span>
                    <span class="advantages__counter-line"></span>
                    <span class="text-color-smallest leading-trim">5</span>
                </div>
                <div class="advantages__head">
                    <div
                        class="col--xs-3 col--md-4 pl-layout js-advantages-content-animation-controller"
                        data-plugin="contentAnimation"
                        data-content-animation-plugins="controller counter"
                        data-content-animation-counter-selector=":root .js-content-animation-advantages-counter"
                        data-content-animation-animations='{
                            "changeShow": {"name": "text"},
                            "changeHide": {"name": "textOut"}
                        }'
                    >
                        <div class="content-animation">
                                                            <p
                                    class="h2 leading-trim "
                                    data-content-animation-item="0"
                                    aria-hidden="false"
                                >
                                    lobby
                                </p>
                                                            <p
                                    class="h2 leading-trim is-hidden"
                                    data-content-animation-item="1"
                                    aria-hidden="true"
                                >
                                    concierge<br>service
                                </p>
                                                            <p
                                    class="h2 leading-trim is-hidden"
                                    data-content-animation-item="2"
                                    aria-hidden="true"
                                >
                                    community<br>center
                                </p>
                                                            <p
                                    class="h2 leading-trim is-hidden"
                                    data-content-animation-item="3"
                                    aria-hidden="true"
                                >
                                    co-working<br>space
                                </p>
                                                            <p
                                    class="h2 leading-trim is-hidden"
                                    data-content-animation-item="4"
                                    aria-hidden="true"
                                >
                                    courtyard lounge with&nbsp;fireplace<br>and fountain
                                </p>
                                                    </div>
                    </div>
                    <div
                        class="col--xs-2 col--md-2 pr-layout js-advantages-content-animation-controller"
                        data-plugin="contentAnimation"
                        data-content-animation-plugins="controller"
                        data-content-animation-animations='{
                            "changeShow": {"name": "fadeIn"},
                            "changeHide": {"name": "fadeOut"}
                        }'
                        data-content-animation-fixed-height="true"
                    >
                        <div class="content-animation">
                                                            <div class="group group--right group--middle group--arrows "
                                    data-content-animation-item="0"
                                    aria-hidden="false"
                                >
                                                                    </div>
                                                            <div class="group group--right group--middle group--arrows is-hidden"
                                    data-content-animation-item="1"
                                    aria-hidden="true"
                                >
                                                                    </div>
                                                            <div class="group group--right group--middle group--arrows is-hidden"
                                    data-content-animation-item="2"
                                    aria-hidden="true"
                                >
                                                                    </div>
                                                            <div class="group group--right group--middle group--arrows is-hidden"
                                    data-content-animation-item="3"
                                    aria-hidden="true"
                                >
                                                                    </div>
                                                            <div class="group group--right group--middle group--arrows is-hidden"
                                    data-content-animation-item="4"
                                    aria-hidden="true"
                                >
                                                                    </div>
                                                    </div>
                    </div>
                </div>
                <div class="advantages__text col--xs-4 col--md-4 px-layout pl-0:md js-advantages-content-animation-controller"
                    data-plugin="contentAnimation"
                    data-content-animation-plugins="controller"
                        data-content-animation-animations='{
                            "changeShow": {"name": "fadeIn", "delay": 0.6},
                            "changeHide": {"name": "fadeOut"}
                        }'
                    data-content-animation-item-selector="[data-content-animation-item-main]"
                >
                    <div class="content-animation content-animation--bottom">
                                                                                                                                                                                                                                            <div
                                data-content-animation-item="0"
                                data-content-animation-item-main="0"
                                class=""
                                aria-hidden="false"
                                                            >
                                <div class="content-animation content-animation--bottom">
                                                                                                                        <div>
                                                <span class="text-offset"></span>
                                                <p class="leading-trim">
                                                    Spacious and elegant lobbies welcome residents with&nbsp;impeccable interiors and a&nbsp;cozy lounge area, embodying the&nbsp;idea of&nbsp;impeccable style and understated luxury. Immerse yourself in&nbsp;an&nbsp;atmosphere of&nbsp;refined comfort comparable to&nbsp;the&nbsp;world's finest hote
                                                </p>
                                            </div>
                                                                                                            </div>
                            </div>
                                                                                                                                                                                                                                            <div
                                data-content-animation-item="1"
                                data-content-animation-item-main="1"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <div class="content-animation content-animation--bottom">
                                                                                                                        <div>
                                                <span class="text-offset"></span>
                                                <p class="leading-trim">
                                                    A&nbsp;personal assistant who takes care of&nbsp;your time and comfort. Transportation arrangements, ticket reservations, or everyday tasks — everything will be done with&nbsp;attention and professionalism.
                                                </p>
                                            </div>
                                                                                                            </div>
                            </div>
                                                                                                                                                                                                                                            <div
                                data-content-animation-item="2"
                                data-content-animation-item-main="2"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <div class="content-animation content-animation--bottom">
                                                                                                                        <div>
                                                <span class="text-offset"></span>
                                                <p class="leading-trim">
                                                    Playing, forgetting about&nbsp;everything in&nbsp;the&nbsp;world, sharing secrets with&nbsp;friends, drawing cartoon characters — the&nbsp;children's room opens the&nbsp;door to&nbsp;another world.
                                                </p>
                                            </div>
                                                                                                            </div>
                            </div>
                                                                                                                                                                                                                                            <div
                                data-content-animation-item="3"
                                data-content-animation-item-main="3"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <div class="content-animation content-animation--bottom">
                                                                                                                        <div>
                                                <span class="text-offset"></span>
                                                <p class="leading-trim">
                                                    If you have a&nbsp;brilliant business idea, discuss it with&nbsp;your colleagues without&nbsp;leaving your home. Spacious meeting rooms with&nbsp;high panoramic windows will help you present your project in&nbsp;the&nbsp;best light.
                                                </p>
                                            </div>
                                                                                                            </div>
                            </div>
                                                                                                                                                                                                                                            <div
                                data-content-animation-item="4"
                                data-content-animation-item-main="4"
                                class="is-hidden"
                                aria-hidden="true"
                                                            >
                                <div class="content-animation content-animation--bottom">
                                                                                                                        <div>
                                                <span class="text-offset"></span>
                                                <p class="leading-trim">
                                                    A&nbsp;secluded corner in&nbsp;the&nbsp;very center of&nbsp;the&nbsp;complex. Greenery, stylish design solutions, and cozy relaxation areas create an&nbsp;atmosphere of&nbsp;calm and harmony.
                                                </p>
                                            </div>
                                                                                                            </div>
                            </div>
                                            </div>
                </div>
            </div>
        </div>
    </div>
    <div class="is-hidden--md-up">
                <div class="advantages__container">
            <div class="advantages__image">
                <div class="content-animation background background--cover"
                    data-plugin="parallax"
                    data-parallax-measure-selector=".advantages__image"
                    data-parallax-enable-mq="sm-down"
                                        data-parallax-100-100='{"transform": "translateY(-5svh)"}'
                    data-parallax-0-0='{"transform": "translateY(0svh)"}'
                    data-parallax-mobile-smooth="true"
                >
                    <div
                        class=" background background--cover ui-background js-content-animation-advantages-1-controller"
                        data-plugin="contentAnimation"
                        data-content-animation-animations='{
                            "changeShow": {"name": "imageClipIn", "duration": 2},
                            "changeHide": {"name": "imageSlideOut", "duration": 2}
                        }'
                        data-content-animation-plugins="controller events"
                        data-content-animation-item-selector="[data-content-animation-item-sub]"
                        data-content-animation-next-selector=":root .js-content-animation-advantages-1-next"
                        data-content-animation-prev-selector=":root .js-content-animation-advantages-1-prev"
                        data-content-animation-disable-next-prev="true"
                    >
                        <div class="content-animation background background--cover">
                                                            <div
                                    data-content-animation-item="sub-1"
                                    data-content-animation-item-sub="sub-1"
                                    class="background background--cover ui-background "
                                    aria-hidden="false"
                                >
                                                                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1777290624.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1777290624.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1777290624.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1777290624.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1777290624.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                    </div>
                                                    </div>
                    </div>
                </div>
            </div>
            <div class="advantages__content">
                <div class="advantages__counter px-layout py-4">
                    <span class="leading-trim">1</span>
                    <span class="advantages__counter-line"></span>
                    <span class="text-color-smallest leading-trim">5</span>
                </div>
                <div class="advantages__head">
                    <div class="col--xs-3 col--md-3 pl-layout">
                        <p class="h2 leading-trim">
                            lobby
                        </p>
                    </div>
                    <div class="col--xs-2 col--md-2 pr-layout">
                        <div class="group group--right group--middle group--arrows">
                                                    </div>
                    </div>
                </div>
                <div class="advantages__text col--xs-4 col--md-4 px-layout pl-0:md">
                                                                                                                                                            <div
                                            >
                        <div class="content-animation content-animation--bottom">
                                                                                                <div>
                                        <span class="text-offset"></span>
                                        <p class="leading-trim">
                                            Spacious and elegant lobbies welcome residents with&nbsp;impeccable interiors and a&nbsp;cozy lounge area, embodying the&nbsp;idea of&nbsp;impeccable style and understated luxury. Immerse yourself in&nbsp;an&nbsp;atmosphere of&nbsp;refined comfort comparable to&nbsp;the&nbsp;world's finest hote
                                        </p>
                                    </div>
                                                                                    </div>
                    </div>
                </div>
            </div>
        </div>
                <div class="advantages__container">
            <div class="advantages__image">
                <div class="content-animation background background--cover"
                    data-plugin="parallax"
                    data-parallax-measure-selector=".advantages__image"
                    data-parallax-enable-mq="sm-down"
                                        data-parallax-100-100='{"transform": "translateY(-5svh)"}'
                    data-parallax-0-0='{"transform": "translateY(0svh)"}'
                    data-parallax-mobile-smooth="true"
                >
                    <div
                        class=" background background--cover ui-background js-content-animation-advantages-2-controller"
                        data-plugin="contentAnimation"
                        data-content-animation-animations='{
                            "changeShow": {"name": "imageClipIn", "duration": 2},
                            "changeHide": {"name": "imageSlideOut", "duration": 2}
                        }'
                        data-content-animation-plugins="controller events"
                        data-content-animation-item-selector="[data-content-animation-item-sub]"
                        data-content-animation-next-selector=":root .js-content-animation-advantages-2-next"
                        data-content-animation-prev-selector=":root .js-content-animation-advantages-2-prev"
                        data-content-animation-disable-next-prev="true"
                    >
                        <div class="content-animation background background--cover">
                                                            <div
                                    data-content-animation-item="sub-1"
                                    data-content-animation-item-sub="sub-1"
                                    class="background background--cover ui-background "
                                    aria-hidden="false"
                                >
                                                                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="780">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="780">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1_1777290624.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1_1777290624.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="780">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1_1777290624.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="780">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1_1777290624.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1_1777290624.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                    </div>
                                                    </div>
                    </div>
                </div>
            </div>
            <div class="advantages__content">
                <div class="advantages__counter px-layout py-4">
                    <span class="leading-trim">2</span>
                    <span class="advantages__counter-line"></span>
                    <span class="text-color-smallest leading-trim">5</span>
                </div>
                <div class="advantages__head">
                    <div class="col--xs-3 col--md-3 pl-layout">
                        <p class="h2 leading-trim">
                            concierge<br>service
                        </p>
                    </div>
                    <div class="col--xs-2 col--md-2 pr-layout">
                        <div class="group group--right group--middle group--arrows">
                                                    </div>
                    </div>
                </div>
                <div class="advantages__text col--xs-4 col--md-4 px-layout pl-0:md">
                                                                                                                                                            <div
                                            >
                        <div class="content-animation content-animation--bottom">
                                                                                                <div>
                                        <span class="text-offset"></span>
                                        <p class="leading-trim">
                                            A&nbsp;personal assistant who takes care of&nbsp;your time and comfort. Transportation arrangements, ticket reservations, or everyday tasks — everything will be done with&nbsp;attention and professionalism.
                                        </p>
                                    </div>
                                                                                    </div>
                    </div>
                </div>
            </div>
        </div>
                <div class="advantages__container">
            <div class="advantages__image">
                <div class="content-animation background background--cover"
                    data-plugin="parallax"
                    data-parallax-measure-selector=".advantages__image"
                    data-parallax-enable-mq="sm-down"
                                        data-parallax-100-100='{"transform": "translateY(-5svh)"}'
                    data-parallax-0-0='{"transform": "translateY(0svh)"}'
                    data-parallax-mobile-smooth="true"
                >
                    <div
                        class=" background background--cover ui-background js-content-animation-advantages-3-controller"
                        data-plugin="contentAnimation"
                        data-content-animation-animations='{
                            "changeShow": {"name": "imageClipIn", "duration": 2},
                            "changeHide": {"name": "imageSlideOut", "duration": 2}
                        }'
                        data-content-animation-plugins="controller events"
                        data-content-animation-item-selector="[data-content-animation-item-sub]"
                        data-content-animation-next-selector=":root .js-content-animation-advantages-3-next"
                        data-content-animation-prev-selector=":root .js-content-animation-advantages-3-prev"
                        data-content-animation-disable-next-prev="true"
                    >
                        <div class="content-animation background background--cover">
                                                            <div
                                    data-content-animation-item="sub-1"
                                    data-content-animation-item-sub="sub-1"
                                    class="background background--cover ui-background "
                                    aria-hidden="false"
                                >
                                                                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_2_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="780">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_2_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="780">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_2_1777290624.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_2_1777290624.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_2_1777290624.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="780">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_2_1777290624.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="780">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_2_1777290624.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_2_1777290624.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                    </div>
                                                    </div>
                    </div>
                </div>
            </div>
            <div class="advantages__content">
                <div class="advantages__counter px-layout py-4">
                    <span class="leading-trim">3</span>
                    <span class="advantages__counter-line"></span>
                    <span class="text-color-smallest leading-trim">5</span>
                </div>
                <div class="advantages__head">
                    <div class="col--xs-3 col--md-3 pl-layout">
                        <p class="h2 leading-trim">
                            community<br>center
                        </p>
                    </div>
                    <div class="col--xs-2 col--md-2 pr-layout">
                        <div class="group group--right group--middle group--arrows">
                                                    </div>
                    </div>
                </div>
                <div class="advantages__text col--xs-4 col--md-4 px-layout pl-0:md">
                                                                                                                                                            <div
                                            >
                        <div class="content-animation content-animation--bottom">
                                                                                                <div>
                                        <span class="text-offset"></span>
                                        <p class="leading-trim">
                                            Playing, forgetting about&nbsp;everything in&nbsp;the&nbsp;world, sharing secrets with&nbsp;friends, drawing cartoon characters — the&nbsp;children's room opens the&nbsp;door to&nbsp;another world.
                                        </p>
                                    </div>
                                                                                    </div>
                    </div>
                </div>
            </div>
        </div>
                <div class="advantages__container">
            <div class="advantages__image">
                <div class="content-animation background background--cover"
                    data-plugin="parallax"
                    data-parallax-measure-selector=".advantages__image"
                    data-parallax-enable-mq="sm-down"
                                        data-parallax-100-100='{"transform": "translateY(-5svh)"}'
                    data-parallax-0-0='{"transform": "translateY(0svh)"}'
                    data-parallax-mobile-smooth="true"
                >
                    <div
                        class=" background background--cover ui-background js-content-animation-advantages-4-controller"
                        data-plugin="contentAnimation"
                        data-content-animation-animations='{
                            "changeShow": {"name": "imageClipIn", "duration": 2},
                            "changeHide": {"name": "imageSlideOut", "duration": 2}
                        }'
                        data-content-animation-plugins="controller events"
                        data-content-animation-item-selector="[data-content-animation-item-sub]"
                        data-content-animation-next-selector=":root .js-content-animation-advantages-4-next"
                        data-content-animation-prev-selector=":root .js-content-animation-advantages-4-prev"
                        data-content-animation-disable-next-prev="true"
                    >
                        <div class="content-animation background background--cover">
                                                            <div
                                    data-content-animation-item="sub-1"
                                    data-content-animation-item-sub="sub-1"
                                    class="background background--cover ui-background "
                                    aria-hidden="false"
                                >
                                                                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1777290625.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1777290625.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1777290625.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1777290625.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_1777290625.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_1777290625.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_1777290625.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_1777290625.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                    </div>
                                                    </div>
                    </div>
                </div>
            </div>
            <div class="advantages__content">
                <div class="advantages__counter px-layout py-4">
                    <span class="leading-trim">4</span>
                    <span class="advantages__counter-line"></span>
                    <span class="text-color-smallest leading-trim">5</span>
                </div>
                <div class="advantages__head">
                    <div class="col--xs-3 col--md-3 pl-layout">
                        <p class="h2 leading-trim">
                            co-working<br>space
                        </p>
                    </div>
                    <div class="col--xs-2 col--md-2 pr-layout">
                        <div class="group group--right group--middle group--arrows">
                                                    </div>
                    </div>
                </div>
                <div class="advantages__text col--xs-4 col--md-4 px-layout pl-0:md">
                                                                                                                                                            <div
                                            >
                        <div class="content-animation content-animation--bottom">
                                                                                                <div>
                                        <span class="text-offset"></span>
                                        <p class="leading-trim">
                                            If you have a&nbsp;brilliant business idea, discuss it with&nbsp;your colleagues without&nbsp;leaving your home. Spacious meeting rooms with&nbsp;high panoramic windows will help you present your project in&nbsp;the&nbsp;best light.
                                        </p>
                                    </div>
                                                                                    </div>
                    </div>
                </div>
            </div>
        </div>
                <div class="advantages__container">
            <div class="advantages__image">
                <div class="content-animation background background--cover"
                    data-plugin="parallax"
                    data-parallax-measure-selector=".advantages__image"
                    data-parallax-enable-mq="sm-down"
                                        data-parallax-100-100='{"transform": "translateY(-5svh)"}'
                    data-parallax-0-0='{"transform": "translateY(0svh)"}'
                    data-parallax-mobile-smooth="true"
                >
                    <div
                        class=" background background--cover ui-background js-content-animation-advantages-5-controller"
                        data-plugin="contentAnimation"
                        data-content-animation-animations='{
                            "changeShow": {"name": "imageClipIn", "duration": 2},
                            "changeHide": {"name": "imageSlideOut", "duration": 2}
                        }'
                        data-content-animation-plugins="controller events"
                        data-content-animation-item-selector="[data-content-animation-item-sub]"
                        data-content-animation-next-selector=":root .js-content-animation-advantages-5-next"
                        data-content-animation-prev-selector=":root .js-content-animation-advantages-5-prev"
                        data-content-animation-disable-next-prev="true"
                    >
                        <div class="content-animation background background--cover">
                                                            <div
                                    data-content-animation-item="sub-1"
                                    data-content-animation-item-sub="sub-1"
                                    class="background background--cover ui-background "
                                    aria-hidden="false"
                                >
                                                                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_3_1777290626.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_3_1777290626.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_3_1777290626.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_3_1777290626.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20600%22%3E%3C/svg%3E"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxxl/uploads/39/5_final_01_final_3_1777290626.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xxl/uploads/39/5_final_01_final_3_1777290626.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_advantages_slider_img_md/uploads/39/5_final_01_final_3_1777290626.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_advantages_slider_img_xs/uploads/39/5_final_01_final_3_1777290626.webp"                    alt=""                            width="720" height="600"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                                    </div>
                                                    </div>
                    </div>
                </div>
            </div>
            <div class="advantages__content">
                <div class="advantages__counter px-layout py-4">
                    <span class="leading-trim">5</span>
                    <span class="advantages__counter-line"></span>
                    <span class="text-color-smallest leading-trim">5</span>
                </div>
                <div class="advantages__head">
                    <div class="col--xs-3 col--md-3 pl-layout">
                        <p class="h2 leading-trim">
                            courtyard lounge with&nbsp;fireplace<br>and fountain
                        </p>
                    </div>
                    <div class="col--xs-2 col--md-2 pr-layout">
                        <div class="group group--right group--middle group--arrows">
                                                    </div>
                    </div>
                </div>
                <div class="advantages__text col--xs-4 col--md-4 px-layout pl-0:md">
                                                                                                                                                            <div
                                            >
                        <div class="content-animation content-animation--bottom">
                                                                                                <div>
                                        <span class="text-offset"></span>
                                        <p class="leading-trim">
                                            A&nbsp;secluded corner in&nbsp;the&nbsp;very center of&nbsp;the&nbsp;complex. Greenery, stylish design solutions, and cozy relaxation areas create an&nbsp;atmosphere of&nbsp;calm and harmony.
                                        </p>
                                    </div>
                                                                                    </div>
                    </div>
                </div>
            </div>
        </div>
            </div>
</section>
    


<section
    class="fitness section section--top ui-light"
    data-scroll-section
    data-plugin="reveal"
    data-themed-class="ui-light"
    data-scroll-snap-point='[
        { "viewport": 0, "element": 0, "scrollable": true }
    ]'
>
    <div class="fitness__color-desktop is-hidden--sm-down"
        data-themed-class="ui-dark"
        data-themed-add-class="header--fitness"
        data-z-index="2"
    ></div>
    <div
        class="fitness__sticky sticky-slider sticky-slider--full-screen"
        data-plugin="stickySlider"
        data-sticky-slider-enable-mq="md-up"
    >
        <div class="sticky-slider__sticky"
            data-scroll
            data-scroll-sticky
        >
            <div
                class="fitness__container row"
                data-sticky-slider-content
            >
                <div class="col col--md-12 is-hidden--sm-down is-decorative"></div>
                <div class="fitness__title col col--xs-4 col--md-2 px-layout pr-0:md mb-1 mb-0:md ui-background">
                    <h2 class="h3 text-right text-left:md leading-trim" data-reveal="text">
                        FITNESS CLUB<br />
WITH A 25m <br />
SWIMMING POOL
                    </h2>
                </div>
                <div class="col col--md-1 is-hidden--sm-down ui-background"></div>
                <div class="fitness__image-full col col--xs-4 col--md-6 px-layout px-0:md mb-1 mb-0:md ui-background">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-1@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221507%22%20height=%221424%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201507%201424%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1507" height="1424">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-1@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221185%22%20height=%221120%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201185%201120%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1185" height="1120">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-1@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22847%22%20height=%22800%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20847%20800%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="847" height="800">
        <img
            data-src="/assets/images/media/landing/11.fitness/image-1@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20342%22%3E%3C/svg%3E"                    alt=""                            width="320" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"                        style="object-position: 80% 20%;"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-1@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="1507" height="1424">                    <source srcset="/assets/images/media/landing/11.fitness/image-1@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1185" height="1120">                    <source srcset="/assets/images/media/landing/11.fitness/image-1@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="847" height="800">
        <img
            src="/assets/images/media/landing/11.fitness/image-1@xs.webp?v=1779376336"                    alt=""                            width="320" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"                        style="object-position: 80% 20%;"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </div>
                <div class="fitness__text-bottom col col--xs-4 col--md-3 px-layout pr-2:md mb-4 mb-0:md ui-background">
                    <p class="leading-trim" data-reveal="text">
                        Sport and luxury combine in&nbsp;the&nbsp;design of&nbsp;the&nbsp;spacious 25-meter swimming pool with&nbsp;3 lanes. Crystal clear water, soft comfortable sun loungers, light that dissolves the&nbsp;contours. An&nbsp;active workout in&nbsp;sporty chic style, relaxed relaxation with&nbsp;a&nbsp;detox cocktail, or meditation to&nbsp;the&nbsp;gentle sound of&nbsp;waves — what appeals to&nbsp;you today?
                    </p>
                </div>
                <div class="col col--md-1 is-hidden--sm-down ui-background"></div>
                <div class="fitness__image-2 col col--xs-4 col--md-3 is-hidden--sm-down ui-background">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-2@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22623%22%20height=%22747%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20623%20747%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-2@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22490%22%20height=%22588%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20490%20588%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-2@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22350%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20350%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            data-src="/assets/images/media/landing/11.fitness/image-2@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22250%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20250%20342%22%3E%3C/svg%3E"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-2@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source srcset="/assets/images/media/landing/11.fitness/image-2@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source srcset="/assets/images/media/landing/11.fitness/image-2@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            src="/assets/images/media/landing/11.fitness/image-2@xs.webp?v=1779376336"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </div>
                <div class="col col--xs-4 mb-1 is-hidden--md-up ui-background">
                    <ul class="fitness__scrollable mobile-scrollable">
                        <li class="mobile-scrollable__item">
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-3@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22641%22%20height=%22747%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20641%20747%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="747">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-3@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22504%22%20height=%22588%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20504%20588%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="588">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-3@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="420">
        <img
            data-src="/assets/images/media/landing/11.fitness/mobile/image-3.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22250%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20250%20342%22%3E%3C/svg%3E"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-3@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="747">                    <source srcset="/assets/images/media/landing/11.fitness/image-3@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="588">                    <source srcset="/assets/images/media/landing/11.fitness/image-3@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="420">
        <img
            src="/assets/images/media/landing/11.fitness/mobile/image-3.webp?v=1779376336"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </li>
                        <li class="mobile-scrollable__item">
                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-2@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22623%22%20height=%22747%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20623%20747%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-2@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22490%22%20height=%22588%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20490%20588%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-2@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22350%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20350%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            data-src="/assets/images/media/landing/11.fitness/mobile/image-2.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22250%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20250%20342%22%3E%3C/svg%3E"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-2@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source srcset="/assets/images/media/landing/11.fitness/image-2@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source srcset="/assets/images/media/landing/11.fitness/image-2@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            src="/assets/images/media/landing/11.fitness/mobile/image-2.webp?v=1779376336"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        </li>
                    </ul>
                </div>
                <div class="fitness__image-3 col col--xs-3 col--md-3 offset--xs-1 offset--md-0 pr-layout pr-0:md mb-6 mb-0:md ui-background">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move is-hidden--sm-down"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-3@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22641%22%20height=%22747%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20641%20747%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="747">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-3@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22504%22%20height=%22588%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20504%20588%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="588">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-3@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="420">
        <img
            data-src="/assets/images/media/landing/11.fitness/image-3@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22250%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20250%20342%22%3E%3C/svg%3E"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move is-hidden--sm-down"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-3@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="641" height="747">                    <source srcset="/assets/images/media/landing/11.fitness/image-3@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="504" height="588">                    <source srcset="/assets/images/media/landing/11.fitness/image-3@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="360" height="420">
        <img
            src="/assets/images/media/landing/11.fitness/image-3@xs.webp?v=1779376336"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                    <p class="leading-trim mt-0.66:md" data-reveal="text">
                        The&nbsp;soothing scent of&nbsp;wood and the&nbsp;crackling of&nbsp;hot stones in&nbsp;the&nbsp;sauna restore your strength and create a&nbsp;resort atmosphere any day you wish.
                    </p>
                </div>
                <div class="col col--md-2 is-hidden--sm-down ui-background"></div>
                <div class="fitness__text-middle col col--xs-4 col--md-3 px-layout pl-0:md mb-1 mb-0:md ui-background">
                    <p class="h3 leading-trim" data-reveal="text">
                        Smart trainers with&nbsp;artificial intelligence will help you maintain your beauty, strength, and flexibility. Crossovers with&nbsp;horizontal bars, power frames, butterfly machines — here, fitness becomes premium.
                    </p>
                </div>
                <div class="col col--md-1 is-hidden--sm-down ui-background"></div>
                <div class="fitness__image-full col col--xs-4 col--md-6 px-layout px-0:md mb-4 mb-0:md ui-background">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-4@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221282%22%20height=%221602%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201282%201602%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1282" height="1602">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-4@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221008%22%20height=%221260%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201008%201260%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1008" height="1260">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-4@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="/assets/images/media/landing/11.fitness/image-4@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20342%22%3E%3C/svg%3E"                    alt=""                            width="320" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"                        style="object-position: 20% 0%;"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-4@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="1282" height="1602">                    <source srcset="/assets/images/media/landing/11.fitness/image-4@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1008" height="1260">                    <source srcset="/assets/images/media/landing/11.fitness/image-4@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="/assets/images/media/landing/11.fitness/image-4@xs.webp?v=1779376336"                    alt=""                            width="320" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"                        style="object-position: 20% 0%;"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </div>
                <div class="row col col--xs-4 col--md-8 mb-6 mb-0:md ui-background">
                    <div class="fitness__text-bottom col col--xs-4 col--md-3 offset--xs-1 offset--md-0 pr-1.5 pl-layout:md pr-3:md mb-1 mb-0:md">
                        <p class="leading-trim" data-reveal="text">
                            Feel ironclad confidence and knock out&nbsp;all doubts about&nbsp;your own abilities. What does it take? Just head down&nbsp;to&nbsp;the&nbsp;boxing gym. Precisely balanced leather punching bags, hanging Thai boxing bags, modern equipment for&nbsp;developing coordination and agility — become not just the&nbsp;best, but the&nbsp;most powerful version of&nbsp;yourself.
                        </p>
                    </div>
                    <div class="fitness__image-5 col col--xs-3 col--md-5 col--order-first-md offset--xs-1 offset--md-0 pr-layout pr-0:md">
                        
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-5@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221050%22%20height=%22747%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201050%20747%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1050" height="747">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-5@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22826%22%20height=%22588%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20826%20588%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="826" height="588">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-5@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22590%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20590%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="590" height="420">
        <img
            data-src="/assets/images/media/landing/11.fitness/image-5@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22250%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20250%20342%22%3E%3C/svg%3E"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-5@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="1050" height="747">                    <source srcset="/assets/images/media/landing/11.fitness/image-5@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="826" height="588">                    <source srcset="/assets/images/media/landing/11.fitness/image-5@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="590" height="420">
        <img
            src="/assets/images/media/landing/11.fitness/image-5@xs.webp?v=1779376336"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                    </div>
                </div>
                <div class="col col--md-1 is-hidden--sm-down ui-background"></div>
                <div class="fitness__image-6 col col--xs-4 col--md-3 is-hidden--sm-down ui-background">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-6@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22623%22%20height=%22747%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20623%20747%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-6@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22490%22%20height=%22588%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20490%20588%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-6@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22350%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20350%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            data-src="/assets/images/media/landing/11.fitness/image-6@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22250%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20250%20342%22%3E%3C/svg%3E"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-6@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source srcset="/assets/images/media/landing/11.fitness/image-6@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source srcset="/assets/images/media/landing/11.fitness/image-6@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            src="/assets/images/media/landing/11.fitness/image-6@xs.webp?v=1779376336"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </div>
                <div class="fitness__image-full col col--xs-4 col--md-8 px-layout px-0:md mb-1 mb-0:md ui-background">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-7@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221709%22%20height=%221210%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201709%201210%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1709" height="1210">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-7@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221344%22%20height=%22951%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201344%20951%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1344" height="951">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-7@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22960%22%20height=%22680%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20960%20680%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="960" height="680">
        <img
            data-src="/assets/images/media/landing/11.fitness/image-7@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20342%22%3E%3C/svg%3E"                    alt=""                            width="320" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"                        style="object-position: 50% 20%;"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-7@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="1709" height="1210">                    <source srcset="/assets/images/media/landing/11.fitness/image-7@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1344" height="951">                    <source srcset="/assets/images/media/landing/11.fitness/image-7@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="960" height="680">
        <img
            src="/assets/images/media/landing/11.fitness/image-7@xs.webp?v=1779376336"                    alt=""                            width="320" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"                        style="object-position: 50% 20%;"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </div>
                <div class="fitness__text-bottom col col--xs-4 col--md-3 px-layout pr-0:md mb-4 mb-0:md ui-background">
                    <p class="h3 leading-trim" data-reveal="text">
                        The&nbsp;yoga studio offers a&nbsp;smooth transition to&nbsp;relaxation, bringing your mind and body into&nbsp;harmony. Soft lighting, the&nbsp;relaxing voice of&nbsp;the&nbsp;instructor, and the&nbsp;calm rhythm of&nbsp;the&nbsp;movements will help you find your balance.
                    </p>
                </div>
                <div class="col col--xs-3 offset--xs-1 pr-layout is-hidden--md-up ui-background">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-6@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22623%22%20height=%22747%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20623%20747%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-6@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22490%22%20height=%22588%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20490%20588%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source
        data-srcset="/assets/images/media/landing/11.fitness/image-6@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22350%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20350%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            data-src="/assets/images/media/landing/11.fitness/image-6@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22250%22%20height=%22342%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20250%20342%22%3E%3C/svg%3E"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/11.fitness/image-6@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source srcset="/assets/images/media/landing/11.fitness/image-6@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source srcset="/assets/images/media/landing/11.fitness/image-6@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            src="/assets/images/media/landing/11.fitness/image-6@xs.webp?v=1779376336"                    alt=""                            width="250" height="342"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                </div>
                <div class="col col--xs-4 col--md-1 is-hidden--sm-down ui-background"></div>
                <div class="col col--md-12 is-hidden--sm-down is-decorative"></div>
            </div>
        </div>
    </div>
</section>
    
<section
    class="section"
    data-scroll-section
>
    
<div
    id="infrastructure"
    class="infrastructure-hero section ui-dark ui-background"
    data-themed-class="ui-dark"
    data-plugin="reveal history"
    data-history-offset-top="100"
    data-history-offset-bottom="200"
    data-history-offset-top-mobile="0"
    data-history-offset-top-mobile="0"
    >
    <div class="infrastructure-hero__sticky sticky sticky:md-up sticky--under-next sticky--under-previous sticky--full-height"
        data-plugin="parallax"
        data-parallax-measure-selector=".section"
        data-parallax-enable-mq="md-up"
        data-parallax-clamp="true"
        data-parallax-0-0='{"transform": "translateX(10svh)"}'
        data-parallax-333-100='{"transform": "translateX(0svh)"}'
    >
        <div class="infrastructure-hero__snap"
            data-scroll-snap-point='[
                { "viewport": 0, "element": 0 }
            ]'
        ></div>
        <div
            class="sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
        >
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js infrastructure-hero__image background background--cover"                        data-parallax-enable-mq="md-up"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".section"            data-parallax-333-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"            data-parallax-200-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-5svh&#x29;&quot;&#x7D;"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_bg_xxxl/uploads/39/image_2_1777295254.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222563%22%20height=%221388%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202563%201388%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2563" height="1388">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_bg_xxl/uploads/39/image_2_1777295254.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222016%22%20height=%221092%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202016%201092%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="2016" height="1092">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_bg_md/uploads/39/image_2_1777295254.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221440%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201440%20780%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1440" height="780">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_infrastructure_bg_xs/uploads/39/image_2_1777295254.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20640%22%3E%3C/svg%3E"                    alt=""                            width="360" height="640"                                        data-plugin="parallax"                        data-parallax-enable-mq="sm-down"                        data-parallax-clamp="true"                        data-parallax-measure-selector="picture"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" infrastructure-hero__image background background--cover"                        data-parallax-enable-mq="md-up"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".section"            data-parallax-333-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"            data-parallax-200-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-5svh&#x29;&quot;&#x7D;"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_bg_xxxl/uploads/39/image_2_1777295254.webp" media="(min-width: 1920px) and (min-height: 700px)" width="2563" height="1388">                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_bg_xxl/uploads/39/image_2_1777295254.webp" media="(min-width: 1440px) and (min-height: 700px)" width="2016" height="1092">                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_bg_md/uploads/39/image_2_1777295254.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1440" height="780">
        <img
            src="https://zorge9.estate/media/cache/homepage_infrastructure_bg_xs/uploads/39/image_2_1777295254.webp"                    alt=""                            width="360" height="640"                                        data-plugin="parallax"                        data-parallax-enable-mq="sm-down"                        data-parallax-clamp="true"                        data-parallax-measure-selector="picture"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    

            <div class="infrastructure-hero__content pb-2 pb-layout:md">
                <div class="px-layout"
                    data-plugin="parallax"
                    data-parallax-enable-mq="md-up"
                    data-parallax-clamp="true"
                    data-parallax-measure-selector=".section"
                    data-parallax-333-100='{"transform": "translateY(0svh)"}'
                    data-parallax-200-100='{"transform": "translateY(-10svh)"}'
                >
                    <h2 class="h1 text-right leading-trim" data-reveal="text" data-reveal-distance="0">
                        INFRASTRUCTURE
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>
    

<div
    class="infrastructure section section--full-height ui-dark ui-background"
    data-themed-class="ui-dark"
    data-themed-add-class="header__logo--infrastructure"
    data-plugin="history"
    data-history-id="infrastructure"
    data-scroll-snap-point='[
        { "viewport": 0, "element": 0 }
    ]'
>
    <div class="sticky sticky--under-next sticky--under-previous sticky--full-height"
        data-plugin="parallax"
        data-parallax-pattern="sectionOutTiny"
        data-parallax-enable-mq="md-up"
    >
        <div
            class="sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
        >
            <div
                class="infrastructure__container section__content"
            >
                <div
                    class="infrastructure__image js-content-animation-infrastructure-controller ui-light ui-background js-scroll-parent-ignore"
                    data-plugin="contentAnimation"
                    data-content-animation-animations='{
                        "changeShow": {"name": "imageClipIn", "duration": 2},
                        "changeHide": {"name": "imageSlideOut", "duration": 2}
                    }'
                    data-content-animation-plugins="controller events counter"
                    data-content-animation-counter-selector=":root .js-content-animation-infrastructure-counter"
                    data-content-animation-next-selector=":root .js-content-animation-infrastructure-next"
                    data-content-animation-prev-selector=":root .js-content-animation-infrastructure-prev"
                    data-content-animation-disable-next-prev="true"
                >
                    <div class="infrastructure__image-container">
                        <div class="content-animation content-animation--cover"
                            data-plugin="parallax"
                            data-parallax-pattern="infrastructureImage infrastructureImageMobile"
                            data-parallax-mobile-smooth="true"
                        >
                                                            <div
                                    data-content-animation-item="0"
                                    class="infrastructure__image-item ui-background "
                                >
                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxxl/uploads/39/img_4055_1_1777295251.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22660%22%20height=%22520%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20660%20520%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="660" height="520">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxl/uploads/39/img_4055_1_1777295251.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22660%22%20height=%22520%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20660%20520%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="660" height="520">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_md/uploads/39/img_4055_1_1777295251.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22660%22%20height=%22520%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20660%20520%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="660" height="520">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xs/uploads/39/img_4055_1_1777295251.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20640%22%3E%3C/svg%3E"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxxl/uploads/39/img_4055_1_1777295251.webp" media="(min-width: 1920px) and (min-height: 700px)" width="660" height="520">                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxl/uploads/39/img_4055_1_1777295251.webp" media="(min-width: 1440px) and (min-height: 700px)" width="660" height="520">                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_md/uploads/39/img_4055_1_1777295251.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="660" height="520">
        <img
            src="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xs/uploads/39/img_4055_1_1777295251.webp"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                </div>
                                                            <div
                                    data-content-animation-item="1"
                                    class="infrastructure__image-item ui-background is-hidden"
                                >
                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxxl/uploads/39/img_4055_2_1777295279.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22660%22%20height=%22520%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20660%20520%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="660" height="520">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxl/uploads/39/img_4055_2_1777295279.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22660%22%20height=%22520%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20660%20520%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="660" height="520">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_md/uploads/39/img_4055_2_1777295279.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22660%22%20height=%22520%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20660%20520%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="660" height="520">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xs/uploads/39/img_4055_2_1777295279.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20640%22%3E%3C/svg%3E"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxxl/uploads/39/img_4055_2_1777295279.webp" media="(min-width: 1920px) and (min-height: 700px)" width="660" height="520">                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxl/uploads/39/img_4055_2_1777295279.webp" media="(min-width: 1440px) and (min-height: 700px)" width="660" height="520">                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_md/uploads/39/img_4055_2_1777295279.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="660" height="520">
        <img
            src="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xs/uploads/39/img_4055_2_1777295279.webp"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                </div>
                                                            <div
                                    data-content-animation-item="2"
                                    class="infrastructure__image-item ui-background is-hidden"
                                >
                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxxl/uploads/39/img_4055_1777295252.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22660%22%20height=%22520%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20660%20520%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="660" height="520">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxl/uploads/39/img_4055_1777295252.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22660%22%20height=%22520%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20660%20520%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="660" height="520">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_md/uploads/39/img_4055_1777295252.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22660%22%20height=%22520%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20660%20520%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="660" height="520">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xs/uploads/39/img_4055_1777295252.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20640%22%3E%3C/svg%3E"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxxl/uploads/39/img_4055_1777295252.webp" media="(min-width: 1920px) and (min-height: 700px)" width="660" height="520">                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xxl/uploads/39/img_4055_1777295252.webp" media="(min-width: 1440px) and (min-height: 700px)" width="660" height="520">                    <source srcset="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_md/uploads/39/img_4055_1777295252.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="660" height="520">
        <img
            src="https://zorge9.estate/media/cache/homepage_infrastructure_slider_img_xs/uploads/39/img_4055_1777295252.webp"                    alt=""                            width="720" height="640"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                </div>
                                                    </div>
                    </div>
                </div>
                <div class="infrastructure__content">
                    <div class="infrastructure__controls">
                        <p class="infrastructure__counter">
                            <span class="leading-trim js-content-animation-infrastructure-counter">1</span>
                            <span class="infrastructure__counter-line"></span>
                            <span class="text-color-smallest leading-trim">3</span>
                        </p>

                                                    <div class="group group--right group--middle group--arrows">
                                        
        
                                                                      
            

        
                
        
        
        
    <a
        class="btn btn--link btn--link-static btn--animate-icon js-content-animation-infrastructure-prev is-disabled"
                                                                                                                                                        aria-label="Previous item"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-long-arrow-left" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left"></use></svg>
                                                    <svg class="icon icon-long-arrow-left" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-left"></use></svg>
                                            </span>
                                    </span>
    </a>
                                        
        
                                                                      
            

        
                
        
        
        
    <a
        class="btn btn--link btn--link-static btn--animate-icon js-content-animation-infrastructure-next"
                                                                                                                                                        aria-label="Next item"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-long-arrow-right" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right"></use></svg>
                                                    <svg class="icon icon-long-arrow-right" width="41" height="14" aria-hidden="true"            viewBox="0 0 41 14"
            style="--icon-width: 41; --icon-height: 14;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-right"></use></svg>
                                            </span>
                                    </span>
    </a>
                            </div>
                                            </div>
                    <div class="infrastructure__head">
                        <p class="text-small leading-trim px-layout mb-1 is-hidden--sm-down">
                            INFRASTRUCTURE
                        </p>
                        <div
                            class="col--xs-3 col--md-3 px-layout pr-0:md"
                            data-plugin="contentAnimation"
                            data-content-animation-plugins="controller height"
                                data-content-animation-animations='{
                                    "changeShow": {"name": "text"},
                                    "changeHide": {"name": "textOut"}
                                }'
                            data-content-animation-fixed-height="true"
                            data-content-animation-controller-selector=":root .js-content-animation-infrastructure-controller"
                        >
                            <div class="content-animation">
                                                                    <p
                                        class="h2 leading-trim "
                                        data-content-animation-item="0"
                                        aria-hidden="false"
                                                                                    data-reveal="text" data-reveal-distance="0"
                                                                            >
                                        Restaurant<br>and bar
                                    </p>
                                                                    <p
                                        class="h2 leading-trim is-hidden"
                                        data-content-animation-item="1"
                                        aria-hidden="true"
                                                                            >
                                        Beauty salon
                                    </p>
                                                                    <p
                                        class="h2 leading-trim is-hidden"
                                        data-content-animation-item="2"
                                        aria-hidden="true"
                                                                            >
                                        spa & grooming
                                    </p>
                                                            </div>
                        </div>
                    </div>
                    <div class="infrastructure__text col--xs-4 col--md-4 px-layout pl-0:md"
                        data-plugin="contentAnimation"
                        data-content-animation-plugins="controller"
                        data-content-animation-animations='{
                            "changeShow": {"name": "text"},
                            "changeHide": {"name": "textOut"}
                        }'
                        data-content-animation-fixed-height="true"
                        data-content-animation-controller-selector=":root .js-content-animation-infrastructure-controller"
                    >
                        <div class="content-animation content-animation--bottom">
                                                            <div
                                    data-content-animation-item="0"
                                    class=""
                                    aria-hidden="false"
                                                                            data-reveal="text" data-reveal-distance="0"
                                                                    >
                                    <div>
                                        <span class="text-offset"></span>
                                        <p class="leading-trim">
                                            The&nbsp;captivatingly beautiful restaurant will win you over&nbsp;with&nbsp;its signature dishes and carefully curated wine collection. Here, time stands still so you can fully immerse yourself in&nbsp;your senses.
                                        </p>
                                    </div>
                                </div>
                                                            <div
                                    data-content-animation-item="1"
                                    class="is-hidden"
                                    aria-hidden="true"
                                                                    >
                                    <div>
                                        <span class="text-offset"></span>
                                        <p class="leading-trim">
                                            Bright beauty trends and new classics, Hollywood curls and creative coloring, “blogger” manicures and professional facial care — the&nbsp;masters at&nbsp;Beauty salon can do it all and even more.
                                        </p>
                                    </div>
                                </div>
                                                            <div
                                    data-content-animation-item="2"
                                    class="is-hidden"
                                    aria-hidden="true"
                                                                    >
                                    <div>
                                        <span class="text-offset"></span>
                                        <p class="leading-trim">
                                            Want to&nbsp;treat your furry friend to&nbsp;a&nbsp;creative haircut or spa? Pet care is easier with&nbsp;professional grooming. Save time and energy — everything you need for&nbsp;your friend&#039;s comfort is within&nbsp;walking distance.
                                        </p>
                                    </div>
                                </div>
                                                    </div>
                    </div>
                </div>
            </div>
            <div class="infrastructure__shadow is-hidden--sm-down"
                data-plugin="parallax"
                data-parallax-enable-mq="md-up"
                data-parallax-clamp="true"
                data-parallax-measure-selector=".section"
                data-parallax-0-0='{"opacity": "0"}'
                data-parallax--100-0='{"opacity": "1"}'
            ></div>
        </div>
    </div>
</div>
</section>
    
<section
    id="improvement"
    class="improvement section section--top pb-2 ui-light ui-background"
    data-scroll-section
    data-themed-class="ui-light"
    data-plugin="reveal history"
    data-z-index="2"
    data-scroll-snap-point='[
        { "viewport": 0, "element": 0, "scrollable": true },
        { "viewport": 0, "element": 100, "scrollable": true }
    ]'
>

    <div class="row mb-6 mb-7:md">
        <div class="col col--xs-4 col--md-5 px-layout pr-0:md">
            <p class="leading-trim" data-reveal="text">
                Rustling tree crowns, flower beds and a&nbsp;sculptural fountain that refreshes on&nbsp;hot days, scattering sun-drenched spray. A&nbsp;cozy place to&nbsp;relax, surrounded by&nbsp;premium greenery brought from&nbsp;the&nbsp;best German nurseries.
            </p>
        </div>
    </div>
    <div class="row">
        <div class="col col--xs-4 col--md-5 col--xxxl-6 offset--md-7 offset--xxxl-6 px-layout pl-0:md mb-1">
            <h2 class="h1 leading-trim text-right" data-reveal="text">
                PRIVATE<br />
2-ACRE PARK
            </h2>
        </div>
        <div class="improvement__image-1 col col--xs-4 col--md-3 offset--md-3 is-hidden--sm-down">
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_improvement_img_1_xxxl/uploads/39/image_20_1777295667.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22623%22%20height=%22747%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20623%20747%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_improvement_img_1_xxl/uploads/39/image_20_1777295667.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22490%22%20height=%22588%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20490%20588%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_improvement_img_1_md/uploads/39/image_20_1777295667.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22350%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20350%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_improvement_img_1_xs/uploads/39/image_20_1777295667.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22433%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20433%22%3E%3C/svg%3E"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_improvement_img_1_xxxl/uploads/39/image_20_1777295667.webp" media="(min-width: 1920px) and (min-height: 700px)" width="623" height="747">                    <source srcset="https://zorge9.estate/media/cache/homepage_improvement_img_1_xxl/uploads/39/image_20_1777295667.webp" media="(min-width: 1440px) and (min-height: 700px)" width="490" height="588">                    <source srcset="https://zorge9.estate/media/cache/homepage_improvement_img_1_md/uploads/39/image_20_1777295667.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="350" height="420">
        <img
            src="https://zorge9.estate/media/cache/homepage_improvement_img_1_xs/uploads/39/image_20_1777295667.webp"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
        </div>
        <div class="col col--xs-4 col--md-6 px-layout pl-0:md">
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_improvement_img_2_xxxl/uploads/39/image_19_1777295653.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221228%22%20height=%221281%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201228%201281%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1281">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_improvement_img_2_xxl/uploads/39/image_19_1777295653.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22966%22%20height=%221008%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20966%201008%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="1008">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_improvement_img_2_md/uploads/39/image_19_1777295653.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22690%22%20height=%22720%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20690%20720%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="690" height="720">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_improvement_img_2_xs/uploads/39/image_19_1777295653.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22433%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20433%22%3E%3C/svg%3E"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_improvement_img_2_xxxl/uploads/39/image_19_1777295653.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1281">                    <source srcset="https://zorge9.estate/media/cache/homepage_improvement_img_2_xxl/uploads/39/image_19_1777295653.webp" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="1008">                    <source srcset="https://zorge9.estate/media/cache/homepage_improvement_img_2_md/uploads/39/image_19_1777295653.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="690" height="720">
        <img
            src="https://zorge9.estate/media/cache/homepage_improvement_img_2_xs/uploads/39/image_19_1777295653.webp"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
        </div>
        <div class="col col--xs-4 col--md-9 offset--md-3 px-layout pl-0:md mt-1">
            <p class="h2 leading-trim" data-reveal="text">
                <span class="text-offset text-offset--3 is-hidden--sm-down"></span>
                Fresh air and birdsong will lead you to&nbsp;your own park. Here, lush maple trees rustle in&nbsp;the&nbsp;wind and birch branches sway gently. The&nbsp;nature of&nbsp;free time is embodied in&nbsp;the&nbsp;freedom of&nbsp;your plans.
            </p>
        </div>
    </div>
    <div class="row mt-6 mt-8:md px-layout">
        
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/14.improvement/bottom@xxxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222456%22%20height=%221619%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202456%201619%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1619">                    <source
        data-srcset="/assets/images/media/landing/14.improvement/bottom@xxl.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221932%22%20height=%221274%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201932%201274%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1274">                    <source
        data-srcset="/assets/images/media/landing/14.improvement/bottom@md.webp?v=1779376336"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221380%22%20height=%22910%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201380%20910%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="910">
        <img
            data-src="/assets/images/media/landing/14.improvement/bottom@xs.webp?v=1779376336"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22320%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20320%22%3E%3C/svg%3E"                    alt=""                            width="360" height="320"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="/assets/images/media/landing/14.improvement/bottom@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="2456" height="1619">                    <source srcset="/assets/images/media/landing/14.improvement/bottom@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1932" height="1274">                    <source srcset="/assets/images/media/landing/14.improvement/bottom@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1380" height="910">
        <img
            src="/assets/images/media/landing/14.improvement/bottom@xs.webp?v=1779376336"                    alt=""                            width="360" height="320"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
    </div>
</section>
    
<section
    class="section"
    data-scroll-section
>
    
<div
    class="section section--full-height ui-dark ui-background is-hidden--md-up"
    data-themed-class="ui-dark"
    data-plugin="reveal history"
    data-z-index="2"
    data-history-id="apartments"
>
    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js apartments-hero-image background background--cover"            data-plugin="appear "        draggable="false"    >
        <img
            data-src="/assets/images/media/landing/15.apartments-hero/background-xs.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20640%22%3E%3C/svg%3E"                    alt=""                            width="360" height="640"                                        data-plugin="parallax"                        data-parallax-enable-mq="sm-down"                        data-parallax-clamp="true"                        data-parallax-measure-selector="picture"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" apartments-hero-image background background--cover"        draggable="false"    >
        <img
            src="/assets/images/media/landing/15.apartments-hero/background-xs.webp"                    alt=""                            width="360" height="640"                                        data-plugin="parallax"                        data-parallax-enable-mq="sm-down"                        data-parallax-clamp="true"                        data-parallax-measure-selector="picture"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    

    <div class="apartments-hero-content pb-2 pb-layout:md">
        <div class="px-layout">
            <h2 class="h1 text-right text-left:md leading-trim" data-reveal="text">
                SPLENDID<br />
APARTMENTS
            </h2>
        </div>
        <div class="row">
            <div class="col col--xs-4 col--md-5 offset--md-7 px-layout pl-0:md">
                <p class="leading-trim" data-reveal="text">
                    <span class="text-offset is-hidden--sm-down"></span>
                    Refined finishes, neoclassical furniture, and beauty imprinted in&nbsp;every detail—the&nbsp;atmosphere of&nbsp;these apartments makes you want to&nbsp;immerse yourself in&nbsp;them again and again. These apartments offer breathtaking views of&nbsp;the&nbsp;capital&#039;s magnificent buildings, which transform into&nbsp;a&nbsp;watercolor landscape on&nbsp;the&nbsp;wall of&nbsp;your living room.
                </p>
            </div>
        </div>
    </div>
</div>
    


<div
    id="apartments"
    class="apartments section ui-dark ui-background"
    data-themed-class="ui-dark"
    data-plugin="reveal history"
    data-history-offset-top="100"
    data-history-offset-bottom="100"
    data-scroll-snap-point='[
        { "viewport": 100, "element": 0 },
        { "viewport": 200, "element": 0 }
    ]'
>
    <div class="apartments__hide-header"
        data-themed-class="ui-dark"
        data-themed-add-class="header--apartments"
        data-z-index="2"
    >
    </div>
    <div class="sticky sticky--under-next sticky--under-previous sticky--full-height">
        <div class="sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
        >
            <div class="apartments__container row">
                <div class="apartments__content col--xs-4 col--md-6 px-layout py-2 py-layout:md"
                                    >
                    <div class="group apartments__type group--nowrap-mobile pb-1">
                                                            
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn apartments__type-item btn--link btn--text-small js-content-animation-apartments-link is-active"
                                                                                                                                                                                            data-content-animation-id="apartments-studios"
                            tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    studios

                                    </span>
            
                    </span>
    </a>
                                                            
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn apartments__type-item btn--link btn--text-small js-content-animation-apartments-link"
                                                                                                                                                                                            data-content-animation-id="apartments-1BR"
                            tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    1BR

                                    </span>
            
                    </span>
    </a>
                                                            
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn apartments__type-item btn--link btn--text-small js-content-animation-apartments-link"
                                                                                                                                                                                            data-content-animation-id="apartments-2BR"
                            tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    2BR

                                    </span>
            
                    </span>
    </a>
                                                            
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn apartments__type-item btn--link btn--text-small js-content-animation-apartments-link"
                                                                                                                                                                                            data-content-animation-id="apartments-3br"
                            tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    3br

                                    </span>
            
                    </span>
    </a>
                                                            
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn apartments__type-item btn--link btn--text-small js-content-animation-apartments-link"
                                                                                                                                                                                            data-content-animation-id="apartments-with terraces"
                            tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    with terraces

                                    </span>
            
                    </span>
    </a>
                                                            
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn apartments__type-item btn--link btn--text-small js-content-animation-apartments-link"
                                                                                                                                                                                            data-content-animation-id="apartments-penthouse"
                            tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    penthouse

                                    </span>
            
                    </span>
    </a>
                                            </div>
                    <hr class="mb-1">
                    <div class="group group--none group--nowrap group--between mb-1">
                        <div
                            class=""
                            data-plugin="contentAnimation"
                            data-content-animation-animations='{
                                "changeShow": {"name": "text"},
                                "changeHide": {"name": "textOut"}
                            }'
                            data-content-animation-plugins="controller"
                            data-content-animation-controller-selector=":root .js-apartments-content-animation-controller"
                        >
                            <div class="content-animation">
                                                                    <div
                                        data-content-animation-item="apartments-studios"
                                        class=""
                                        aria-hidden="false"
                                    >
                                        <p class="apartments__area group">
                                            <span class="h1-large leading-trim">26-30</span>
                                            <span class="h2 leading-trim">м<sup>2</sup></span>
                                        </p>
                                    </div>
                                                                    <div
                                        data-content-animation-item="apartments-1BR"
                                        class="is-hidden"
                                        aria-hidden="true"
                                    >
                                        <p class="apartments__area group">
                                            <span class="h1-large leading-trim">36-65</span>
                                            <span class="h2 leading-trim">м<sup>2</sup></span>
                                        </p>
                                    </div>
                                                                    <div
                                        data-content-animation-item="apartments-2BR"
                                        class="is-hidden"
                                        aria-hidden="true"
                                    >
                                        <p class="apartments__area group">
                                            <span class="h1-large leading-trim">56-67</span>
                                            <span class="h2 leading-trim">м<sup>2</sup></span>
                                        </p>
                                    </div>
                                                                    <div
                                        data-content-animation-item="apartments-3br"
                                        class="is-hidden"
                                        aria-hidden="true"
                                    >
                                        <p class="apartments__area group">
                                            <span class="h1-large leading-trim">64-80</span>
                                            <span class="h2 leading-trim">м<sup>2</sup></span>
                                        </p>
                                    </div>
                                                                    <div
                                        data-content-animation-item="apartments-with terraces"
                                        class="is-hidden"
                                        aria-hidden="true"
                                    >
                                        <p class="apartments__area group">
                                            <span class="h1-large leading-trim">67-81</span>
                                            <span class="h2 leading-trim">м<sup>2</sup></span>
                                        </p>
                                    </div>
                                                                    <div
                                        data-content-animation-item="apartments-penthouse"
                                        class="is-hidden"
                                        aria-hidden="true"
                                    >
                                        <p class="apartments__area group">
                                            <span class="h1-large leading-trim">60-150</span>
                                            <span class="h2 leading-trim">м<sup>2</sup></span>
                                        </p>
                                    </div>
                                                            </div>
                        </div>
                    </div>

                    <div
                        class="apartments__plan js-apartments-content-animation-controller mt-auto mb-auto"
                        data-plugin="contentAnimation"
                        data-content-animation-animations='{
                            "changeShow": {"name": "fadeIn"},
                            "changeHide": {"name": "fadeOut"}
                        }'
                        data-content-animation-plugins="controller events swipe"
                        data-content-animation-link-selector=":root .js-content-animation-apartments-link"
                    >
                        <div class="content-animation content-animation--center">
                                                            <div
                                    data-content-animation-item="apartments-studios"
                                    class="ui-background "
                                    aria-hidden="false"
                                >
                                    
                
    
    <img class="img-full is-invisible--js is-hidden--no-js"
        draggable="false"
                                    width="540"                        height="420"                        alt="studios"                data-plugin="appear "
             data-src="/uploads/1/studio_1755094133.png?v=1779376336"
            src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22540%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20540%20420%22%3E%3C/svg%3E"    >

                <noscript>
            
    
    
    <img class="img-full "
        draggable="false"                                    width="540"                        height="420"                        alt="studios"
                src="/uploads/1/studio_1755094133.png?v=1779376336"    >

        
        </noscript>
                                </div>
                                                            <div
                                    data-content-animation-item="apartments-1BR"
                                    class="ui-background is-hidden"
                                    aria-hidden="true"
                                >
                                    
                
    
    <img class="img-full is-invisible--js is-hidden--no-js"
        draggable="false"
                                    width="540"                        height="420"                        alt="1BR"                data-plugin="appear "
             data-src="/uploads/1/1К_1_1755097564.png?v=1779376336"
            src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22540%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20540%20420%22%3E%3C/svg%3E"    >

                <noscript>
            
    
    
    <img class="img-full "
        draggable="false"                                    width="540"                        height="420"                        alt="1BR"
                src="/uploads/1/1К_1_1755097564.png?v=1779376336"    >

        
        </noscript>
                                </div>
                                                            <div
                                    data-content-animation-item="apartments-2BR"
                                    class="ui-background is-hidden"
                                    aria-hidden="true"
                                >
                                    
                
    
    <img class="img-full is-invisible--js is-hidden--no-js"
        draggable="false"
                                    width="540"                        height="420"                        alt="2BR"                data-plugin="appear "
             data-src="/uploads/1/2К_1_1755097563.png?v=1779376336"
            src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22540%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20540%20420%22%3E%3C/svg%3E"    >

                <noscript>
            
    
    
    <img class="img-full "
        draggable="false"                                    width="540"                        height="420"                        alt="2BR"
                src="/uploads/1/2К_1_1755097563.png?v=1779376336"    >

        
        </noscript>
                                </div>
                                                            <div
                                    data-content-animation-item="apartments-3br"
                                    class="ui-background is-hidden"
                                    aria-hidden="true"
                                >
                                    
                
    
    <img class="img-full is-invisible--js is-hidden--no-js"
        draggable="false"
                                    width="540"                        height="420"                        alt="3br"                data-plugin="appear "
             data-src="/uploads/1/3К_1_1755097563.png?v=1779376336"
            src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22540%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20540%20420%22%3E%3C/svg%3E"    >

                <noscript>
            
    
    
    <img class="img-full "
        draggable="false"                                    width="540"                        height="420"                        alt="3br"
                src="/uploads/1/3К_1_1755097563.png?v=1779376336"    >

        
        </noscript>
                                </div>
                                                            <div
                                    data-content-animation-item="apartments-with terraces"
                                    class="ui-background is-hidden"
                                    aria-hidden="true"
                                >
                                    
                
    
    <img class="img-full is-invisible--js is-hidden--no-js"
        draggable="false"
                                    width="540"                        height="420"                        alt="with terraces"                data-plugin="appear "
             data-src="/uploads/1/3К_1_1755097563.png?v=1779376336"
            src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22540%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20540%20420%22%3E%3C/svg%3E"    >

                <noscript>
            
    
    
    <img class="img-full "
        draggable="false"                                    width="540"                        height="420"                        alt="with terraces"
                src="/uploads/1/3К_1_1755097563.png?v=1779376336"    >

        
        </noscript>
                                </div>
                                                            <div
                                    data-content-animation-item="apartments-penthouse"
                                    class="ui-background is-hidden"
                                    aria-hidden="true"
                                >
                                    
                
    
    <img class="img-full is-invisible--js is-hidden--no-js"
        draggable="false"
                                    width="540"                        height="420"                        alt="penthouse"                data-plugin="appear "
             data-src="/uploads/1/Пентхаус_1_1755097563.png?v=1779376336"
            src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22540%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20540%20420%22%3E%3C/svg%3E"    >

                <noscript>
            
    
    
    <img class="img-full "
        draggable="false"                                    width="540"                        height="420"                        alt="penthouse"
                src="/uploads/1/Пентхаус_1_1755097563.png?v=1779376336"    >

        
        </noscript>
                                </div>
                                                    </div>
                    </div>
                    <div class=" mt-1">
                         <p class="text-small leading-trim">
                            <span class="text-color-primary">Purchase conditions:</span> <br>
                             mortgage, 0% installment plan, trade-in
                        </p>
                    </div>
                </div>
                <div class="col--md-6 apartments__image is-hidden--sm-down"
                >
                    <div class="apartments__image-item"
                    >
                        
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"                        data-parallax-measure-selector=".section"                        data-parallax-clamp="true"            data-parallax-0-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;10svh&#x29;&quot;&#x7D;"            data-parallax-100-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="/assets/images/media/landing/15.apartments-hero/background@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221282%22%20height=%221388%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201282%201388%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1282" height="1388">                    <source
        data-srcset="/assets/images/media/landing/15.apartments-hero/background@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221008%22%20height=%221092%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201008%201092%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1008" height="1092">                    <source
        data-srcset="/assets/images/media/landing/15.apartments-hero/background@xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            data-src="/assets/images/media/landing/15.apartments-hero/background-xs.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20640%22%3E%3C/svg%3E"                    alt=""                            width="360" height="640"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"                        data-parallax-measure-selector=".section"                        data-parallax-clamp="true"            data-parallax-0-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;10svh&#x29;&quot;&#x7D;"            data-parallax-100-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="/assets/images/media/landing/15.apartments-hero/background@xxxl.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1282" height="1388">                    <source srcset="/assets/images/media/landing/15.apartments-hero/background@xxxl.webp" media="(min-width: 1440px) and (min-height: 700px)" width="1008" height="1092">                    <source srcset="/assets/images/media/landing/15.apartments-hero/background@xxxl.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="780">
        <img
            src="/assets/images/media/landing/15.apartments-hero/background-xs.webp"                    alt=""                            width="360" height="640"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                        <div class="apartments-hero-content pb-2 pb-layout:md">
                            <div class="px-layout">
                                <p class="h1 text-right leading-trim" data-reveal="text">
                                    SPLENDID<br />
APARTMENTS
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</section>
    

<section
    id="services"
    data-plugin="history"
    data-history-offset-top="100"
    data-history-offset-bottom="100"
    data-history-offset-top-mobile="0"
    data-history-offset-bottom-mobile="0"
    class="services section ui-dark ui-background"
    data-scroll-section
    data-themed-class="ui-dark"
    data-scroll-snap-point='[
                { "viewport": 100, "element": 0 },                { "viewport": 200, "element": 0 },                { "viewport": 300, "element": 0 }            ]'
>
    <h2 class="sr-only">
        technologies and services
    </h2>
    <div
        class="services__sticky sticky sticky--under-next sticky--under-previous is-hidden--sm-down"
        style="--item-count: 3"
    >
        <div
            class="sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
        >
            <div class="row">
                <div class="services__container col col--xs-4 col--md-6"
                    data-plugin="parallax"
                    data-parallax-pattern="services"
                    data-parallax-services-count="3"
                >
                    <div class="services__image">
                                                    <div class="background background--cover ui-background"
                                data-plugin="parallax"
                                data-parallax-pattern="servicesImage"
                                data-parallax-item-index="1"
                            >
                                                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/32/image2x_10_1755265771.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/32/image2x_10_1755265771.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/32/image2x_10_1755265771.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/32/image2x_10_1755265771.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22820%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20820%22%3E%3C/svg%3E"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/32/image2x_10_1755265771.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/32/image2x_10_1755265771.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/32/image2x_10_1755265771.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/32/image2x_10_1755265771.webp"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                            </div>
                                                    <div class="background background--cover ui-background"
                                data-plugin="parallax"
                                data-parallax-pattern="servicesImage"
                                data-parallax-item-index="2"
                            >
                                                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/39/image_23_1777295803.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/39/image_23_1777295803.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/39/image_23_1777295803.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/39/image_23_1777295803.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22820%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20820%22%3E%3C/svg%3E"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/39/image_23_1777295803.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/39/image_23_1777295803.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/39/image_23_1777295803.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/39/image_23_1777295803.webp"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                            </div>
                                                    <div class="background background--cover ui-background"
                                data-plugin="parallax"
                                data-parallax-pattern="servicesImage"
                                data-parallax-item-index="3"
                            >
                                                                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/39/image_22_1777295806.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/39/image_22_1777295806.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/39/image_22_1777295806.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/39/image_22_1777295806.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22820%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20820%22%3E%3C/svg%3E"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/39/image_22_1777295806.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/39/image_22_1777295806.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/39/image_22_1777295806.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/39/image_22_1777295806.webp"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                                            </div>
                                            </div>
                </div>
                <div class="services__left col col--md-6 px-layout">
                    <p class="h3 text-right leading-trim">
                        TECHNOLOGIES<br />
AND SERVICES
                    </p>
                </div>
            </div>
        </div>
        <div
            class="sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
            data-plugin="stickyBottom"
        >
            <div class="services__list-wrapper row">
                <div class="col col--md-3 offset--md-6 pl-layout pb-layout">
                    <ul class="services__list js-services-list" data-count="2">
                                                    <li>
                                

<div class="services-card card ui-dark">
    <div class="card__lt">
        <p class="text-small leading-trim">
            digital elevator
        </p>
    </div>
    <div class="card__lb">
        <p class="leading-trim">
            The&nbsp;intelligent system can independently determine when the&nbsp;resident is returning home and call the&nbsp;lift to&nbsp;the&nbsp;correct floor.
        </p>
    </div>
</div>
                            </li>
                                                    <li>
                                

<div class="services-card card ui-dark">
    <div class="card__lt">
        <p class="text-small leading-trim">
            Home control center
        </p>
    </div>
    <div class="card__lb">
        <p class="leading-trim">
            Video cameras in&nbsp;the&nbsp;complex send data to&nbsp;a&nbsp;single control room, while the&nbsp;Alpha Open software platform collects and processes data on&nbsp;the&nbsp;operation of&nbsp;engineering communications.
        </p>
    </div>
</div>
                            </li>
                                                    <li>
                                

<div class="services-card card ui-dark">
    <div class="card__lt">
        <p class="text-small leading-trim">
            Bellman service
        </p>
    </div>
    <div class="card__lb">
        <p class="leading-trim">
            Take the&nbsp;first step into&nbsp;your new home with&nbsp;ease and confidence. We will provide professional support in&nbsp;arranging official registration, accompanying you at&nbsp;every stage.
        </p>
    </div>
</div>
                            </li>
                                            </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="is-hidden--md-up">
                <div class="services__container">
                            <p class="services__title h3 leading-trim is-hidden--md-up">
                    TECHNOLOGIES<br />
AND SERVICES
                </p>
                        <div class="services__image">
                <div class="background background--cover ui-background"
                    data-plugin="parallax"
                    data-parallax-measure-selector=".services__image"
                    data-parallax-enable-mq="sm-down"
                                        data-parallax-100-100='{"transform": "translateY(-5svh)"}'
                    data-parallax-0-0='{"transform": "translateY(0svh)"}'
                    data-parallax-mobile-smooth="true"
                >
                                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/32/image2x_10_1755265771.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/32/image2x_10_1755265771.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/32/image2x_10_1755265771.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/32/image2x_10_1755265771.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22820%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20820%22%3E%3C/svg%3E"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/32/image2x_10_1755265771.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/32/image2x_10_1755265771.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/32/image2x_10_1755265771.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/32/image2x_10_1755265771.webp"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                    </div>
            </div>
            <div class="services__content pt-layout pb-4">
                <div class="row">
                    <div class="col col--xs-2 pl-layout">
                        <p class="h2 leading-trim">
                            digital elevator
                        </p>
                    </div>
                    <div class="col col--xs-2 pr-layout">
                        <div class="services__counter px-layout">
                            <span class="leading-trim">1</span>
                            <span class="services__counter-line"></span>
                            <span class="text-color-smallest leading-trim">3</span>
                        </div>
                    </div>
                </div>

                <div class="services__text px-layout mt-4">
                    <p class="text-small leading-trim">
                        <span class="text-offset"></span>
                        The&nbsp;intelligent system can independently determine when the&nbsp;resident is returning home and call the&nbsp;lift to&nbsp;the&nbsp;correct floor.
                    </p>
                </div>
            </div>
        </div>
                <div class="services__container">
                        <div class="services__image">
                <div class="background background--cover ui-background"
                    data-plugin="parallax"
                    data-parallax-measure-selector=".services__image"
                    data-parallax-enable-mq="sm-down"
                                        data-parallax-100-100='{"transform": "translateY(-5svh)"}'
                    data-parallax-0-0='{"transform": "translateY(0svh)"}'
                    data-parallax-mobile-smooth="true"
                >
                                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/39/image_23_1777295803.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/39/image_23_1777295803.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/39/image_23_1777295803.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/39/image_23_1777295803.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22820%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20820%22%3E%3C/svg%3E"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/39/image_23_1777295803.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/39/image_23_1777295803.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/39/image_23_1777295803.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/39/image_23_1777295803.webp"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                    </div>
            </div>
            <div class="services__content pt-layout pb-4">
                <div class="row">
                    <div class="col col--xs-2 pl-layout">
                        <p class="h2 leading-trim">
                            Home control center
                        </p>
                    </div>
                    <div class="col col--xs-2 pr-layout">
                        <div class="services__counter px-layout">
                            <span class="leading-trim">2</span>
                            <span class="services__counter-line"></span>
                            <span class="text-color-smallest leading-trim">3</span>
                        </div>
                    </div>
                </div>

                <div class="services__text px-layout mt-4">
                    <p class="text-small leading-trim">
                        <span class="text-offset"></span>
                        Video cameras in&nbsp;the&nbsp;complex send data to&nbsp;a&nbsp;single control room, while the&nbsp;Alpha Open software platform collects and processes data on&nbsp;the&nbsp;operation of&nbsp;engineering communications.
                    </p>
                </div>
            </div>
        </div>
                <div class="services__container">
                        <div class="services__image">
                <div class="background background--cover ui-background"
                    data-plugin="parallax"
                    data-parallax-measure-selector=".services__image"
                    data-parallax-enable-mq="sm-down"
                                        data-parallax-100-100='{"transform": "translateY(-5svh)"}'
                    data-parallax-0-0='{"transform": "translateY(0svh)"}'
                    data-parallax-mobile-smooth="true"
                >
                                            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/39/image_22_1777295806.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/39/image_22_1777295806.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/39/image_22_1777295806.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/39/image_22_1777295806.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22820%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20820%22%3E%3C/svg%3E"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxxl/uploads/39/image_22_1777295806.webp" media="(min-width: 1920px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_xxl/uploads/39/image_22_1777295806.webp" media="(min-width: 1440px) and (min-height: 700px)" width="720" height="900">                    <source srcset="https://zorge9.estate/media/cache/homepage_services_slider_img_md/uploads/39/image_22_1777295806.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="900">
        <img
            src="https://zorge9.estate/media/cache/homepage_services_slider_img_xs/uploads/39/image_22_1777295806.webp"                    alt=""                            width="720" height="820"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                                    </div>
            </div>
            <div class="services__content pt-layout pb-4">
                <div class="row">
                    <div class="col col--xs-2 pl-layout">
                        <p class="h2 leading-trim">
                            Bellman service
                        </p>
                    </div>
                    <div class="col col--xs-2 pr-layout">
                        <div class="services__counter px-layout">
                            <span class="leading-trim">3</span>
                            <span class="services__counter-line"></span>
                            <span class="text-color-smallest leading-trim">3</span>
                        </div>
                    </div>
                </div>

                <div class="services__text px-layout mt-4">
                    <p class="text-small leading-trim">
                        <span class="text-offset"></span>
                        Take the&nbsp;first step into&nbsp;your new home with&nbsp;ease and confidence. We will provide professional support in&nbsp;arranging official registration, accompanying you at&nbsp;every stage.
                    </p>
                </div>
            </div>
        </div>
            </div>
</section>
    <section
    class="section"
    data-scroll-section
>
    
<div
    id="penthouses"
    class="penthouses-hero section ui-dark ui-background"
    data-themed-class="ui-dark"
    data-plugin="reveal history"
    data-history-offset-top="100"
    data-history-offset-top-mobile="0"
    data-scroll-snap-point='[
        { "viewport": 100, "element": 0 }
    ]'
>
    <div class="sticky sticky:md-up sticky--under-next sticky--under-previous">
        <div
            class="sticky__layer sticky__layer--sticky"
            data-scroll
            data-scroll-sticky
        >
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js penthouses-hero__image background background--cover"                        data-parallax-enable-mq="md-up"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".section"            data-parallax-0-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"            data-parallax-100-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-plugin="appear  parallax"        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_bg_xxxl/uploads/39/rectangle_733_1777295807.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222563%22%20height=%221388%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202563%201388%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="2563" height="1388">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_bg_xxl/uploads/39/rectangle_733_1777295807.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%222016%22%20height=%221092%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%202016%201092%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="2016" height="1092">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_bg_md/uploads/39/rectangle_733_1777295807.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221440%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201440%20780%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1440" height="780">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_penthouse_bg_xs/uploads/39/rectangle_733_1777295807.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22640%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20640%22%3E%3C/svg%3E"                    alt=""                            width="360" height="640"                                        data-plugin="parallax"                        data-parallax-enable-mq="sm-down"                        data-parallax-clamp="true"                        data-parallax-measure-selector="picture"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" penthouses-hero__image background background--cover"                        data-parallax-enable-mq="md-up"                        data-parallax-clamp="true"                        data-parallax-measure-selector=".section"            data-parallax-0-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"            data-parallax-100-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-plugin=" parallax"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_bg_xxxl/uploads/39/rectangle_733_1777295807.webp" media="(min-width: 1920px) and (min-height: 700px)" width="2563" height="1388">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_bg_xxl/uploads/39/rectangle_733_1777295807.webp" media="(min-width: 1440px) and (min-height: 700px)" width="2016" height="1092">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_bg_md/uploads/39/rectangle_733_1777295807.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1440" height="780">
        <img
            src="https://zorge9.estate/media/cache/homepage_penthouse_bg_xs/uploads/39/rectangle_733_1777295807.webp"                    alt=""                            width="360" height="640"                                        data-plugin="parallax"                        data-parallax-enable-mq="sm-down"                        data-parallax-clamp="true"                        data-parallax-measure-selector="picture"            data-parallax-100-0="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;-10svh&#x29;&quot;&#x7D;"            data-parallax-0-100="&#x7B;&quot;transform&quot;&#x3A;&quot;translateY&#x28;0svh&#x29;&quot;&#x7D;"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    

            <div class="penthouses-hero__content pb-2 pb-layout:md"
                data-plugin="parallax"
                data-parallax-enable-mq="md-up"
                data-parallax-clamp="true"
                data-parallax-measure-selector=".section"
                data-parallax-0-0='{"transform": "translateY(10svh)"}'
                data-parallax--100-0='{"transform": "translateY(0svh)"}'
                data-parallax-100-100='{"transform": "translateY(-10svh)"}'
            >
                <div class="px-layout">
                    <h2 class="penthouses-hero__title h1 text-right leading-trim" data-reveal="text" data-reveal-distance="0">
                        PENTHOUSES<br />
WITH&nbsp;GLASS ROOFS

                    </h2>
                </div>
                <div class="row">
                    <div class="col col--xs-4 col--md-5 px-layout pr-0:md">
                        <p class="leading-trim" data-reveal="text" data-reveal-distance="0">
                            Climb to&nbsp;the&nbsp;top, gaze at&nbsp;the&nbsp;sky that has become much closer, and take your place among&nbsp;the&nbsp;stars. Penthouse owners have access to&nbsp;all dimensions: the&nbsp;height of&nbsp;the&nbsp;horizon, the&nbsp;width of&nbsp;the&nbsp;panorama, and the&nbsp;length of&nbsp;the&nbsp;admiring gaze.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    
<div
    class="penthouses section section--top ui-dark ui-background pb-5 pb-8:md"
    data-themed-class="ui-dark"
    data-z-index="2"
    data-plugin="reveal history"
    data-history-id="penthouses"
    data-scroll-snap-point='[
        { "viewport": 0, "element": 0, "scrollable": true }
    ]'
>
    <div class="row">
        <div class="col col--xs-4 col--md-9 offset--md-3 mb-1 mb-0:md">
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_1_xxxl/uploads/39/zorge90368_1777295805.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221922%22%20height=%221281%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201922%201281%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1922" height="1281">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_1_xxl/uploads/39/zorge90368_1777295805.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221512%22%20height=%221008%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201512%201008%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1512" height="1008">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_1_md/uploads/39/zorge90368_1777295805.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221080%22%20height=%22720%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201080%20720%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1080" height="720">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_penthouse_img_1_xs/uploads/39/zorge90368_1777295805.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22360%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20360%22%3E%3C/svg%3E"                    alt=""                            width="360" height="360"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_1_xxxl/uploads/39/zorge90368_1777295805.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1922" height="1281">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_1_xxl/uploads/39/zorge90368_1777295805.webp" media="(min-width: 1440px) and (min-height: 700px)" width="1512" height="1008">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_1_md/uploads/39/zorge90368_1777295805.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1080" height="720">
        <img
            src="https://zorge9.estate/media/cache/homepage_penthouse_img_1_xs/uploads/39/zorge90368_1777295805.webp"                    alt=""                            width="360" height="360"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
        </div>
        <div class="col col--xs-4 col--md-11 px-layout pr-0:md mb-4">
            <p class="penthouses__text-1 h2 leading-trim" data-reveal="text">
                <span class="text-offset text-offset--3 is-hidden--sm-down"></span>
                SUNBEAMS LIGHT UP&nbsp;THE&nbsp;TRANSPARENT WINDOWS ABOVE&nbsp;YOUR HEAD AND REFLECT THE&nbsp;COLORS OF&nbsp;THE&nbsp;SUNSET. With&nbsp;high ceilings and elegant decor, penthouses give you the&nbsp;feeling of&nbsp;flying over&nbsp;the&nbsp;luxurious landscape of&nbsp;your own life.
            </p>
        </div>
        <div class="col col--xs-4 px-layout mb-6 container-h-vars is-hidden--md-up">
            <div class="penthouses__carousel mobile-scrollable">
                <div class="penthouses__card mobile-scrollable__item ui-background">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xxxl/uploads/39/image_25_1777295804.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22801%22%20height=%221210%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20801%201210%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="801" height="1210">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xxl/uploads/39/image_25_1777295804.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22630%22%20height=%22952%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20630%20952%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="630" height="952">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_md/uploads/39/image_25_1777295804.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22450%22%20height=%22680%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20450%20680%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="450" height="680">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xs/uploads/39/image_25_1777295804.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22433%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20433%22%3E%3C/svg%3E"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xxxl/uploads/39/image_25_1777295804.webp" media="(min-width: 1920px) and (min-height: 700px)" width="801" height="1210">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xxl/uploads/39/image_25_1777295804.webp" media="(min-width: 1440px) and (min-height: 700px)" width="630" height="952">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_md/uploads/39/image_25_1777295804.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="450" height="680">
        <img
            src="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xs/uploads/39/image_25_1777295804.webp"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                    <div class="penthouses__card-content">
                        <p class="h1 leading-trim mb-0.66">
                            4.2 m
                        </p>
                        <p class="text-small leading-trim">
                            ceilings height
                        </p>
                    </div>
                </div>
                <div class="penthouses__card mobile-scrollable__item ui-background">
                    
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_3_xxxl/assets/images/media/landing/18.penthouses/image-2%40md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221228%22%20height=%221601%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201228%201601%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1601">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_3_xxl/assets/images/media/landing/18.penthouses/image-2%40md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22966%22%20height=%221260%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20966%201260%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="1260">                    <source
        data-srcset="/assets/images/media/landing/18.penthouses/image-2@md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22690%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20690%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="690" height="900">
        <img
            data-src="/assets/images/media/landing/18.penthouses/image-2@xs.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22433%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20433%22%3E%3C/svg%3E"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_3_xxxl/assets/images/media/landing/18.penthouses/image-2%40md.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1601">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_3_xxl/assets/images/media/landing/18.penthouses/image-2%40md.webp" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="1260">                    <source srcset="/assets/images/media/landing/18.penthouses/image-2@md.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="690" height="900">
        <img
            src="/assets/images/media/landing/18.penthouses/image-2@xs.webp"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                    <div class="penthouses__card-content">
                        <p class="h1 leading-trim mb-0.66">
                            3.6 m
                        </p>
                        <p class="text-small leading-trim">
                            window height
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col col--xs-4 col--md-4 pl-layout mb-8 is-hidden--sm-down">
            <div class="penthouses__card">
                
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xxxl/uploads/39/image_25_1777295804.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22801%22%20height=%221210%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20801%201210%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="801" height="1210">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xxl/uploads/39/image_25_1777295804.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22630%22%20height=%22952%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20630%20952%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="630" height="952">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_md/uploads/39/image_25_1777295804.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22450%22%20height=%22680%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20450%20680%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="450" height="680">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xs/uploads/39/image_25_1777295804.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22433%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20433%22%3E%3C/svg%3E"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xxxl/uploads/39/image_25_1777295804.webp" media="(min-width: 1920px) and (min-height: 700px)" width="801" height="1210">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xxl/uploads/39/image_25_1777295804.webp" media="(min-width: 1440px) and (min-height: 700px)" width="630" height="952">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_2_md/uploads/39/image_25_1777295804.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="450" height="680">
        <img
            src="https://zorge9.estate/media/cache/homepage_penthouse_img_2_xs/uploads/39/image_25_1777295804.webp"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                <div class="penthouses__card-content">
                    <p class="h1 leading-trim mb-0.66">
                        4.2 m
                    </p>
                    <p class="text-small leading-trim">
                        ceilings height
                    </p>
                </div>
            </div>
        </div>
        <div class="col col--xs-4 col--md-6 offset--md-2 pr-layout mb-8 mt-6 is-hidden--sm-down">
            <div class="penthouses__card">
                
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_3_xxxl/assets/images/media/landing/18.penthouses/image-2%40md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221228%22%20height=%221601%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201228%201601%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1601">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_3_xxl/assets/images/media/landing/18.penthouses/image-2%40md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22966%22%20height=%221260%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20966%201260%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="1260">                    <source
        data-srcset="/assets/images/media/landing/18.penthouses/image-2@md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22690%22%20height=%22900%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20690%20900%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="690" height="900">
        <img
            data-src="/assets/images/media/landing/18.penthouses/image-2@xs.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22433%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20433%22%3E%3C/svg%3E"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_3_xxxl/assets/images/media/landing/18.penthouses/image-2%40md.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1228" height="1601">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_3_xxl/assets/images/media/landing/18.penthouses/image-2%40md.webp" media="(min-width: 1440px) and (min-height: 700px)" width="966" height="1260">                    <source srcset="/assets/images/media/landing/18.penthouses/image-2@md.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="690" height="900">
        <img
            src="/assets/images/media/landing/18.penthouses/image-2@xs.webp"                    alt=""                            width="320" height="433"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
                <div class="penthouses__card-content">
                    <p class="h1 leading-trim mb-0.66">
                        3.6 m
                    </p>
                    <p class="text-small leading-trim">
                        window height
                    </p>
                </div>
            </div>
        </div>
        <div class="col col--xs-4 col--md-3 px-layout mb-1 is-hidden--md-up">
            <p class="h2 text-right leading-trim" data-reveal="text">
                private<br />
Terraces
            </p>
        </div>
        <div class="col col--xs-4 col--md-9 mb-1 mb-0:md px-layout px-0:md penthouses__image">
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full parallax-image-move"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_4_xxxl/assets/images/media/landing/18.penthouses/image-4%40xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221922%22%20height=%221281%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201922%201281%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1922" height="1281">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_4_xxl/assets/images/media/landing/18.penthouses/image-4%40xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221512%22%20height=%221008%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201512%201008%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1512" height="1008">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_4_md/assets/images/media/landing/18.penthouses/image-4%40xxxl.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221080%22%20height=%22720%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201080%20720%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1080" height="720">
        <img
            data-src="https://zorge9.estate/media/cache/homepage_penthouse_img_4_xs/assets/images/media/landing/18.penthouses/image-4%40xs.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22320%22%20height=%22274%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20320%20274%22%3E%3C/svg%3E"                    alt=""                            width="320" height="274"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full parallax-image-move"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_4_xxxl/assets/images/media/landing/18.penthouses/image-4%40xxxl.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1922" height="1281">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_4_xxl/assets/images/media/landing/18.penthouses/image-4%40xxxl.webp" media="(min-width: 1440px) and (min-height: 700px)" width="1512" height="1008">                    <source srcset="https://zorge9.estate/media/cache/homepage_penthouse_img_4_md/assets/images/media/landing/18.penthouses/image-4%40xxxl.webp" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="1080" height="720">
        <img
            src="https://zorge9.estate/media/cache/homepage_penthouse_img_4_xs/assets/images/media/landing/18.penthouses/image-4%40xs.webp"                    alt=""                            width="320" height="274"                                        data-plugin="parallax"                        data-parallax-pattern="imageMove"                        data-parallax-mobile-smooth="true"            draggable="false"
        >
    </picture>

            
        </noscript>
    
        </div>
        <div class="penthouses__side col col--xs-4 col--md-3 px-layout pl-0:md">
            <p class="h2 text-right leading-trim is-hidden--sm-down" data-reveal="text">
                private<br />
Terraces
            </p>
            <p class="penthouses__text-2 leading-trim" data-reveal="text">
                <span class="text-offset is-hidden--sm-down"></span>
                This is not just a&nbsp;place to&nbsp;relax, it&#039;s an&nbsp;extension of&nbsp;your home where you can realise your bold ideas for&nbsp;creating a&nbsp;garden, a&nbsp;space for&nbsp;evening gatherings or a&nbsp;place to&nbsp;enjoy peace and quiet under&nbsp;the&nbsp;stars.
            </p>
        </div>
    </div>
</div>
</section>
                                    </main>

                                            


<footer
    class="section section--no-overflow ui-dark ui-background footer py-layout is-hidden--print"
    data-scroll-section
    data-themed-class="ui-dark"
>
    <div class="text-center mb-4.5 mb-6:md">
                
        
                                                                      
            

        
                
        
        
        
    <a
        class="btn btn--link btn--link-static btn--animate-icon"
                                                href="#top"
                                                                    aria-label="Scroll to top of the page"
                                                    >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-long-arrow-up" width="14" height="31" aria-hidden="true"            viewBox="0 0 14 31"
            style="--icon-width: 14; --icon-height: 31;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-up" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-up"></use></svg>
                                                    <svg class="icon icon-long-arrow-up" width="14" height="31" aria-hidden="true"            viewBox="0 0 14 31"
            style="--icon-width: 14; --icon-height: 31;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-up" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#long-arrow-up"></use></svg>
                                            </span>
                                    </span>
    </a>
    </div>
    <div class="row row--bottom-md">
        <div class="col col--xs-4 col--md-8 px-layout group group--center mb-6 mb-0:md">
                                    
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn footer__logo btn--link btn--link-heading"
                                                href="#top"
                                                                    aria-label="Scroll to top of the page"
                                                    >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-logo" width="673" height="87" aria-hidden="true"            viewBox="0 0 673 87"
            style="--icon-width: 673; --icon-height: 87;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo"></use></svg>
                                            </span>
                                    </span>
    </a>
                    </div>
        <div class="col col--xs-2 col--md-2 col--order-first-md pl-layout">
            <p class="text-small leading-trim">
                © 2026 Zorge №9
            </p> 
        </div>
        <div class="col col--xs-2 col--md-2 pr-layout">
            <div class="footer__vig">
                        
        
                                                                      
            

                    
    
                    
        
        
    <a
        class="btn btn--link btn--link-static btn--text-small btn--clone"
                                    target="_blank" rel="noopener"                                        href="https://videinfra.com/"
                                                                data-plugin=" button"
                            data-button-clone-content="true"
                                                    title="Award-winning real estate website design agency"
                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Site by vide infra

                                    </span>
            
                    </span>
    </a>
            </div>
        </div>
    </div>
</footer>
                                    </div>
            
                        <div class="js-modal">
                                                    


        
        
        
    <div
        class="modal modal--full ui-dark is-hidden"
        role="dialog"
        aria-hidden="true"        aria-label="Меню"                                id="menu"                        data-plugin="modal"                        data-modal-animation-name-in="modal-clip-in"                        data-modal-animation-name-out="modal-clip-out"

                data-nosnippet    >
        <div class="modal__background"></div>

                <div class="modal__animation">
            <div class="modal__scroller"><div class="modal__scroller__scrollable js-scroll-parent"><div class="modal__content-wrapper js-modal-scrollable-content">
                <div class="modal__content js-modal-ignore-auto-close js-scroll-parent-ignore">

                                        
                                        
    



<header
    class="header header--menu is-hidden--print ui-dark"
    
>
    <div class="header__content row row--top-xs">
        <div class="col col--xs-3 col--md-9 py-layout pl-layout">
                                
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn header__logo btn--link btn--link-static js-modal-close"
                                                                                                                                                        aria-label="Close"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-logo" width="673" height="87" aria-hidden="true"            viewBox="0 0 673 87"
            style="--icon-width: 673; --icon-height: 87;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo"></use></svg>
                                            </span>
                                    </span>
    </a>
        </div>
                <div class="col col--xs-1 col--md-3 group group--nowrap group--none py-layout pr-layout">
            <div class="header__item is-hidden--sm-down">
                        
        
                                                                      
            

                    
    
                    
        
        
    <a
        class="btn btn--link btn--link-static btn--text-small btn--clone"
                                                href="/apartments"
                                                                data-plugin=" button"
                            data-button-clone-content="true"
                                    >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Choose an Apartment

                                    </span>
            
                    </span>
    </a>
            </div>
                        <div class="header__item header__item--close">
                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--outline btn--square btn--lg js-modal-close"
                                                                                                                                                        aria-label="Close"
                                                    tabindex="0"
                            role="button"
            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-close" width="18" height="16" aria-hidden="true"            viewBox="0 0 18 16"
            style="--icon-width: 18; --icon-height: 16;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close"></use></svg>
                                            </span>
                                    </span>
    </a>
            </div>
        </div>
    </div>
</header>
    <div class="menu row">
        <div class="menu__list col col--xs-4 col--md-6 px-layout pb-layout">
            <ul>
                                                            <li class="menu__list-item h3">
                            <a href="/location" class="menu__list-link btn-container js-history-link ">
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-static h3"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Location

                                    </span>
            
                    </span>
    </span>
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn menu__list-arrow btn--link btn--link-static"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
                            </a>
                        </li>
                                                                                <li class="menu__list-item h3">
                            <a href="/style" class="menu__list-link btn-container js-history-link ">
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-static h3"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Design

                                    </span>
            
                    </span>
    </span>
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn menu__list-arrow btn--link btn--link-static"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
                            </a>
                        </li>
                                                                                <li class="menu__list-item h3">
                            <a href="/infrastructure" class="menu__list-link btn-container js-history-link ">
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-static h3"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Infrastructure

                                    </span>
            
                    </span>
    </span>
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn menu__list-arrow btn--link btn--link-static"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
                            </a>
                        </li>
                                                                                <li class="menu__list-item h3">
                            <a href="/improvement" class="menu__list-link btn-container js-history-link ">
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-static h3"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Amenities

                                    </span>
            
                    </span>
    </span>
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn menu__list-arrow btn--link btn--link-static"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
                            </a>
                        </li>
                                                                                <li class="menu__list-item h3">
                            <a href="/apartments" class="menu__list-link btn-container js-history-link ">
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-static h3"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Apartments

                                    </span>
            
                    </span>
    </span>
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn menu__list-arrow btn--link btn--link-static"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
                            </a>
                        </li>
                                                                                <li class="menu__list-item h3">
                            <a href="/services" class="menu__list-link btn-container js-history-link ">
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-static h3"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Services

                                    </span>
            
                    </span>
    </span>
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn menu__list-arrow btn--link btn--link-static"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
                            </a>
                        </li>
                                                                                <li class="menu__list-item h3">
                            <a href="/parking" class="menu__list-link btn-container js-history-link ">
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-static h3"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Parking

                                    </span>
            
                    </span>
    </span>
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn menu__list-arrow btn--link btn--link-static"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
                            </a>
                        </li>
                                                                                <li class="menu__list-item h3">
                            <a href="/penthouses" class="menu__list-link btn-container js-history-link ">
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--link btn--link-static h3"
                                                            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Penthouses

                                    </span>
            
                    </span>
    </span>
                                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn menu__list-arrow btn--link btn--link-static"
                                                            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
                            </a>
                        </li>
                                                                                                                                                            </ul>
        </div>
        <div class="menu__side col col--xs-4 col--md-6 col--order-first-md px-layout pb-layout">
            
    
    
    
    
    <picture class=" menu__decor img-full"        draggable="false"    >                    <source srcset="/assets/images/media/menu/decor@xxxl.webp?v=1779376336" media="(min-width: 1920px) and (min-height: 700px)" width="1282" height="1254">                    <source srcset="/assets/images/media/menu/decor@xxl.webp?v=1779376336" media="(min-width: 1440px) and (min-height: 700px)" width="1008" height="986">                    <source srcset="/assets/images/media/menu/decor@md.webp?v=1779376336" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="720" height="704">
        <img
            src="/assets/images/media/menu/decor@xs.webp?v=1779376336"                    alt=""                            width="360" height="352"            draggable="false"
        >
    </picture>

            
            <div class="menu__footer group group--between group--bottom">
                    
                                    
    
            
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--text-arrow btn--text-small btn-container btn--outline btn--outline-secondary"
                                                href="#gallery-modal"
                                                                                                        data-content-animation-id="false"
                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                                    
        
                                                                      
            

                    
    
                    
        
        
    <span
        class="btn btn--clone btn--clone-small"
                                    data-plugin=" button"
                            data-button-clone-content="true"
                                    >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Gallery of Completed<br />
Residences

                                    </span>
            
                    </span>
    </span>
    

                                    </span>
            
                                                        <span class="btn__icon">
                    
        
                                                                      
            

                    
    
                    
        
        
    <span
        class="btn btn--clone btn--clone-right"
                                    data-plugin=" button"
                            data-button-clone-content="true"
                                    >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-arrow-right" width="7" height="12" aria-hidden="true"            viewBox="0 0 7 12"
            style="--icon-width: 7; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#arrow-right"></use></svg>
                                            </span>
                                    </span>
    </span>
        </span>
    
                                    </span>
    </a>
            </div>
        </div>
    </div>
                </div>
            </div></div></div>
        </div>
    </div>

                
                                        

        
        
        
    <div
        class="modal modal--side ui-light is-hidden"
        role="dialog"
        aria-hidden="true"        aria-label="рассрочка и ипотека"                                id="offers-modal"                        data-plugin="modal"

                data-nosnippet    >
        <div class="modal__background"></div>

                <div class="modal__animation">
            <div class="modal__scroller"><div class="modal__scroller__scrollable js-scroll-parent"><div class="modal__content-wrapper js-modal-scrollable-content">
                <div class="modal__content js-modal-ignore-auto-close js-scroll-parent-ignore">

                                                                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--outline btn--square btn--lg modal__close  js-modal-close"
                                                                                                                                                        aria-label="Close"
                                                    tabindex="0"
                            role="button"
            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-close" width="18" height="16" aria-hidden="true"            viewBox="0 0 18 16"
            style="--icon-width: 18; --icon-height: 16;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close"></use></svg>
                                            </span>
                                    </span>
    </a>
                    
                                        
    <div class="offers-modal" data-plugin="tabs">
        <div class="offers-modal__tablist group mb-4" role="tablist" aria-labelledby="offers-1">
                                    
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--link btn--text-small is-active"
                                                                                                                                                                                            aria-controls="offers-1"                        aria-selected="true"
                            tabindex="0"
                            role="tab"
            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Mortgage

                                    </span>
            
                    </span>
    </a>
                                    
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--link btn--text-small"
                                                                                                                                                                                            aria-controls="offers-2"                        aria-selected="false"
                            tabindex="0"
                            role="tab"
            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    trade-in

                                    </span>
            
                    </span>
    </a>
                    </div>
        <div class="tabs-contents">
                            <div
                    class="tabs-contents__content ui-background"
                    id="offers-1"
                    role="tabpanel"
                    aria-hidden="false"
                >
                    <div class="offers-modal__item">
                        <p role="heading" aria-level="2" class="h2 leading-trim mb-layout">Mortgage</p>

                        <hr class="mb-layout">

                        <div class="offers-modal__container">
                            <div class="offers-modal__side mb-2 mb-0:md">
                                                            </div>
                            <div class="offers-modal__content">
                                <div class="text text--offers">
                                    <p>Buying real estate is one of&nbsp;the&nbsp;most important decisions in&nbsp;life, and it is also one of&nbsp;the&nbsp;most expensive purchases. We will do everything possible to&nbsp;help you navigate this difficult process and make it as&nbsp;simple and straightforward as&nbsp;possible. Mortgage programs from&nbsp;20 leading banks will help bring your dream closer to&nbsp;reality.</p>
                                </div>
                                                            </div>
                        </div>
                    </div>
                </div>
                            <div
                    class="tabs-contents__content ui-background"
                    id="offers-2"
                    role="tabpanel"
                    aria-hidden="true"
                >
                    <div class="offers-modal__item">
                        <p role="heading" aria-level="2" class="h2 leading-trim mb-layout">trade-in</p>

                        <hr class="mb-layout">

                        <div class="offers-modal__container">
                            <div class="offers-modal__side mb-2 mb-0:md">
                                                            </div>
                            <div class="offers-modal__content">
                                <div class="text text--offers">
                                    <p>You can sell your apartment through&nbsp;our trusted partner.</p>

<p>The&nbsp;proceeds from&nbsp;the&nbsp;sale will be immediately transferred to&nbsp;the&nbsp;account for&nbsp;the&nbsp;payment of&nbsp;your new home.</p>

<p>We offer the&nbsp;best conditions for&nbsp;you right now: no need to&nbsp;wait for&nbsp;new buildings to&nbsp;rise in&nbsp;price.</p>
                                </div>
                                                            </div>
                        </div>
                    </div>
                </div>
                    </div>
    </div>
                </div>
            </div></div></div>
        </div>
    </div>

    

        
        
        
    <div
        class="modal modal--full gallery-modal ui-dark is-hidden"
        role="dialog"
        aria-hidden="true"        aria-label="галерея"                                id="gallery-modal"                        data-plugin="modal galleryModal"                        data-gallery-modal="modal galleryModal"                        data-gallery-modal-endpoint="/api/gallery-modal.json"                        data-gallery-modal-reload-on-filter-change="true"                        data-gallery-modal-scroll-to-list="true"                        data-modal-auto-close="false"                        data-modal-reset-form-on-close="true"                        data-modal-animation-name-in="modal-clip-in"                        data-modal-animation-name-out="modal-clip-out"                        data-modal-one-per-page="false"

                data-nosnippet    >
        <div class="modal__background"></div>

                <div class="modal__animation">
            <div class="modal__scroller"><div class="modal__scroller__scrollable js-scroll-parent"><div class="modal__content-wrapper js-modal-scrollable-content">
                <div class="modal__content js-modal-ignore-auto-close js-scroll-parent-ignore">

                                        
                                        
    <div data-scroll-section>
        <div class="sticky js-image-zoom-container">
            <div class="gallery-modal__head sticky__layer sticky__layer--sticky"
                data-scroll
                data-scroll-sticky
            >
                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--outline btn--square btn--lg modal__close js-modal-close"
                                                                                                                                                        aria-label="Close"
                                                    tabindex="0"
                            role="button"
            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-close" width="18" height="16" aria-hidden="true"            viewBox="0 0 18 16"
            style="--icon-width: 18; --icon-height: 16;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close"></use></svg>
                                            </span>
                                    </span>
    </a>
                <div class="h2 gallery-modal__title leading-trim is-hidden--md-up">
                    gallery
                </div>
            </div>
            <div class="gallery-modal__filters-container sticky__layer sticky__layer--sticky"
                data-scroll
                data-scroll-sticky
            >
                <div class="row">
                    

<form class="gallery-modal__filters col col--xs-4 col--md-4 px-layout py-layout js-ajax-filters js-image-zoom-hide is-hidden--sm-down">
    <div class="h2 gallery-modal__title leading-trim">
        gallery
    </div>
    <input class="sr-only" type="hidden" name="type" value="image" checked>
    <input class="sr-only" type="hidden" name="category" value="1" checked>
</form>
                </div>
            </div>
            <div class="gallery-modal__content-wrapper sticky__layer">
                <div class="gallery-modal__content px-layout:md py-layout ui-background" data-plugin="imagesZoom">
                    <button class="btn gallery-modal__zoom is-hidden--sm-down js-image-zoom-trigger"
                        aria-label="Увеличить фото"
                        data-plugin="cursor"
                        data-cursor-show-default-cursor="true"
                    >
                        <span class="cursor cursor--zoom js-cursor-button is-hidden--no-hover is-invisible">
                                    
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn cursor__button btn--outline is-decorative js-zoom-open"
                                                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-plus" width="16" height="17" aria-hidden="true"            viewBox="0 0 16 17"
            style="--icon-width: 16; --icon-height: 17;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#plus" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#plus"></use></svg>
                                            </span>
                                    </span>
    </span>
                                    
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn cursor__button btn--outline is-decorative js-zoom-close is-hidden"
                                                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-minus" width="16" height="17" aria-hidden="true"            viewBox="0 0 16 17"
            style="--icon-width: 16; --icon-height: 17;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#minus" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#minus"></use></svg>
                                            </span>
                                    </span>
    </span>
                        </span>
                    </button>
                    <div class="js-ajax-list">
                        
<script type="text/template" data-template-variable="item">
    <% if (request.category == item.category.name && request.type == item.type) { %>
        <% if (item.type == 'image') { %>
        <div class="gallery-modal__item"
        >
            <%= lazyPicture(item.image, {
                class: 'img-full',
            }) %>
            <div class="gallery-modal__item-play is-decorative is-hidden--hover is-hidden--sm-down">
                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--outline is-decorative"
                                                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-plus" width="16" height="17" aria-hidden="true"            viewBox="0 0 16 17"
            style="--icon-width: 16; --icon-height: 17;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#plus" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#plus"></use></svg>
                                            </span>
                                    </span>
    </span>
            </div>
        </div>
        <% } else if (item.type == 'video') { %>
        <a
            class="gallery-modal__item gallery-modal__item--video"
            href="#video-modal"
            data-plugin="cursor"
            data-cursor-show-default-cursor="true"
            data-video-modal-video-id="<%- item.src %>"
            data-video-modal-video-width="<%- item.width %>"
            data-video-modal-video-height="<%- item.height %>"
        >
            <%= lazyPicture(item.image, {
                class: 'img-full',
            }) %>
            <p class="gallery-modal__item-caption px-1 py-1">
                <span class="h2 leading-trim"><%= item.title %></span>
                <span class="text-small leading-trim"><%= item.info %></span>
            </p>
            <div class="gallery-modal__item-play is-decorative is-hidden--hover">
                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn btn--outline is-decorative"
                                                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-play" width="9" height="19" aria-hidden="true"            viewBox="0 0 9 19"
            style="--icon-width: 9; --icon-height: 19;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play"></use></svg>
                                            </span>
                                    </span>
    </span>
            </div>
            <div class="cursor cursor--video js-cursor-button is-hidden--no-hover is-invisible is-hidden--no-hover">
                        
        
                                                                      
            

        
    
        
        
        
    <span
        class="btn cursor__button cursor__button--play btn--outline is-decorative"
                                                            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-play" width="9" height="19" aria-hidden="true"            viewBox="0 0 9 19"
            style="--icon-width: 9; --icon-height: 19;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#play"></use></svg>
                                            </span>
                                    </span>
    </span>
            </div>
        </a>
        <% } %>
    <% } %>
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
                </div>
            </div></div></div>
        </div>
    </div>

    
        
        
        
    <div
        class="modal modal--full ui-dark is-hidden"
        role="dialog"
        aria-hidden="true"        aria-label="Видео"                                id="video-modal"                        data-plugin="videoModal"

                data-nosnippet    >
        <div class="modal__background"></div>

                <div class="modal__animation">
            <div class="modal__scroller"><div class="modal__scroller__scrollable js-scroll-parent"><div class="modal__content-wrapper js-modal-scrollable-content">
                <div class="modal__content js-modal-ignore-auto-close js-scroll-parent-ignore">

                                                                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--outline btn--square btn--lg modal__close  js-modal-close"
                                                                                                                                                        aria-label="Close"
                                                    tabindex="0"
                            role="button"
            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-close" width="18" height="16" aria-hidden="true"            viewBox="0 0 18 16"
            style="--icon-width: 18; --icon-height: 16;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close"></use></svg>
                                            </span>
                                    </span>
    </a>
                    
                                        

    <div class="js-video-modal-content">
        <script type="text/template">
                        <% if (videoId) { %>
                        
    <div data-plugin="videoPlayer"
                                data-video-player-id="&lt;%- videoId %&gt;"                        data-video-player-type="vimeo"                        data-video-player-width="&lt;%- videoWidth %&gt;"                        data-video-player-height="&lt;%- videoHeight %&gt;"                        data-video-player-autoplay="true"                        data-video-player-controls="true"
        class="video-player video-player--default video-player--contain video-player--fullscreen  ui-dark"
        style="--aspect-ratio: &lt;%- videoWidth %&gt; / &lt;%- videoHeight %&gt;"
    >
        
        <div class="video-player__panel js-video-player-panel is-hidden">
            <div class="video-player__panel__toggler">
                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--primary btn--square video-player__panel__toggler__btn video-player__panel__toggler__btn--play js-video-player-play"
                                                                                                                                                        aria-label="Play"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-video-play" width="20" height="20" aria-hidden="true"            viewBox="0 0 20 20"
            style="--icon-width: 20; --icon-height: 20;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-play" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-play"></use></svg>
                                            </span>
                                    </span>
    </a>

                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--primary btn--square video-player__panel__toggler__btn video-player__panel__toggler__btn--pause js-video-player-pause"
                                                                                                                                                        aria-label="Pause"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-video-pause" width="20" height="20" aria-hidden="true"            viewBox="0 0 20 20"
            style="--icon-width: 20; --icon-height: 20;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-pause" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-pause"></use></svg>
                                            </span>
                                    </span>
    </a>
            </div>

            <div class="js-video-player-progress-bar-place group__fill video-player-progress">
                <div class="js-video-player-circle video-player-progress__circle"></div>
                <div class="js-video-player-timer-place video-player-progress__timer"></div>
            </div>

            <div class="video-player__panel__duration js-video-player-duration"></div>

            <div class="video-player__panel__mute">
                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--primary btn--square js-video-player-mute video-player__panel__mute__inner video-player__panel__mute__inner--mute"
                                                                                                                                                        aria-label="Mute"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-video-mute" width="20" height="20" aria-hidden="true"            viewBox="0 0 20 20"
            style="--icon-width: 20; --icon-height: 20;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-mute" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-mute"></use></svg>
                                            </span>
                                    </span>
    </a>

                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--primary btn--square js-video-player-mute video-player__panel__mute__inner video-player__panel__mute__inner--unmute"
                                                                                                                                                        aria-label="Unmute"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-video-unmute" width="20" height="20" aria-hidden="true"            viewBox="0 0 20 20"
            style="--icon-width: 20; --icon-height: 20;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-unmute" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-unmute"></use></svg>
                                            </span>
                                    </span>
    </a>
            </div>

            <div class="video-player__panel__fullscreen">
                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--primary btn--square js-video-player-fullscreen video-player__panel__fullscreen__inner video-player__panel__fullscreen__inner--fullscreen"
                                                                                                                                                        aria-label="Fullscreen"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-video-fullscreen" width="20" height="20" aria-hidden="true"            viewBox="0 0 20 20"
            style="--icon-width: 20; --icon-height: 20;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-fullscreen" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-fullscreen"></use></svg>
                                            </span>
                                    </span>
    </a>

                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--primary btn--square js-video-player-fullscreen video-player__panel__fullscreen__inner video-player__panel__fullscreen__inner--minimize"
                                                                                                                                                        aria-label="Minimize"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-video-minimize" width="20" height="20" aria-hidden="true"            viewBox="0 0 20 20"
            style="--icon-width: 20; --icon-height: 20;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-minimize" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#video-minimize"></use></svg>
                                            </span>
                                    </span>
    </a>
            </div>
        </div>
    </div>

            <% } %>
        </script>
    </div>

                </div>
            </div></div></div>
        </div>
    </div>

    
        
        
        
    <div
        class="modal modal--full ui-dark is-hidden"
        role="dialog"
        aria-hidden="true"        aria-label="динамика стоимости"                                id="investment-modal"                        data-plugin="modal"

                data-nosnippet    >
        <div class="modal__background"></div>

                <div class="modal__animation">
            <div class="modal__scroller"><div class="modal__scroller__scrollable js-scroll-parent"><div class="modal__content-wrapper js-modal-scrollable-content">
                <div class="modal__content js-modal-ignore-auto-close js-scroll-parent-ignore">

                                                                        
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--outline btn--square btn--lg modal__close  js-modal-close"
                                                                                                                                                        aria-label="Close"
                                                    tabindex="0"
                            role="button"
            >
                    <svg aria-hidden="true" class="btn__outline">
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
                <rect x="0.75" y="0.75" rx="1" width="2" height="2"  data-plugin="svgLength"></rect>
            </svg>
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-close" width="18" height="16" aria-hidden="true"            viewBox="0 0 18 16"
            style="--icon-width: 18; --icon-height: 16;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#close"></use></svg>
                                            </span>
                                    </span>
    </a>
                    
                                        
    <div class="investment-modal row">
        <div class="investment-modal__image col col--xs-4 col--md-6 is-hidden--sm-down">
            
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js background background--cover"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_investment_modal_img_xxxl/assets/images/media/landing/21.investment/modal%40md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221282%22%20height=%221388%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201282%201388%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 700px)" width="1282" height="1388">                    <source
        data-srcset="https://zorge9.estate/media/cache/homepage_investment_modal_img_xxl/assets/images/media/landing/21.investment/modal%40md.webp"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221008%22%20height=%221092%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201008%201092%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 700px)" width="1008" height="1092">
        <img
            data-src="/assets/images/media/landing/21.investment/modal@md.webp"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22780%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20780%22%3E%3C/svg%3E"                    alt=""                            width="720" height="780"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" background background--cover"        draggable="false"    >                    <source srcset="https://zorge9.estate/media/cache/homepage_investment_modal_img_xxxl/assets/images/media/landing/21.investment/modal%40md.webp" media="(min-width: 1920px) and (min-height: 700px)" width="1282" height="1388">                    <source srcset="https://zorge9.estate/media/cache/homepage_investment_modal_img_xxl/assets/images/media/landing/21.investment/modal%40md.webp" media="(min-width: 1440px) and (min-height: 700px)" width="1008" height="1092">
        <img
            src="assets/images/media/landing/21.investment/modal@md.webp"                    alt=""                            width="720" height="780"            draggable="false"
        >
    </picture>

            
        </noscript>
    
        </div>
        <div class="investment-modal__content col col--xs-4 col--md-6">
            <p class="h2 leading-trim">
                Dynamics /n of&nbsp;cost
            </p>
            <div class="mt-1 mt-2:md">
                <hr class="mb-1">
                <p class="h1-large text-color-primary leading-trim mb-1 mb-0.66:md">20%</p>
                <p class="text-small text-color-primary leading-trim">Annual income</p>
            </div>
            <div class="mt-2 mt-1:md">
                
    
                
    
    
    <picture class="is-invisible--js is-hidden--no-js img-full"            data-plugin="appear "        draggable="false"    >                    <source
        data-srcset="assets/images/media/landing/21.investment/graph.svg"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22664%22%20height=%22338%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20664%20338%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="664" height="338">
        <img
            data-src="/assets/images/media/landing/21.investment/graph-xs.svg"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22327%22%20height=%22266%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20327%20266%22%3E%3C/svg%3E"                    alt=""                            width="327" height="266"            draggable="false"
        >
    </picture>

                    <noscript>
            
    
    
    
    
    <picture class=" img-full"        draggable="false"    >                    <source srcset="assets/images/media/landing/21.investment/graph.svg" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), (min-width: 668px) and (min-height: 416px), (min-width: 980px)" width="664" height="338">
        <img
            src="assets/images/media/landing/21.investment/graph-xs.svg"                    alt=""                            width="327" height="266"            draggable="false"
        >
    </picture>

            
        </noscript>
    
            </div>
        </div>
    </div>
                </div>
            </div></div></div>
        </div>
    </div>

            </div>
        </div>
    </div>

                

<dialog
    open
    aria-label="Cookie consent" aria-describedby="cookie-consent-description"
    class="cookie-consent cookie-consent--simple ui-dark"
    data-plugin="cookieConsent"
    id="cookie-consent"
>
    <div class="cookie-consent__container ui-background">
        <p id="cookie-consent-description" class="cookie-consent__description text-small leading-trim">
            This site collects         
        
                                                                      
            

                    
    
                    
        
        
    <a
        class="btn btn--link btn--link-static btn--clone"
                                    target="_blank" rel="noopener"                                        href="/privacy-policy"
                                                                    aria-label="About cookies"
                            data-plugin=" button"
                            data-button-clone-content="true"
                                    >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    cookie

                                    </span>
            
                    </span>
    </a>&nbsp;files
        </p>

                
        
                                                                      
            

        
    
        
        
        
    <a
        class="btn btn--link btn--underline btn--link-heading btn--text-small js-cookie-consent-accept"
                                                                                                                                                        aria-label="Accept cookies"
                                                    tabindex="0"
                            role="button"
            >
        
        <span class="btn__content">
            
                                                    <span
                    class="btn__text "
                                     >
                    Accept

                                            <span class="btn__underline"></span>
                                    </span>
            
                    </span>
    </a>
    </div>
</dialog>

<script>
    if ((document.cookie.indexOf('cookieConsentStatus=1') !== -1 || document.cookie.indexOf('cookieConsentStatus=0') !== -1) && document.querySelector('#cookie-consent')) {
        document.querySelector('#cookie-consent').classList.add('is-hidden')
    } else {
        document.documentElement.classList.add('with-cookie-consent');
    }
</script>
    
        
<div class="turn-message text-center ui-dark ui-background">
    <div class="turn-message__logo pt-layout px-layout">
        <svg class="icon icon-logo" width="673" height="87" aria-hidden="true"            viewBox="0 0 673 87"
            style="--icon-width: 673; --icon-height: 87;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#logo"></use></svg>
    </div>
    <div class="turn-message__content">
        <div class="turn-message__icon">
            <svg class="icon icon-turn-message" width="121" height="120" aria-hidden="true"            viewBox="0 0 121 120"
            style="--icon-width: 121; --icon-height: 120;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#turn-message" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#turn-message"></use></svg>
        </div>

        <p class="text-small leading-trim mt-1.5 mt-2:md">
            Please rotate your <br>phone vertically
        </p>
    </div>
</div>
    
<div class="error-message js-form-error-message is-hidden" role="alert" aria-live="assertive">
    <p class="js-form-error-message-text leading-trim"></p>
            
        
                                                                      
            

        
    
        
        
        
    <button
        class="btn btn--link btn--link-static js-form-error-message-close"
                                    type="button"
                                                    aria-label="Закрыть"
                                                    >
        
        <span class="btn__content">
            
                                    
                                                                    <span class="btn__icon ">
                        <svg class="icon icon-form-error" width="14" height="12" aria-hidden="true"            viewBox="0 0 14 12"
            style="--icon-width: 14; --icon-height: 12;"
        
        ><use href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#form-error" xlink:href="&#x2F;assets&#x2F;images&#x2F;icons.svg&#x3F;v&#x3D;1779376336#form-error"></use></svg>
                                            </span>
                                    </span>
    </button>
</div>

        <script fetchpriority="low" async src="assets/javascripts/browser-message/browser-message.js"></script>

            <script fetchpriority="low" src="assets/javascripts/shared.js"></script>
    
            <script>
                                                var LOCALES = {
                                    'errors': {
                        'email': 'Please enter a valid email address',
                        'required': 'This field is required',
                        'tel': 'Please enter a valid phone number',
                        'minlength': 'Please enter at least {0} characters',

                        'generic': 'Connection error, please try again',
                        'genericCode': 'Error occurred, please try again',

                        // Passwords don't match
                        'equalTo': 'Passwords don\'t match'
                    }
                            };
        </script>
    
        <script src="assets/javascripts/landing.js"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"d4912cc6c06d4f82967aae7c0e72ad0c","r":1}' crossorigin="anonymous"></script>
</body>
</html>
